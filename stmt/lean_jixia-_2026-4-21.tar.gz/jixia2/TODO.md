to debug output to console add line:
let _ ← IO.println s!"XXXX Found Name: {id}"

1. Anonymous Instance need append parameter name and type.
2. some additional declaration create like .wraper._@ .hdp

