/-
Copyright (c) 2024 BICMR@PKU. All rights reserved.
Released under the Apache 2.0 license as described in the file LICENSE.
Authors: Tony Beta Lambda
-/
import Lean
import Analyzer.Types
import Analyzer.Goal

open Lean Elab Meta Command

namespace Analyzer.Process.Line

-- see Lean.Server.FileWorker.getInteractiveTermGoal
def getGoalsAt (infoTree : InfoTree) (fileMap : FileMap) (pos : String.Pos) : IO (Array Goal) :=
  let goals := infoTree.goalsAt? fileMap pos
  goals.toArray.flatMapM fun r => Goal.fromTactic.runWithInfo r.useAfter r.ctxInfo r.tacticInfo

def onLoad : CommandElabM Unit :=
  enableInfoTree

def getResult : CommandElabM (Array LineInfo) := do
  let fileMap ← getFileMap
  let trees := (← getInfoTrees).toArray
  let numLines := fileMap.positions.size -- 這是總行數

  fileMap.positions.mapIdxM fun i p => do
    -- 1. 取得當前行的起始位置
    let startPos := fileMap.lineStart i

    -- 2. 取得下一行的起始位置，如果已經是最後一行，則取檔案結尾
    let endPos := if i + 1 < numLines
                  then fileMap.lineStart (i + 1)
                  else fileMap.source.endPos
    let lineContent := fileMap.source.extract startPos endPos

    return {
      start := p,
      state := ← trees.flatMapM (fun tree => getGoalsAt tree fileMap p),
      line  := lineContent
    }

end Analyzer.Process.Line
