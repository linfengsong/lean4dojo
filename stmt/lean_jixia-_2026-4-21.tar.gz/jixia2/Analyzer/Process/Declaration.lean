/-
Copyright (c) 2024 BICMR@PKU. All rights reserved.
Released under the Apache 2.0 license as described in the file LICENSE.
Authors: Tony Beta Lambda, Blueberry
-/
import Lean
import Analyzer.Types
import Lean.Elab

open Lean Elab Command Parser Term PrettyPrinter ScopedEnvExtension Meta
open TSyntax.Compat

namespace Analyzer.Process.Declaration

initialize selfCallRangesRef : IO.Ref (Std.HashMap Name (Array String.Range)) ←
  IO.mkRef {}

/-- Last string component of a `Name` (e.g. `A.B.f` -> `some "f"`). -/
private partial def nameLastString? : Name → Option String
  | .str _ s => some s
  | .num p _ => nameLastString? p
  | .anonymous => none

private partial def collectIdentRanges (stx : Syntax) (p : Name → Bool) : Array String.Range :=
  let here :=
    if stx.isIdent && p (stx.getId.eraseMacroScopes) then
      match stx.getRange? with
      | some r => #[r]
      | none   => #[]
    else
      #[]
  stx.getArgs.foldl (fun acc child => acc ++ collectIdentRanges child p) here

private def dedupRanges (xs : Array String.Range) : Array String.Range :=
  xs.foldl (fun acc r => if acc.contains r then acc else acc.push r) #[]

private def collectSelfCallRangesFromValue
    (valueStx : Syntax) (rawId fullName : Name) : Array String.Range :=
  if valueStx.isMissing || valueStx.isNone then
    #[]
  else
    let rawN  := rawId.eraseMacroScopes
    let fullN := fullName.eraseMacroScopes
    let rawLast?  := nameLastString? rawN
    let fullLast? := nameLastString? fullN

    let isSelf (id : Name) : Bool :=
      let id := id.eraseMacroScopes
      -- exact match first
      if id == rawN || id == fullN then
        true
      else
        -- fallback: same last component (handles qualified/unqualified usage)
        match nameLastString? id with
        | some s =>
            (rawLast?.isSome && rawLast?.get! == s) ||
            (fullLast?.isSome && fullLast?.get! == s)
        | none => false

    dedupRanges (collectIdentRanges valueStx isSelf)

private partial def findDeclVal? (stx : Syntax) : Option Syntax :=
  let k := stx.getKind
  if k == ``Lean.Parser.Command.declValSimple || k == ``Lean.Parser.Command.declValEqns then
    some stx
  else
    let rec loop (i : Nat) : Option Syntax :=
      if _h : i < stx.getNumArgs then
        match findDeclVal? (stx.getArg i) with
        | some v => some v
        | none   => loop (i + 1)
      else
        none
    loop 0

private def extractDeclValForSelfCalls? (v : Syntax) : Option Syntax :=
  if v.isMissing || v.isNone then
    none
  else if v.getKind == ``Lean.Parser.Command.declValSimple then
    if v.getNumArgs > 1 then some v[1] else some v
  else if v.getKind == ``Lean.Parser.Command.declValEqns then
    some v
  else
    some v


def getActiveNamespaces (env : Environment) : IO (Array Name) := do
  let exts ← scopedEnvExtensionsRef.get
  let mut nsSet : NameSet := {}
  for ext in exts do
    match ext.ext.getState env |>.stateStack with
    | top :: _ =>
      for ns in top.activeScopes.toList do
        nsSet := nsSet.insert ns
    | _ => pure ()
  return nsSet.toList.toArray

def getFullname (modifiers : Modifiers) (name : Name) : CommandElabM Name := do
  let currNamespace ← getCurrNamespace
  let view := extractMacroScopes name
  let declName := if (`_root_).isPrefixOf view.name then
      { view with name := name.replacePrefix `_root_ Name.anonymous }.review
    else
      currNamespace ++ name
  return if let .private := modifiers.visibility then
    mkPrivateName (← getEnv) declName
  else
    declName

def expandBinderType (ref : Syntax) (stx : Syntax) : Syntax :=
  if stx.getNumArgs == 0 then
    mkHole ref
  else
    stx[1]

def expandBinderIdent (stx : Syntax) : TermElabM Syntax :=
  match stx with
  | `(_) => mkFreshIdent stx (canonical := true)
  | _    => pure stx

def expandOptIdent (stx : Syntax) : TermElabM Syntax := do
  if stx.isNone then
    let id ← withFreshMacroScope <| MonadQuotation.addMacroScope `inst
    return mkIdentFrom stx id
  else
    return stx[0]

def expandBinderModifier (type : Syntax) (optBinderModifier : Syntax) : TermElabM Syntax := do
  if optBinderModifier.isNone then
    return type
  else
    let modifier := optBinderModifier[0]
    let kind     := modifier.getKind
    if kind == `binderDefault then
      let defaultVal := modifier[1]
      `(optParam $type $defaultVal)
    else if kind == `binderTactic then
      let tac := modifier[2]
      let name ← declareTacticSyntax tac
      `(autoParam $type $(mkIdentFrom tac name))
    else
      throwUnsupportedSyntax

def getBinderIds (ids : Syntax) : TermElabM (Array Syntax) :=
  ids.getArgs.mapM fun id =>
    let k := id.getKind
    if k == identKind || k == `Lean.Parser.Term.hole then
      return id
    else
      throwErrorAt id "identifier or `_` expected"

def toBinderViews (stx : Syntax) : TermElabM (Array BinderView) := do
  let k := stx.getKind
  if stx.isIdent || k == ``hole then
    return #[{ ref := stx, id := (← expandBinderIdent stx), type := mkHole stx, bi := .default }]
  else if k == ``Lean.Parser.Term.explicitBinder ||
          k == ``Lean.Parser.Term.implicitBinder ||
          k == ``Lean.Parser.Term.strictImplicitBinder then
    let bi : BinderInfo :=
      if k == ``Lean.Parser.Term.explicitBinder then .default
      else if k == ``Lean.Parser.Term.implicitBinder then .implicit
      else .strictImplicit
    let ids ← getBinderIds stx[1]
    let type := if k == ``Lean.Parser.Term.explicitBinder then
      if stx.getNumArgs > 3 then stx[3] else mkHole stx
    else
      let maybeColonNode := stx[2]
      if maybeColonNode.getKind == Lean.nullKind && maybeColonNode.getNumArgs > 1 then
        maybeColonNode[1]
      else
        mkHole stx
    let optModifier := if stx.getNumArgs > 4 then stx[4] else mkHole stx
    ids.mapM fun id => do
      let binderType := expandBinderType id type
      let finalType := if type.getKind == ``Lean.Parser.Term.hole then
          (mkHole id).setHeadInfo id.getTailInfo
      else
        type
      pure { ref := id, id := (← expandBinderIdent id), type := finalType, bi := bi }
  else if k == ``instBinder then
    let idstx := if stx.getNumArgs > 2 then stx[1] else mkHole stx
    let id ← expandOptIdent idstx
    let n := stx.getNumArgs
    let type := if n >= 3 then stx.getArg (n - 2) else stx
    return #[ { ref := id, id := id, type := type, bi := .instImplicit } ]
  else
    throwUnsupportedSyntax

private def isNamedDef (stx : Syntax) : Bool :=
  let kStr := stx.getKind.toString
  if kStr == "Lean.Parser.Module.import" ||
     kStr == "Lean.Parser.Command.open" ||
     kStr == "Lean.Parser.Command.export" ||    -- 新增：導出命名空間
     kStr == "Lean.Parser.Command.universe" ||  -- 新增：定義層級（通常不視為 named def）
     kStr == "Lean.Parser.Command.attribute" || -- 新增：修改屬性
     kStr == "Lean.Parser.Command.set_option" ||-- 新增：修改選項
     kStr == "Lean.Parser.Command.namespace" ||
     kStr == "Lean.Parser.Command.section" ||
     kStr == "Lean.Parser.Command.end" then false
  else
    stx.getPos?.isSome

private def isInstanceDef (stx : Syntax) : Bool :=
  stx.isOfKind ``Lean.Parser.Command.declaration &&
  stx.getNumArgs > 1 &&
  stx[1].getKind == ``Lean.Parser.Command.instance

private def getDefName? (stx : Syntax) : Option Name :=
  if !stx.isOfKind ``Lean.Parser.Command.declaration then none
  else
    let realStx := if stx.getNumArgs > 1 then stx[1] else stx
    let k := realStx.getKind

    if k == ``Lean.Parser.Command.theorem ||
       k == ``Lean.Parser.Command.definition ||
       k == ``Lean.Parser.Command.abbrev ||
       k == ``Lean.Parser.Command.opaque then
      let (id, _) := expandDeclIdCore realStx[1]
      some id
    else if k == ``Lean.Parser.Command.instance then
      let optDeclId := realStx[3]
      if optDeclId.isNone then none
      else
        let (id, _) := expandDeclIdCore optDeclId[0]
        some id
    else if k == ``Lean.Parser.Command.structure ||
            k == ``Lean.Parser.Command.inductive then
      let (id, _) := expandDeclIdCore realStx[1]
      some id
    else
      none

def getScopeInfo : CommandElabM ScopeInfo := do
  let scope ← getScope
  let env ← getEnv

  -- 1. 獲取一般的 open 宣告 (Array Name)
  let openDecls := scope.openDecls
  let _ := openDecls.map (fun decl =>
    match decl with

    | Lean.OpenDecl.simple ns _   => ns
    | Lean.OpenDecl.explicit ns _ => ns
  ) |>.toArray

  -- 2. 【核心修正】從環境擴展中「真正」提取活躍的 Scoped 命名空間
  -- 這是抓到 "Function", "Classical", "MeasureTheory" 的唯一方法
  let exts ← liftIO scopedEnvExtensionsRef.get
  let mut scopedNames : NameSet := {}
  for ext in exts do
    match ext.ext.getState env |>.stateStack with

    | top :: _ =>
      for ns in top.activeScopes.toList do
        scopedNames := scopedNames.insert ns
    | _ => pure ()

  return {
    varDecls := scope.varDecls.map fun stx => (stx.raw.reprint.getD "").trim,
    includeVars := scope.includedVars.toArray.map (·.eraseMacroScopes),
    omitVars := scope.omittedVars.toArray.map (·.eraseMacroScopes),
    levelNames := scope.levelNames.toArray,
    currNamespace := ← getCurrNamespace,
    -- 一般 open
    openDecl := ← getOpenDecls,
    -- 這裡現在會包含真正被 open scoped 的 "Function"
    scopedOpenDecl := scopedNames.toList.toArray
  }


def getScopeInfo2 : CommandElabM ScopeInfo := do
  let scope ← getScope
  -- 直接從 Syntax 中還原原始字串
  let varDecls := scope.varDecls.map fun stx =>
    match stx.raw.reprint with

    | some s => s.trim  -- 拿到如 "{ι ι' : Sort*} [LinearOrder α]"
    | none   => "(無法解析的語法)"
  -- 2. 提取命名空間：從 List OpenDecl 轉為 Array Name
  -- 使用完整的 Lean.OpenDecl 路徑以避免語法解析錯誤
  let openNames : Array Name := (scope.openDecls.map fun decl =>
    match decl with

    | Lean.OpenDecl.simple ns _   => ns
    | Lean.OpenDecl.explicit ns _ => ns
  ).toArray

  return {
    varDecls := varDecls,
    includeVars := scope.includedVars.toArray.map (·.eraseMacroScopes),
    omitVars := scope.omittedVars.toArray.map (·.eraseMacroScopes),
    levelNames := scope.levelNames.toArray,
    currNamespace := ← getCurrNamespace,
    -- 3. 現在型別完全匹配：Array Name
    openDecl := ← getOpenDecls,
    scopedOpenDecl := openNames
  }

def getConstructorInfo (stx : Syntax) : CommandElabM BaseDeclarationInfo := do
  let scopeInfo ← getScopeInfo
  let mut modifiers ← elabModifiers stx[2]
  if let some leadingDocComment := stx[0].getOptional? then
    modifiers := { modifiers with docString? := some ⟨leadingDocComment, false⟩ }
  let id := stx[3]
  let name := id.getId
  let (ref, signature) ← liftCoreM do pure (← PPSyntax.pp `command stx, ← PPSyntax.pp `term stx[4])
  return {
    kind := "constructor",
    ref,
    id,
    name,
    modifiers,
    signature,
    params := #[],
    type := none,
    value := none,
    scopeInfo,
  }

initialize nameCounterRef : IO.Ref (Std.HashMap Name Nat) ← IO.mkRef {}

initialize nameRangeRef : IO.Ref (Std.HashMap String String) ← IO.mkRef {}

def getNextGlobalName (baseName : Name) (range: Option String.Range): IO Name := do
  let rangeStart := match range with
  | some v => v.start
  | none   => 0
  let rangeName := s!"{baseName}.{rangeStart}"
  let rangeMap ← nameRangeRef.get
  let existName := rangeMap.get? rangeName |>.getD ""
  if existName == "" then
    let countMap ← nameCounterRef.get
    let currentIdx := countMap.get? baseName |>.getD 0

    let nextIdx := currentIdx + 1
    nameCounterRef.modify fun m => m.insert baseName nextIdx

    let nextName := s!"{baseName}_{nextIdx}"
    nameRangeRef.modify fun m => m.insert rangeName nextName

    return Name.mkSimple nextName
  else
    return Name.mkSimple existName

def getAnonymousInstanceName (stx : Syntax) : Name := Id.run do
  let term := stx[1]![4]![1]![1]!

  let clean (s : String) : String :=
    let chars := s.toList.filter (fun c => c.isAlphanum || c == '_')
    String.mk chars

  if term.getKind == ``Lean.Parser.Term.app then
    let className := clean (term[0]!.reprint.getD "")
    let mut typeNames := ""
    let args := term.getArgs
    for i in [1:args.size] do
      let rawArg := args[i]!.reprint.getD ""
      typeNames := typeNames ++ clean rawArg

    return Name.mkStr1 ("inst" ++ className ++ typeNames)
  else
    let fullRaw := clean (term.reprint.getD "")
    return Name.mkStr1 ("inst" ++ fullRaw)

/-- 手動實作 Lean 官方的實例命名邏輯 (對齊 Expr 層級)
def getRealInstanceName (classStx : Syntax) (typeStxs : Array Syntax) : CommandElabM Name := do
  liftTermElabM do
    -- 1. 將類別語法（如 SMul）轉為 Expr
    let classExpr ← elabTerm classStx none
    -- 2. 將所有型別參數語法（如 M, α →ₘ[μ] β）轉為 Expr
    let typeExprs ← typeStxs.mapM (fun stx => elabTerm stx none)

    -- 3. 獲取 Class 的純名稱 (例如 "SMul")
    let className := classExpr.getAppFn.constName?.map (·.eraseMacroScopes.toString) |>.getD "Unknown"

    -- 4. 遞迴獲取所有型別參數的頭部名稱 (例如 "M", "AEEqFun")
    let mut typeNames := ""
    for expr in typeExprs do
      -- getAppFn 會自動穿透應用程序，拿到最核心的常量名稱 (例如 AEEqFun)
      if let some n := expr.getAppFn.constName? then
        typeNames := typeNames ++ n.eraseMacroScopes.toString

    -- 5. 組合並清理字串 (移除點號等)
    let clean (s : String) : String :=
      String.mk (s.toList.filter (fun c => c.isAlphanum || c == '_'))

    return Name.mkStr1 ("inst" ++ clean className ++ clean typeNames)
-/
-- 範例用法：在你的 elabCommand 中調用
-- elab_rules : command
--   | `(instance : $cls $types*) => do
--     let realName ← getRealInstanceName cls types
--     logInfo s!"Lean's Real Name: {realName}"


def getDeclarationInfo (stx : Syntax) : CommandElabM DeclarationInfo := do
  let isDecl := stx.isOfKind ``Lean.Parser.Command.declaration
  let realStx := if stx.isOfKind ``Lean.Parser.Command.declaration && stx.getNumArgs > 1 then
    stx[1]
  else
    stx

  let kindStr := realStx.getKind.toString
   let normKind :=
    if kindStr.endsWith "structure" then "structure"
    else if kindStr.endsWith "definition" then "definition"
    else if kindStr.endsWith "theorem" then "theorem"
    else if kindStr.endsWith "inductive" then "inductive"
    else if kindStr.endsWith "instance" then "instance"
    else if kindStr.endsWith "abbrev" then "abbrev"
    else if kindStr.endsWith "axiom" then "axiom"
    else if kindStr.endsWith "classInductive" then "classInductive"
    else if kindStr.endsWith "example" then "example"
    else if kindStr.endsWith "opaque" then "opaque"
    else if kindStr.endsWith "proofWanted" then "proofWanted"
    else if kindStr.endsWith "constructor" then "constructor"
    else if kindStr.endsWith "recursor" then "recursor"
    else kindStr

  let modifiers ← elabModifiers stx[0]

  let name := (stx.find? (·.isIdent)).map (·.getId.eraseMacroScopes.toString) |>.getD "Unknown"

  let (sigStx, valueStx) :=
    if normKind == "instance" then
      if realStx.getNumArgs >= 6 then
        (realStx[4], realStx[5])
      else
        (realStx, Syntax.missing)

    else if normKind == "definition" || normKind == "theorem" || normKind == "opaque" then

      if realStx.getNumArgs >= 5 then
        (realStx[2], realStx[4])  --Open AI Codex request: realStx[realStx.getNumArgs - 1]
      else if realStx.getNumArgs >= 3 then
        (realStx[2], Syntax.missing)
      else
        (realStx, Syntax.missing)

    else if normKind == "abbrev" then

      if realStx.getNumArgs >= 5 then
        (realStx[2], realStx[4])
      else if realStx.getNumArgs == 4 then
        (realStx[2], realStx[3])
      else if realStx.getNumArgs == 3 then
        (realStx[2], Syntax.missing)
      else
        (realStx, Syntax.missing)
    else if normKind == "structure" then
      if realStx.getNumArgs >= 4 then
        (realStx[2], realStx[4])
      else if realStx.getNumArgs >= 3 then
        (realStx[2], Syntax.missing)
      else
        (realStx, Syntax.missing)

    else if normKind == "inductive" || normKind == "classInductive"  then
      if realStx.getNumArgs >= 4 then
        (realStx[3], Syntax.missing)
      else if realStx.getNumArgs >= 3 then
        (realStx[2], Syntax.missing)
      else
        (realStx, Syntax.missing)
    else if normKind == "axiom" then
        (realStx[2], Syntax.missing)
    else if normKind == "example" then
        (realStx[1], realStx[2])
    else
        (realStx, Syntax.missing)

  --if normKind == "structure" then
    --let _ ← IO.println s!"XXXX normKind: {normKind}, ealStx.getNumArgs: {realStx.getNumArgs}, sigStx: {sigStx}, valueStx: {valueStx}"
    --let _ ← IO.println s!"XXXX normKind: {normKind}, ealStx.getNumArgs: {realStx.getNumArgs}, realStx: {realStx}"

  let params ← if !sigStx.isMissing && sigStx.getNumArgs > 0 then
    let binders := sigStx[0]
    liftTermElabM do
      let args := binders.getArgs
      let res ← args.flatMapM fun arg => do
        let k := arg.getKind
        if k == ``Lean.Parser.Term.instBinder ||
           k == ``Lean.Parser.Term.explicitBinder ||
           k == ``Lean.Parser.Term.implicitBinder ||
           k == ``Lean.Parser.Term.strictImplicitBinder ||
            arg.isIdent then
          try  toBinderViews arg catch _ => pure #[]
        else if k == Lean.nullKind then
          let mut all := #[]
          for arg in stx.getArgs do
            all := all ++ (← toBinderViews arg)
          return all
        else
          pure #[]
      pure res
  else
    pure #[]

  let rawTypeSpec := if sigStx.getNumArgs > 0 then sigStx[sigStx.getNumArgs - 1] else Syntax.missing

  let typeSpec := if rawTypeSpec.isOfKind `null && rawTypeSpec.getNumArgs == 1 then
      rawTypeSpec[0]
    else
      rawTypeSpec

  let typeStx :=
    if typeSpec.getNumArgs > 1 then
      let firstChildPP := (typeSpec[0].reprint.getD "").trim
      if firstChildPP == ":" then
        typeSpec[1]
      else
        typeSpec
    else
      typeSpec

  let typeData : Option PPSyntax :=
    if typeStx.isMissing then none else
      some {
        original := typeStx.isOriginal,
        range := typeStx.getRange?,
        pp? := typeStx.reprint.map (·.trim)
      }

  let decl := stx[1]
  let currNS ← getCurrNamespace
  let rawId ← if normKind == "abbrev" ||
                 normKind == "definition" ||
                 normKind == "theorem" ||
                 normKind == "opaque" ||
                 normKind == "axiom" ||
                 normKind == "inductive" ||
                 normKind == "classInductive" ||
                 normKind == "structure" then
      let (id, _) := expandDeclIdCore decl[1]
      pure id
    else if normKind == "instance" then
      try
        let optInstDeclId := decl[3]
        if optInstDeclId.isNone then
          let rawName := getAnonymousInstanceName stx
          --let _ ← IO.println s!"XXXX rawName: {rawName}"
          let finalName ← liftIO $ getNextGlobalName rawName stx.getRange?
          pure finalName
        else
          let declIdNode := optInstDeclId[0]
          let (id, _) := expandDeclIdCore declIdNode
          pure id
      catch e =>
        pure (Name.mkSimple (s!"BADNAME"))
    else if normKind == "example" then
      pure `_example
    else
      pure Name.anonymous
  --let _ ← IO.println s!"XXXX  6 normKind: {normKind}"
  let fullName ← getFullname modifiers rawId
  --if s!"fullName".endsWith "leRec_succ_left" then
  --let _ ← IO.println s!"XXXX fullName: {fullName}, normKind: {normKind} getNumArgs: {realStx.getNumArgs}, realStx: {realStx}"

  let declValStx? : Option Syntax :=
    match extractDeclValForSelfCalls? valueStx with
      | some v => some v
      | none =>
          match findDeclVal? realStx with
            | some dv => extractDeclValForSelfCalls? dv
            | none    => none

  let selfRanges : Array String.Range :=
    match declValStx? with
    | some v => collectSelfCallRangesFromValue v rawId fullName
    | none   => #[]

  let extra? : Option DeclarationExtra :=
    some { selfCallRanges? := if selfRanges.isEmpty then none else some selfRanges }

  let valueData : Option PPSyntax :=
    if valueStx.isMissing || valueStx.isNone then none else
      some {
        original := valueStx.isOriginal,
        range := valueStx.getRange?,
        pp? := valueStx.reprint.map (·.trim)
      }

  let base : BaseDeclarationInfo := {
    kind := normKind,
    ref := {
      original := stx.isOriginal,
      range := stx.getRange?,
      pp? := stx.reprint.map (·.trim)
    },
    id := stx,
    name := fullName,
    modifiers := modifiers,
    signature := {
      original := sigStx.isOriginal,
      range := sigStx.getRange?,
      pp? := sigStx.reprint.map (·.trimRight)
    },
    params := params,
    type := typeData,
    value := valueData,
    scopeInfo := ← getScopeInfo,
    extra? := extra?
  }
  --let _ ← IO.println s!"XXXX  9 normKind: {normKind}"
  if normKind == "inductive" || kindStr == "Lean.Parser.Command.classInductive" then
    let ctors := if realStx.getNumArgs > 4 then
        realStx[4].getArgs.filter fun s => s.getKind == ``Lean.Parser.Command.ctor
      else #[]
    let constructors ← ctors.mapM fun ctor =>
      Analyzer.Process.Declaration.getConstructorInfo ctor
    return DeclarationInfo.ofInductive { toBaseDeclarationInfo := base, constructors }
  else
    return DeclarationInfo.ofBase base


initialize declRef : IO.Ref (Array DeclarationInfo) ← IO.mkRef #[]

def getLogPath : IO String := do
  let path? ← IO.getEnv "JIXIA_LOG_PATH"
  return path?.getD "jixia_json.log"

def handleDeclaration (stx : Syntax) : CommandElabM Unit := do
  let some pos := stx.getPos? | return ()
  let some endPos := stx.getTailPos? | return ()
  let name := (getDefName? stx).getD Name.anonymous
  let currentDecls ← liftIO <| declRef.get

  let existing? := currentDecls.find? fun d =>
    let b := d.toBaseDeclarationInfo
    let isSameStart := b.ref.range.map (·.start == pos) |>.getD false
    let isSameName  := b.name == name
    isSameStart && isSameName

  match existing? with
  | some oldDecl =>
      let oldEnd := oldDecl.toBaseDeclarationInfo.ref.range.map (·.stop) |>.getD 0
      if endPos > oldEnd then
        let info ← getDeclarationInfo stx
        declRef.modify fun a =>
          let filtered := a.filter fun d =>
            let b := d.toBaseDeclarationInfo
            let isSameStart := b.ref.range.map (·.start == pos) |>.getD false
            let isSameName  := b.name == name
            if isSameStart && isSameName then false else true
          filtered.push info
      else
        return ()
  | none =>
      let info ← try
        getDeclarationInfo stx
      catch e =>
        let msg ← e.toMessageData.toString
        let env ← getEnv
        let modName := env.mainModule.toString

        liftIO do
          let modRange := stx[0].getRange?
          let rangeStr := match modRange with
          | some r => s!"[{r.start.byteIdx}, {r.stop.byteIdx}]"
          | none   => "none"

          let logPath ← getLogPath
          let handle ← IO.FS.Handle.mk logPath IO.FS.Mode.append
          handle.putStrLn s!"[ERROR] getDeclarationInfo failed for {name}: {msg}"
          handle.putStrLn s!"[PROCESS_LOG] MODULE: {modName} | NAME: {name} | MOD_RANGE: {rangeStr}"
          handle.flush

        throwUnsupportedSyntax

      declRef.modify fun a => a.push info

  throwUnsupportedSyntax


def handleProofWanted (stx : Syntax) : CommandElabM Unit := do
  let mods := stx[0]; let name := stx[2]; let sig := stx[3]
  let stx' ← withRef stx `(command| $mods:declModifiers axiom $name $sig)
  Lean.Elab.Command.elabCommand stx'
  liftIO <| declRef.modify fun a =>
    if a.isEmpty then a
    else
      let lastIdx := a.size - 1
      a.modify lastIdx fun (info : DeclarationInfo) =>
        let base : BaseDeclarationInfo := info.toBaseDeclarationInfo
        let newBase : BaseDeclarationInfo := { base with kind := "proofWanted" }
        DeclarationInfo.ofBase newBase


def onLoad : CommandElabM Unit := do
  liftIO <| declRef.set #[]

  let declKind := ``Lean.Parser.Command.declaration
  modifyEnv fun env =>
    let env1 := commandElabAttribute.ext.addEntry env {
      key      := declKind,
      declName := ``handleDeclaration,
      value    := handleDeclaration
    }
    let env2 := commandElabAttribute.ext.addEntry env1 {
      key      := `proof_wanted,
      declName := ``handleProofWanted,
      value    := handleProofWanted
    }
    env2


def getResult : CommandElabM (Array DeclarationInfo) :=
  liftIO <| declRef.get

end Analyzer.Process.Declaration
