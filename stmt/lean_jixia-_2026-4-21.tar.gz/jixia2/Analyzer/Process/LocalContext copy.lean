/-
Copyright (c) 2024 BICMR@PKU. All rights reserved.
Released under the Apache 2.0 license as described in the file LICENSE.
Authors: Tony Beta Lambda
-/
import Lean
import Analyzer.Types

open Lean Elab Command

namespace Analyzer.Process.LocalContext


partial def findContextInfos (tree : InfoTree) : Array ContextEntryInfo :=
  match tree with

  | .context _ t => findContextInfos t
  | .node i children =>
    let stx := i.stx
    let kind := stx.getKind

    let isOriginal := match stx.getHeadInfo with | .original .. => true | _ => false

    let isTargetNamespace := (`Lean.Parser.Command).isPrefixOf kind
                          || (`Mathlib.Linter).isPrefixOf kind
                          || (`Mathlib.Command).isPrefixOf kind

    let ignoreList := [
      ``Lean.Parser.Command.declaration,
      ``Lean.Parser.Command.declId,
      ``Lean.Parser.Command.eoi,
      ``Lean.Parser.Command.moduleDoc,
      ``Lean.Parser.Command.end,
      ``Lean.Parser.Command.namespace,
      ``Lean.Parser.Command.section,
      `null,
      `Lean.Parser.Module.module
    ]

    if isTargetNamespace && !ignoreList.contains kind then
      let fullContent := (stx.reprint.getD "").trim
      let parts := fullContent.splitOn " in "
      let displayContent := if parts.length > 1 then parts.head! else fullContent
      #[{ kind := kind.toString, content := displayContent, range := stx.getRange? }]
    else
      -- 繼續搜尋子節點
      children.toArray.flatMap findContextInfos
  | _ => #[]


def getLocalContext (tree : InfoTree) : Array ContextEntryInfo :=
  let allEntries := findContextInfos tree
  allEntries.foldl (init := #[]) fun acc x =>
    if acc.any (fun y => y.range == x.range && y.kind == x.kind) then acc else acc.push x

def getResult : CommandElabM LocalContextInfo := do
  let trees := (← getInfoTrees).toArray
  let allContextInfos := trees.flatMap getLocalContext
  let localCtx := { contextEntries := allContextInfos }

  return localCtx

end Analyzer.Process.LocalContext
