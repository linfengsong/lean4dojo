import Lean
import Analyzer.Types

open Lean Elab Command

namespace Analyzer.Process.LocalContext

private def getExactContent (source : String) (stx : Syntax) : String :=
  match stx.getPos?, stx.getTailPos? with
  | some b, some e => (source.extract b e).trim
  | _, _           => (stx.reprint.getD "").trim

private def isTargetNamespace (kind : Name) : Bool :=
  kind == `Mathlib.Tactic.commandIrreducible_def
  || kind == `Lean.Parser.Command.attribute
  || (`Lean.Parser.Command).isPrefixOf kind
  || (`Mathlib.Linter).isPrefixOf kind
  || (`Mathlib.Command).isPrefixOf kind
  || (`Mathlib.Util.Notation3).isPrefixOf kind
  || kind == `Batteries.Tactic.Alias.alias
  || kind == `Batteries.Tactic.Alias.aliasLR
  --|| (`Mathlib.Tactic).isPrefixOf kind
  --|| (`Mathlib.Attr).isPrefixOf kind
  || kind == `Mathlib.Tactic.command_Irreducible_def____

private def isTopLevelCommand (kind : Name) : Bool :=
  (`Lean.Parser.Command).isPrefixOf kind ||
  (`Mathlib.Command).isPrefixOf kind ||
  kind.components.any (fun n => n.toString.startsWith "command")

private def ignoreList : List Name := [
  ``Lean.Parser.Command.declaration,
  ``Lean.Parser.Command.declId,
  ``Lean.Parser.Command.eoi,
  ``Lean.Parser.Command.moduleDoc,
  ``Lean.Parser.Command.end,
  ``Lean.Parser.Command.namespace,
  ``Lean.Parser.Command.section,
  `null,
  `Lean.Parser.Module.module
]

private def wantedMacroHeads : List String := [
  "notation3",
  "assert_not_imported",
  "assert_not_exists",
  "mk_iff_of_inductive_prop",
  "library_note2"
]

private def firstToken (s : String) : String :=
  let t := s.trim
  t.takeWhile (fun c => c != ' ' && c != '\n' && c != '\t')

private def isWantedMacroContent (content : String) : Bool :=
  wantedMacroHeads.contains (firstToken content)

private def cutAfterIn (s : String) : String :=
  let pieces :=
    (s.split (fun c => c = '\n' || c = '\t' || c = '\r'))
      |>.map String.trim
      |>.filter (fun t => !t.isEmpty)
  let flat := String.intercalate " " pieces
  match flat.splitOn " in " with
  | [] => flat
  | [one] => one
  | head :: _ => head ++ " in"

private def shouldKeep (stx : Syntax) (content : String) : Bool :=
  let kind := stx.getKind
  let hasPos := stx.getPos?.isSome && stx.getTailPos?.isSome

  if !hasPos then
    false
  else
    let isOriginal :=
      match stx.getHeadInfo with

      | .original .. => true
      | _ =>
        kind.components.any (fun n => n.toString.startsWith "Irreducible") ||
        (content.splitOn "irreducible_def").length > 1 ||
        kind.components.any (fun n => n.toString.startsWith "notation3") ||
        (content.splitOn "notation3").length > 1

    let isTarget := isTargetNamespace kind || isTopLevelCommand kind

    let keepOriginal :=
      isOriginal && isTarget && !ignoreList.contains kind

    let keepMacroExtra :=
      !ignoreList.contains kind && isWantedMacroContent content

    keepOriginal || keepMacroExtra

private def getEffectiveKind (stx : Syntax) : Name :=
  let k := stx.getKind
  -- If it's a generic wrapper, look at the first non-modifier child
  if k == ``Lean.Parser.Command.attribute || k == ``Lean.Parser.Command.declaration then
    let actualChild := stx.getArgs.find? fun arg =>
      let ak := arg.getKind
      ak != Name.anonymous &&
      ak != ``Lean.Parser.Command.visibility &&
      ak != ``Lean.Parser.Command.private
    actualChild.map (·.getKind) |>.getD k
  else
    k

partial def findContextInfos (source : String) (tree : InfoTree) : Array ContextEntryInfo :=
  match tree with
  | .context _ t => findContextInfos source t
  | .node i children =>
    let stx := i.stx
    let rawContent := getExactContent source stx
    let content :=
      if stx.getKind == ``Lean.Parser.Command.in then
        cutAfterIn rawContent
      else
        rawContent

    let self :=
      if shouldKeep stx content then
        let effectiveKind := getEffectiveKind stx
        let rawKindStr := effectiveKind.toString
        -- 簡化 Kind 名稱，讓 JSON 輸出更乾淨
        let cleanKind :=
          if (rawKindStr.splitOn "Irreducible").length > 1 then
            "irreducible_def"
          else if (rawKindStr.splitOn "declaration").length > 1 then
            "declaration"
          else
            rawKindStr

        #[{
          kind := cleanKind
          content := content
          range := stx.getRange?
        }]
      else
        #[]

    self ++ children.toArray.flatMap (findContextInfos source)
  | _ => #[]

def getLocalContext (source : String) (tree : InfoTree) : Array ContextEntryInfo :=
  let allEntries := findContextInfos source tree
  allEntries.foldl (init := #[]) fun acc x =>
    if acc.any (fun y => y.range == x.range && y.kind == x.kind) then acc else acc.push x

def getResult : CommandElabM LocalContextInfo := do
  let fm ← getFileMap
  let source := fm.source
  let trees := (← getInfoTrees).toArray

  let allContextInfos := trees.flatMap (getLocalContext source)
  let allContextInfos := allContextInfos.qsort (fun a b =>
    match a.range, b.range with
    | some ra, some rb => ra.start < rb.start
    | some _, none => true
    | none, some _ => false
    | none, none => false
  )
  return { contextEntries := allContextInfos }

end Analyzer.Process.LocalContext
