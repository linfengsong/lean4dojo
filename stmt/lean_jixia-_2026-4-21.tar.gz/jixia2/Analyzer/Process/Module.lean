/-
Copyright (c) 2024 BICMR@PKU. All rights reserved.
Released under the Apache 2.0 license as described in the file LICENSE.
Authors: Tony Beta Lambda
-/
import Lean
import Analyzer.Types

open Lean Elab Command

namespace Analyzer.Process.Module

partial def findScopeRanges (tree : InfoTree) : Array ScopeRangeInfo :=
  match tree with

  | .context _ t => findScopeRanges t
  | .node i children =>
    let childResults := children.toArray.flatMap findScopeRanges

    match i with

    | .ofCommandInfo val =>
      let stx := val.stx
      let kind := stx.getKind

      -- 【核心修正 1】過濾非原始指令 (排除 Macro 內部生成的 namespace)
      let isOriginal := match stx.getHeadInfo with | .original .. => true | _ => false

      if isOriginal then
        -- 偵測開始標籤
        if kind == ``Lean.Parser.Command.section || kind == ``Lean.Parser.Command.namespace then
          let normKind := if kind == ``Lean.Parser.Command.section then "section" else "namespace"

          -- 【核心修正 2】只提取識別碼的名字，不 reprint 整個指令
          let name := match stx.find? (·.isIdent) with

            | some (Syntax.ident _ _ id _) => id.toString
            | _ => "anonymous"

          let sect := {
            kind := normKind,
            name := name.trim,
            range := stx.getRange?
          }
          -- 既然是頂層指令，我們回傳 [當前節點] + 子節點結果
          #[sect] ++ childResults

        -- 偵測結束標籤
        else if kind == ``Lean.Parser.Command.end then
          -- 重要：end 指令即便沒有 ident，其本身也是有 Range 的
          let name := match stx.find? (·.isIdent) with

            | some (Syntax.ident ..) => stx.reprint.getD "anonymous"
            | _ => "anonymous" -- 這是無名 end (單純的 `end`)

          let sect := {
             kind := "end",
             name := name.trim,
             range := stx.getRange? -- 這會拿到 `end` 關鍵字所在的精確位置
          }
          childResults.push sect -- 放在最後，確保順序正確
        else childResults
      else childResults -- 非 Original 指令直接跳過，解決問題 1

    | _ => childResults
  | _ => #[]

def getResult : CommandElabM ModuleInfo := do
  let env ← getEnv
  let trees := (← getInfoTrees).toArray
  let imports := env.header.imports.map fun i => i.module
  let scopeRangeInfos := trees.flatMap findScopeRanges
  let docstring := getMainModuleDoc env |>.toArray |>.map fun d => d.doc
  return {
    imports,
    scopeRangeInfos,
    docstring,
  }

end Analyzer.Process.Module
