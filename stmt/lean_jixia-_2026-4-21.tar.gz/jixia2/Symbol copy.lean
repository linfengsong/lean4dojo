/-
Copyright (c) 2024 BICMR@PKU. All rights reserved.
Released under the Apache 2.0 license as described in the file LICENSE.
-/
import Lean
import Analyzer.Types
import Analyzer.Process.Common

open Lean Elab Term Command Frontend Parser
open Std (HashSet)

namespace Analyzer.Process.Symbol

/-- 引用資訊結構 -/
structure InfoReference where
  name  : Name
  srcName : String --source name
  range : String.Range
  isCallHead : Bool := false --whether source token is followed by (
  binderCount : Nat := 0 -- total binders of resolved constant type.
  explicitArgCount : Nat := 0 -- explicit binders count.
  namespacePrefixSafe : Bool := true -- final decision for auto-prefixer.
  namespacePrefixReason : Option String := none -- e.g. "implicit-only callable".
  deriving Inhabited, Repr

/-- 取 source 中 range 對應文字 -/
def sliceByRange (input : String) (r : String.Range) : String :=
  input.extract r.start r.stop


partial def binderInfos (ty : Expr) : List BinderInfo :=
  match ty with
  | .forallE _ _ body bi => bi :: binderInfos body
  | _ => []

def binderCount (ty : Expr) : Nat :=
  (binderInfos ty).length

def explicitArgCount (ty : Expr) : Nat :=
  (binderInfos ty).foldl (init := 0) fun n bi =>
    if bi.isExplicit then n + 1 else n

def firstBinderImplicit (ty : Expr) : Bool :=
  match binderInfos ty with
  | [] => false
  | bi :: _ => !bi.isExplicit

/-- safer generic rule for auto-prefixing -/
def computePrefixSafety (isCallHead : Bool) (ci : ConstantInfo) :
    Nat × Nat × Bool × Option String :=

  let b := binderCount ci.type
  let e := explicitArgCount ci.type
  let firstImpl := firstBinderImplicit ci.type

  let implicitOnlyUnsafe := isCallHead && b > 0 && e == 0
  let leadingImplicitUnsafe := isCallHead && firstImpl

  let unsafeFlag := implicitOnlyUnsafe || leadingImplicitUnsafe
  let reason :=
    if implicitOnlyUnsafe then some "implicit-only callable"
    else if leadingImplicitUnsafe then some "leading implicit binder"
    else none

  (b, e, !unsafeFlag, reason)

def enrichRefsWithSafety (env : Environment) (refs : Array InfoReference) : Array InfoReference :=
  refs.map fun ref =>
    match env.find? ref.name with
    | none =>
      if ref.isCallHead then
        { ref with
          namespacePrefixSafe := false
          namespacePrefixReason := some "unresolved call-head"
        }
      else
        ref
    | some ci =>
      let (b, e, safe, reason) := computePrefixSafety ref.isCallHead ci
      { ref with
        binderCount := b
        explicitArgCount := e
        namespacePrefixSafe := safe
        namespacePrefixReason := reason
      }

/-- 輔助：格式化表達式 (解決 ppType 未定義問題) -/
def ppType (type : Expr) : MetaM (Option String) :=
  tryCatchRuntimeEx (do
    let format ← PrettyPrinter.ppExpr type |>.run'
    pure <| some format.pretty
  ) (fun _ => pure none)

/-- Is `nm` the function head of parent application expression? -/
def isHeadConstOfParentApp (parentExpr? : Option Expr) (nm : Name) : Bool :=
  match parentExpr?.map Expr.consumeMData with
  | some p =>
    if p.isApp then
      match p.getAppFn.consumeMData with
      | .const fn _ => fn == nm
      | _ => false
    else
      false
  | none => false

/-- 深度遍歷 InfoTree 並去重，只抓取最細顆粒度的引用 -/
partial def collectInfoRefs (input : String) (tree : InfoTree) : Array InfoReference :=
  go none tree |>.foldl (init := #[]) fun acc x =>
    if acc.any (fun y => y.range == x.range && y.name == x.name) then acc else acc.push x
where
  go (parentExpr? : Option Expr) (tree : InfoTree) : Array InfoReference :=
    match tree with
    | .context _ t => go parentExpr? t

    | .node info children =>
      -- current expression for passing down to children
      let currentExpr? : Option Expr :=
        match info with
        | .ofTermInfo ti => some ti.expr.consumeMData
        | _ => parentExpr?

      let childRefs := children.foldl (fun acc c => acc ++ go currentExpr? c) #[]

      match info with
      | .ofTermInfo ti =>
        match ti.expr.consumeMData, ti.stx.getRange? with
        | .const name _, some r =>
          if childRefs.any (fun c => c.range == r) then
            childRefs
          else
            let src := sliceByRange input r
            let callHead := isHeadConstOfParentApp parentExpr? name
            childRefs.push {
              name := name
              srcName := src
              range := r
              isCallHead := callHead
            }
        | _, _ => childRefs

      | _ => childRefs

    | _ => #[]

/-- 核心：提取符號資訊並進行範圍過濾 -/
def getSymbolInfo (name : Name) (info : ConstantInfo) (allRefs : Array InfoReference) : TermElabM SymbolInfo := do
  let kind := match info with

    | .axiomInfo _ => .«axiom»
    | .defnInfo _ => .definition
    | .thmInfo _ => .«theorem»

    | .opaqueInfo _ => .«opaque»
    | .quotInfo _ => .«quotient»
    | .inductInfo _ => .«inductive»

    | .ctorInfo _ => .constructor
    | .recInfo _ => .recursor

  let type := info.toConstantVal.type
  let typeFull ← ppType type
  let typeReadable ← ppType type
  let typeFallback := type.dbgToString
  let isProp := (match info with | .thmInfo _ => true | _ => false)

  let fileMap ← getFileMap
  let input := fileMap.source
  let declRange? ← Lean.findDeclarationRanges? name

  let toLspPos (p : Lean.Position) : Lean.Lsp.Position :=
    { line := p.line - 1, character := p.column }

  let mut typeReferences : Array SymbolRef := #[]
  let mut valueReferences : Array SymbolRef := #[]

  if let some dr := declRange? then
    -- 定理定義的總起始與總結束 (byte offsets)
    let start := fileMap.lspPosToUtf8Pos (toLspPos dr.range.pos)
    let stop  := fileMap.lspPosToUtf8Pos (toLspPos dr.range.endPos)

    -- 定理名稱結束位置，用於區分 Statement (Type) 和 Proof (Value)
    let nameEnd := fileMap.lspPosToUtf8Pos (toLspPos dr.selectionRange.endPos)

    -- 🔍 關鍵修正：尋找真正的 Value 起始位置
    let fullDeclText := sliceByRange input { start := start, stop := stop }

    -- 輔助函數：手動尋找子字串位置
    let findPos (sub : String) : Option String.Pos :=
      let parts := fullDeclText.splitOn sub
      if parts.length > 1 then
        -- 第一段的長度（Byte Size）就是子字串起始的偏移量
        some ⟨(parts[0]!).utf8ByteSize⟩
      else
        none

    let _valueStart : String.Pos :=
      if let some pos := findPos ":=" then
        ⟨start.byteIdx + pos.byteIdx⟩
      else if let some pos := findPos "where" then
        ⟨start.byteIdx + pos.byteIdx⟩
      else
        match info with

        | .inductInfo _ | .axiomInfo _ | .quotInfo _ => stop
        | _ => nameEnd

    let myRefs := allRefs.filter fun ref =>
      ref.range.start >= start && ref.range.stop <= stop


    for ref in myRefs do
      -- 排除掉定理本身的名字
      if ref.name == name then continue

      let outRef : Analyzer.SymbolRef := {
        name := ref.name
        srcName := ref.srcName
        range := some ref.range
        isCallHead := ref.isCallHead
        binderCount := ref.binderCount
        explicitArgCount := ref.explicitArgCount
        namespacePrefixSafe := ref.namespacePrefixSafe
        namespacePrefixReason := ref.namespacePrefixReason
      }

      if ref.range.start < nameEnd then
        typeReferences := typeReferences.push outRef
      else
        valueReferences := valueReferences.push outRef

  return {
    kind, name, typeFull, typeReadable, typeFallback,
    typeReferences,
    valueReferences := some valueReferences,
    isProp
  }

/-- 執行指令循環以產生 InfoTree -/
def runFrontendLoop (ictx : Frontend.Context) (s : Frontend.State) : IO Frontend.State := do
  -- 使用 StateRefT 的 run 模式，這通常能避開類型不匹配
  let (_, s') ← (Frontend.processCommands).run ictx |>.run s
  pure s'

def getResult (path : System.FilePath) : IO (Array SymbolInfo) := do
  let sysroot ← findSysroot
  let ssp := (← getSrcSearchPath) ++ [sysroot / "src" / "lean"]
  let module := (← searchModuleNameOfFileName path ssp).get!

  let input ← IO.FS.readFile path
  let inputCtx := Parser.mkInputContext input path.toString
  let (header, parserState, messages) ← Parser.parseHeader inputCtx
  let (env, messages) ← processHeader header .empty messages inputCtx

  let ictx : Frontend.Context := { inputCtx := inputCtx }
  let s : Frontend.State := {
    commandState := {
      Command.mkState env messages .empty with
      infoState.enabled := true
    },
    parserState := parserState,
    cmdPos      := parserState.pos
  }

  let s' ← runFrontendLoop ictx s

  let mut allRefs := #[]
  for tree in s'.commandState.infoState.trees do
    allRefs := allRefs ++ collectInfoRefs input tree

  let finalEnv := s'.commandState.env
  allRefs := enrichRefsWithSafety finalEnv allRefs
  let index := finalEnv.allImportedModuleNames.idxOf? module

  let config : Core.Context := {
    fileMap := inputCtx.fileMap,
    fileName := path.toString
  }

  let f a name info := do
    if finalEnv.getModuleIdxFor? name != index then return a
    let (si, _, _) ← getSymbolInfo name info allRefs |>.run' |>.toIO config { env := finalEnv }
    return a.push si

  let a ← finalEnv.constants.map₁.foldM f #[]
  finalEnv.constants.map₂.foldlM f a

end Analyzer.Process.Symbol
