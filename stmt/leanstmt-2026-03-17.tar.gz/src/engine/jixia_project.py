from dataclasses import dataclass, field
from jixia import LeanProject
from jixia.structs import Symbol,Declaration,InfoTree
from .module import ModuleData,SymbolData,DeclarationData,InfoTreeData,ModuleTreeData,ProjectData, to_lean_ident

@dataclass
class JixiaProjectData(ProjectData):
    working_dir: str
    json_dir: str = ".jixia"
    project: LeanProject = field(init=False, repr=False)

    def __post_init__(self):
        self.project = LeanProject(self.working_dir, self.json_dir)

    def loadModuleTree(self, module_name):
        module = self.project.load_module_info(module_name)
        if module is None:
            return None
        
        #write_lean(project, module_name, output_dir)
        symbols = self.project.load_info(module_name, Symbol)
        decls = self.project.load_info(module_name, Declaration)
        infoTrees = self.project.load_info(module_name, InfoTree)

        no_marcor_decls = []
        for decl in decls:
            if "_aux_" in to_lean_ident(decl.name) and "___macroRules_" in to_lean_ident(decl.name):
                pass #print(f"Jixia remove macro decl: {decl.name}")
            elif "_aux_" in to_lean_ident(decl.name) and "___elabRules_" in to_lean_ident(decl.name):
                pass
            elif "_aux_" in to_lean_ident(decl.name) and "__delab_" in to_lean_ident(decl.name):
                pass
            elif "_aux_" in to_lean_ident(decl.name) and "___unexpand_" in to_lean_ident(decl.name):
                pass
            elif "._@." in to_lean_ident(decl.name) and "._hyg." in to_lean_ident(decl.name):
                pass
            elif "inst" in to_lean_ident(decl.name) and decl.ref is not None and decl.ref.original == False:
                pass
            else:
                no_marcor_decls.append(decl)

        mooduleTreeData = ModuleTreeData(
            ModuleData.create(module),
            [SymbolData.create(symbol) for symbol in symbols],
            [DeclarationData.create(decl) for decl in no_marcor_decls],
            [InfoTreeData.create(infoTree) for infoTree in infoTrees]
        )

        return mooduleTreeData
