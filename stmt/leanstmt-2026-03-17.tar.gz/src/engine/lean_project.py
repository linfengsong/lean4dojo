from dataclasses import dataclass
import msgspec
import logging
from pathlib import Path
from .structs import LeanModuleInfo,LeanSymbol,LeanDeclaration,LeanInfoTree
from .module import ModuleData,SymbolData,DeclarationData,InfoTreeData,ModuleTreeData,ProjectData,to_lean_ident

@dataclass
class LeanProjectData(ProjectData):
    working_dir: str
    json_dir: str = ".jixia"

    def loadModuleTree(self, module_name, raise_exception: bool = True):
        module = self.load_info(module_name, "mod", LeanModuleInfo)
        if module is None:
            return None
        
        try:
            #write_lean(project, module_name, output_dir)
            symbols = self.load_info(module_name, "sym", list[LeanSymbol])
            decls = self.load_info(module_name, "decl", list[LeanDeclaration])
            infoTrees = self.load_info(module_name, "elab", list[LeanInfoTree])

            no_macor_decls = []
            for decl in decls:
                if "_aux_" in to_lean_ident(decl.name) and "___macroRules_" in to_lean_ident(decl.name):
                    pass #print(f"Jixia remove macro decl: {decl.name}")
                elif "_aux_" in to_lean_ident(decl.name) and "___elabRules_" in to_lean_ident(decl.name):
                    pass
                elif "_aux_" in to_lean_ident(decl.name) and "__delab_" in to_lean_ident(decl.name):
                    pass
                elif "_aux_" in to_lean_ident(decl.name) and "___unexpand_" in to_lean_ident(decl.name):
                    pass #print(f"Lean remove macro decl: {decl.name}")
                elif "._@." in to_lean_ident(decl.name) and "._hyg." in to_lean_ident(decl.name):
                    pass
                elif "inst" in to_lean_ident(decl.name) and decl.ref is not None and decl.ref.original == False:
                    pass
                else:
                    no_macor_decls.append(decl)

            mooduleTreeData = ModuleTreeData(
                ModuleData.create(module),
                [SymbolData.create(symbol) for symbol in symbols],
                [DeclarationData.create(decl) for decl in no_macor_decls],
                [InfoTreeData.create(infoTree) for infoTree in infoTrees]
            )

            return mooduleTreeData
        except Exception as e:
            if raise_exception:
                raise Exception(f"Lean Fail to load json for {module_name}: {e}")
            else:
                logging.info(f"Lean Fail to load json for {module_name}: {e}")
                return None
        
    
    def load_info(self, module_name, type, objType):
        module_id = to_lean_ident(module_name)
        filename = f"{module_id}.{type}.json"
        with(Path(self.working_dir) / Path(self.json_dir) / Path(filename)).open(encoding='utf-8') as fp:
            raw_json = fp.read()
            
            return msgspec.json.decode(raw_json, type=objType)

