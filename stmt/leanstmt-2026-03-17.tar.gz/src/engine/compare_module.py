import os
import io
import argparse
from datetime import datetime
from typing import Any, Dict, Optional
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm
from dataclasses import dataclass, is_dataclass, fields
from dataclasses_json import dataclass_json
from .jixia_project import JixiaProjectData
from .lean_project import LeanProjectData
from .util import collect_match_modules
from .module import dataclass_field_values


@dataclass_json
@dataclass
class Diff:
    path: str = None
    name: str = None
    old: Any = None
    new: Any = None
    parent_old: Any = None
    parent_new: Any = None
    len_set_diff = 0
    old_decl_set = []
    new_decl_set = []

    @classmethod
    def create(cls, path, name, old, new, parent_old, parent_new, diff_detail):
        if diff_detail > 0:
            return cls (
                path = path,
                name = name,
                old = old,
                new = new,
                parent_old = parent_old,
                parent_new = parent_new,
            )
        else:
            num_cut = 200
            return cls (
                path = path,
                name = name,
                old = f"{old}"[:num_cut],
                new = f"{new}"[:num_cut],
                parent_old = f"{parent_old}"[:num_cut],
                parent_new = f"{parent_new}"[:num_cut],          
            )
        
def createListData(list: list) -> list:
    if len(list) == 0:
        return []
    if hasattr(list[0], "name"):
        out_list = []
        for item in list:
            item_name = getattr(item, "name")
            out_list.append(item_name)
        return out_list
    else:
        return list

def find_first_mismatch_detail(name1:str, fname, list1: list, name2: str, list2: list, diff_detail: int = 0, path: str = "") -> Optional[Dict[str, Any]]:
    obj1 = list1[0]
    obj2 = list2[0]
    # 1. 處理類型不一致
    if type(obj1) is not type(obj2):
        return Diff.create(
            path=path if path else "root",
            name=fname,
            old=obj1,
            new=obj2,
            parent_old=list1[diff_detail],
            parent_new=list2[diff_detail],
            diff_detail=diff_detail
            )

    # 2. 處理 Dataclass
    if is_dataclass(obj1):
        for f in fields(obj1):
            if f.name == "parent":
                continue
            current_path = f"{path}.{f.name}" if path else f.name
            v1, v2 = dataclass_field_values(f, obj1, obj2)
            res = find_first_mismatch_detail(name1, f.name, [v1, *list1], name2, [v2, *list2], diff_detail, current_path)
            if res: return res
        return None

    # 3. 處理列表 (List)
    if isinstance(obj1, list):
        if len(obj1) != len(obj2):
            return Diff.create(
                path=path if path else "root",
                name=fname,
                old=len(obj1),
                new=len(obj2),
                parent_old=createListData(obj1),
                parent_new=createListData(obj2),
                diff_detail=diff_detail
            )
        for i, (item1, item2) in enumerate(zip(obj1, obj2)):
            item_name = ""
            if hasattr(item1, "name"):
                item_name = getattr(item1, "name")
            res = find_first_mismatch_detail(name1, f"{fname},{item_name}", [item1, *list1], name2, [item2, *list2], diff_detail, f"{path}[{i}, {item_name}]")
            if res: return res
        return None

    # 4. 基本數值或其它類型比較
    if obj1 != obj2:
        return Diff.create(
            path=path if path else "root",
            name=fname,
            old=obj1,
            new=obj2,
            parent_old=list1[diff_detail],
            parent_new=list2[diff_detail],
            diff_detail=diff_detail
        )

    return None

def print_diff(label, module_name, diff, prefect, file=None):
    if diff is None:
        return 0
    try:
        if prefect:
            
            str = diff.to_json(indent=2, ensure_ascii=False)
        else:
            str = f"    {diff.to_json(ensure_ascii=False)}"
    except Exception as e:
        print(f"EXCEPTION: Fail to convert to json {e}")
        str = f"    {diff}"
    print(f"module_name {module_name} is different on {label}", file=file)
    print(str, file=file)
    return 1

def sync_jixia_lean_data(jixia_data, lean_data):
    jixia_names_set = {decl.compare_key() for decl in jixia_data.decls}

    lean_data.decls = [
        decl for decl in lean_data.decls
        if decl.compare_key() in jixia_names_set 
    ]
    lean_names_set = {decl.compare_key() for decl in lean_data.decls}

    jixia_data.decls = [
        decl for decl in jixia_data.decls 
        if decl.compare_key() in lean_names_set or not (".inst" in decl.name or decl.name.startswith("inst"))
    ]
    jixia_names_list = [decl.compare_key() for decl in jixia_data.decls]
    lean_names_list = [decl.compare_key() for decl in lean_data.decls]
    return jixia_names_list, lean_names_list

def compare_module_worker(jixia_project_args, lean_project_args, module_name, diff_detail, prefect):
    jixia_project = JixiaProjectData(*jixia_project_args)
    lean_project = LeanProjectData(*lean_project_args)
    
    output = io.StringIO()
    diff_count = 0
    jixia_label = "old"
    lean_label = "new"
    
    try:
        jixia_data = jixia_project.loadModuleTree(module_name)
        lean_data = lean_project.loadModuleTree(module_name)
        
        if jixia_data is None:
            return f"Module {module_name} missing Jixia data.\n", 1
        if lean_data is None:
            return f"Module {module_name} missing Lean data.\n", 1
        
        jixia_names_list, lean_names_list = sync_jixia_lean_data(jixia_data, lean_data)

        #for attr in ["module", "symbols", "decls", "infoTrees"]:
        for attr in ["module", "symbols", "decls"]:
            v1 = getattr(jixia_data, attr)
            v2 = getattr(lean_data, attr)
            if v1 != v2:
                diff = find_first_mismatch_detail(jixia_label, "root", [v1, jixia_data], 
                                                  lean_label, [v2, lean_data], diff_detail)
                #if diff_detail > 0:
                #    diff.len_set_diff = len(jixia_names_list) - len(lean_names_list)
                #    diff.old_decl_set = {key for key in jixia_names_list if not key in lean_names_list}
                #    diff.new_decl_set = {key for key in lean_names_list if not key in jixia_names_list}
                diff_count += print_diff(attr, module_name, diff, prefect, file=output)
        
        return output.getvalue(), diff_count
    except Exception as e:
        return f"EXCEPTION: Fail to compare module: {module_name} - {str(e)}\n", 1

def process_searches(working_dir: str, lean_json_dir: str, jixia_json_dir: str,
                     search_list: list[str], exclude_list: list[str], 
                     diff_detail: int, log_json_perfect: bool,
                     log_mode: str, output_dir: str, max_workers: int = 4):
    if not output_dir.startswith("/"):
        output_dir = os.path.join(working_dir, output_dir)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_name = f"diff_{timestamp}.log"
    log_path = os.path.join(output_dir, file_name)

    print(f"Working_dir: {working_dir}")
    print(f"Comparing: jixia_project: {jixia_json_dir}, lean_project: {lean_json_dir}")
    print(f"Search List: {search_list}")
    print(f"Exclude List: {exclude_list}")
    print(f"Log Mode: {log_mode}, Diff Detail: {diff_detail}, Log Json Prefect: {log_json_perfect}")
    print(f"Task start. Logs write to {log_path}")

    with open(log_path, "w", encoding="utf-8") as f:
        jixia_project = JixiaProjectData(working_dir, json_dir=jixia_json_dir)
        #lean_project = LeanProjectData(working_dir, json_dir=lean_json_dir)

        f.write(f"\n{'='*80}\n")
        f.write(f"Run Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        print(f"Working_dir: {working_dir}", file=f)
        print(f"Comparing: jixia_project: {jixia_json_dir}, lean_project: {lean_json_dir}", file=f)
        print(f"Search List: {search_list}", file=f)
        print(f"Exclude List: {exclude_list}", file=f)
        print(f"Log Mode: {log_mode}, Diff Detail: {diff_detail}, Log Json Perfect: {log_json_perfect}", file=f)
        f.flush()

        jixia_modules = []
        for search in search_list:
            jixia_modules.extend(collect_match_modules(jixia_project, search, exclude_list))

        j_args = (working_dir, jixia_json_dir)
        l_args = (working_dir, lean_json_dir)

        #lean_modules = []
        #for search in search_list:
        #    lean_modules.extend(collect_match_modules(lean_project, search, exclude_list))

        total_diffs = 0
        with ProcessPoolExecutor(max_workers=max_workers) as executor:
            futures = {
                executor.submit(compare_module_worker, j_args, l_args, m_name, diff_detail, log_json_perfect): m_name
                for m_name in jixia_modules
            }
            for future in tqdm(as_completed(futures), total=len(futures), desc="Comparing Modules"):
                result_str, count = future.result()
                if result_str:
                    f.write(result_str)
                    f.flush()
                total_diffs += count
        f.write(f"\n{'='*80}\nTotal Differences Found: {total_diffs}\n")
        
        print(f"Task finished. Total Difference: {total_diffs}, Detail logs at: {log_path}")

def main():
    parser = argparse.ArgumentParser(description="Python Code Implementation Helper for Project Comparison")
    
    # 定義輸入參數
    parser.add_argument("--working_dir", type=str, default="/home/linfe/math/lean_test", help="Target working directory")
    parser.add_argument("--lean_json_dir", type=str, default=".jixia", help="Lean Json directory")
    parser.add_argument("--jixia_json_dir", type=str, default=".jixia.v4.24.0", help="Jixia Json directory")
    parser.add_argument("--search_list", type=str, default="", help="Comma separated modules to search (e.g. 'Init,Mathlib')")
    parser.add_argument("--exclude_list", type=str, default="", help="Comma separated modules to exclude")
    parser.add_argument("--log_mode", type=str, choices=["Info", "Debug"], default="Info", help="Log detail mode")
    parser.add_argument("--detail_level", type=int, default=0, help="Detail level for difference")
    parser.add_argument("--log_json_perfect", type=bool, default=False, help="Json perfect format for difference")
    parser.add_argument("--output_dir", type=str, default=".logs", help="Directory to save timestamped logs")
    parser.add_argument("--max_workers", type=int, default=os.cpu_count(), help="Number of parallel processes")

    args = parser.parse_args()

    # 處理逗號分隔的列表
    search_list = [s.strip() for s in args.search_list.split(",") if s.strip()]
    exclude_list = [e.strip() for e in args.exclude_list.split(",") if e.strip()]

    if len(search_list) == 0:
        search_list = [
            "Init",
            "Mathlib",
            "LeanTest" # need replace by lean project configuration
        ]


    if len(exclude_list) == 0:
        exclude_list = [
            "Init.WF",
            "Init.Meta.Defs",
            'Mathlib.Data.Prod.Basic',

            "Mathlib.Tactic.CC.Addition",
            "Mathlib.Tactic.Simps.Basic",
            "Mathlib.Lean.Meta.CongrTheorems",
            "Mathlib.Util.Notation3"
        ]

    
    process_searches(
        args.working_dir,
        args.lean_json_dir, 
        args.jixia_json_dir, 
        search_list, 
        exclude_list, 
        args.detail_level,
        args.log_json_perfect,
        args.log_mode, 
        args.output_dir
    )

if __name__ == "__main__":
    main()

    # detail:
    # --log_mode Debug
    # --log_json_perfect True --diff_detail 2 
    
    #Test cases:
    # --search_list "Init.Try"
    # --search_list "Init.Data.Cast"
    # --search_list "Mathlib.MeasureTheory"
    # --search_list "Mathlib.MeasureTheory.SetAlgebra"
    # --search_list "Mathlib.MeasureTheory.PiSystem"
    # --search_list "Mathlib.MeasureTheory.Constructions.SubmoduleQuotient"
    # --search_list "Mathlib.MeasureTheory.Constructions.Projective"
    # --search_list "Mathlib.MeasureTheory.OuterMeasure.Basic"
    # --search_list "Mathlib.MeasureTheory.Function.AEEqFun"
    # --search_list "Mathlib.MeasureTheory.Constructions.BorelSpace.Basic"
    # --search_list "Mathlib.MeasureTheory.Function.AEEqFun.DomAct"
    # --search_list Mathlib.Tactic.Hint
    # --search_list Mathlib.GroupTheory.GroupAction.Primitive
    
    #example to run:
    # python -m engine.compare_module --detail_level=2 --log_json_perfect True --search_list Mathlib.GroupTheory.GroupAction.Primitive 

    # python -m engine.compare_module --search_list  "Init.Try,Init.Data.Cast,Mathlib.MeasureTheory.SetAlgebra,Mathlib.MeasureTheory.PiSystem,Mathlib.MeasureTheory.Constructions.SubmoduleQuotient,Mathlib.MeasureTheory.Constructions.Projective,Mathlib.MeasureTheory.OuterMeasure.Basic,Mathlib.MeasureTheory.Function.AEEqFun,Mathlib.MeasureTheory.Constructions.BorelSpace.Basic,Mathlib.MeasureTheory.Function.AEEqFun.DomAct,Mathlib.Tactic.Hint,Mathlib.Tactic.Widget.LibraryRewrite,Mathlib.Tactic.Widget.Calc,Mathlib.Data.Nat.Init"

    # python -m engine.compare_module --search_list Mathlib.Order.DirectedInverseSystem
    # python -m engine.compare_module --search_list Mathlib.CategoryTheory.Limits.HasLimits --detail_level 2 --log_json_perfect True

    # python -m engine.compare_module --search_list Mathlib.Util.Export,Mathlib.Util.MemoFix --detail_level 3 --log_json_perfect True

    # python -m engine.compare_module --search_list Mathlib.Algebra.Category.CommAlgCat.Monoidal --detail_level 2 --log_json_perfect True

    # python -m engine.compare_module --search_list Mathlib.CategoryTheory.Limits.HasLimits --detail_level 2 --log_json_perfect True

    # python -m engine.compare_module --search_list Mathlib.Topology.ContinuousMap.Bounded.Normed --detail_level 3 --log_json_perfect True
