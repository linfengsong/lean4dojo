from typing import Optional, Self, Any
from dataclasses import dataclass, fields, field
from dataclasses_json import dataclass_json, config
from jixia.structs import (
    Modifiers, ModuleInfo, PPSyntax, Param, Symbol, Declaration, StringRange, 
    InfoTree, OpenDecl, ScopeInfo, PPSyntaxWithKind,
    Variable,SpecialValue,TermElabInfo,Goal,TacticElabInfo,ElabInfo
)
from ...core.structs import (
    LeanModifiers, LeanModuleInfo, LeanPPSyntax, LeanParam, LeanSymbol, LeanDeclaration, LeanStringRange, 
    LeanInfoTree, LeanOpenDecl, LeanOpenDeclSimple, LeanOpenDeclRename, LeanScopeInfo, LeanPPSyntaxWithKind,
    LeanVariable, LeanSpecialValue, LeanTermElabInfo, LeanGoal, LeanTacticElabInfo, LeanElabInfo
)
from ..util import to_lean_ident

LeanIdent = str

def normalize_string(val: str):
    val = " ".join(val.split())
    val = val.replace("{ ", "{").replace(" }", "}").replace("(", "").replace(")", "") #.replace("( ", "(").replace(" )", ")")
    val = val.replace("\n", " ").replace("\r", " ").replace("\t", " ")
    val = val.replace("¬", "¬ ").replace("«", " ").replace("≫", " ").strip()
    val = " ".join(val.split())
    return val

def has_comment_string(val: str):
    return val.startswith(": --") or val.startswith(":--") or val.startswith(": /-") or val.startswith(":/-")

def dataclass_field_values(f, obj1, obj2):
        if not f.compare: 
            return None, None

        v1, v2 = getattr(obj1, f.name), getattr(obj2, f.name)

        if f.metadata.get("allow_none_match") and v1 is None and v2 is not None:
            v1 = v2

        if f.metadata.get("allow_pp_none_match"):
            if hasattr(obj1.parent, "pp"):
                pp_v1, pp_v2 = getattr(obj1.parent, "pp"), getattr(obj2.parent, "pp")
                if pp_v1 is None and pp_v2 is not None:
                    v1 = v2
            if hasattr(obj1, "pp"):
                pp_v1, pp_v2 = getattr(obj1, "pp"), getattr(obj2, "pp")
                if pp_v1 is None and pp_v2 is not None:
                    v1 = v2

        if f.metadata.get("allow_name_match") and (v1 is not None) and (v2 is not None):
            vs1 = v1.split(".")
            vs2 = v2.split(".")
            if vs2[0] == "_private":
                vs2 = vs2[2:]
            v1 = ".".join(vs1)
            v2 = ".".join(vs2)
            vs1 = v1.split("._@.")
            vs2 = v2.split("._@.")
            v1 = vs1[0]
            v2 = vs2[0]

            vs2 = v2.split(".0.")
            if len(vs2) == 2 and not ".0." in v1:
                v1 = vs2[0] + ".0." + v1

        if f.metadata.get("allow_anonymous_name_match") and (v1 is not None) and (v2 is not None):
            ##### workaround, need fix in new name for instance
            vs1 = v1.split(".")
            last1 = vs1[-1]
            parts1 = last1.rsplit("_", 1)
            prefix1 = parts1[0]
            postfix1 = parts1[1] if len(parts1) > 1 else ""

            vs2 = v2.split(".")
            last2 = vs2[-1]
            parts2 = last2.rsplit("_", 1)
            postfix2 = parts2[1] if len(parts2) > 1 else ""

            if prefix1.startswith("inst") and len(postfix1) > 0 and len(postfix2) > 0: #and prefix1.startswith(prefix2) 
                v2 = v1
        
        if f.metadata.get("allow_param_empty_match") and (v1 is not None) and (v2 is not None):
            if len(v1) == 0:
                v1 = v2

        if f.metadata.get("allow_variable_match") and (v1 is not None) and (v2 is not None):
            # since MACRO does not load, variable name might not be able to get, lean does not setup array empty
            if len(v2) == 0:
                v1 = v2
            #if len(v1) == len(v2):
            #    for i, val1 in enumerate(v1):
            #        val2 = v2[i]
            #        val1 = normalize_string(val1)
            #        val2 = normalize_string(val2)
            #        if val2.startswith("variable ") and not val1.startswith("variable "):
            #            val1 = "variable " + val1
            #        # since MACRO does not load, variable name might not be able to get
            #        if val2 == "[anonymous]":
            #            val1 = val2
            #        v1[i] = val1
            #        v2[i] = val2

        if f.metadata.get("allow_lstrip_match") and (v1 is not None) and (v2 is not None):
            v1 = v1.lstrip()

        if f.metadata.get("allow_normalize_match") and (v1 is not None) and (v2 is not None):
            v1 = normalize_string(v1)
            v2 = normalize_string(v2)
            if len(v1) > 40 and len(v2) > 40:
                h1 = v1[:20]
                t1 = v1[-20:]
                v1 = h1 + " ... " + t1
                h2 = v2[:20]
                t2 = v2[-20:]
                v2 = h2 + " ... " + t2
            v1 = v2 # ignore difference since v1 from MACRO

        if f.metadata.get("remove_comment") and (v1 is not None) and (v2 is not None):
            # lean type has commet, it need remove it but hard to do
            v1_range = getattr(v1, "range") if hasattr(v1, "range") else None
            v1_pp = getattr(v1, "pp") if hasattr(v1, "pp") else None
            v2_range = getattr(v2, "range") if hasattr(v2, "range") else None
            v2_pp = getattr(v2, "pp") if hasattr(v2, "pp") else None
            if v1_pp is not None and v1_range is not None and v2_pp is not None and v2_range is not None:
                v1_pp = normalize_string(v1_pp)
                v2_pp = normalize_string(v2_pp)
                if v2_pp.endswith(v1_pp) and v1_pp != v2_pp and has_comment_string(v2_pp):
                    setattr(v2, "range", v1_range)
                    setattr(v2, "pp", v1_pp)

        if f.metadata.get("opaque_match") and (v1 is not None) and v2 is None:
            # for opaque, empty of value without MACRO
            v1_pp = getattr(v1, "pp") if hasattr(v1, "pp") else None
            if v1_pp is not None and v1_pp == " :=\n  default_or_ofNonempty%":
                v1 = None

        if f.name =="visibility":
            if v1 == "regular":
                v2 = v1
                
        if f.name =="compute_kind":
            if v1 == "regular":
                v2 = v1

        return v1, v2    

def match_jixia_any_compare(cls):
    def __eq__(self, other):
        if not isinstance(other, cls): return False
        for f in fields(self):
            v1, v2 = dataclass_field_values(f, self, other)
            if v1 != v2: return False 
    
    cls.__eq__ = __eq__
    return cls

def match_jixia_visibility_reqular_compare(cls):
    def __eq__(self, other):
        if not isinstance(other, cls): return False
        for f in fields(self):
            if not f.compare: continue
            v1, v2 = getattr(self, f.name), getattr(other, f.name)
            if f.metadata.get("allow_none_match") and (v1 is None):
                continue
            if v1 != v2: return False
        return True
    
    cls.__eq__ = __eq__
    return cls

@dataclass_json
@dataclass
class ModuleData:
    docstring: Optional[str]
    imports: list[list[str]]

    parent: Any = field(default=None, repr=False, compare=False, hash=False, metadata=config(exclude=lambda x: True))

    @classmethod
    def create(cls, module_info: ModuleInfo) -> Self:
        return cls(
            docstring=module_info.docstring,
            imports=module_info.imports
        )
    
    @classmethod
    def lean_create(cls, module_info: LeanModuleInfo) -> Self:
        return cls(
            docstring=module_info.docstring,
            imports=module_info.imports
        )
    
@dataclass_json
@dataclass
class SymbolData:
    kind: str
    name: LeanIdent
    type_full: Optional[str]
    type_readable: Optional[str]
    type_fallback: Optional[str]
    type_references: list[LeanIdent]
    value_references: Optional[list[LeanIdent]]
    is_prop: bool

    parent: Any = field(default=None, repr=False, compare=False, hash=False, metadata=config(exclude=lambda x: True))

    @classmethod
    def create(cls, symbol: Symbol) -> Self:
        return cls(
            kind=str(symbol.kind),
            name=to_lean_ident(symbol.name),
            type_full=symbol.type_full,
            type_readable=symbol.type_readable,
            type_fallback=symbol.type_fallback,
            type_references=[ to_lean_ident(ref) for ref in symbol.type_references],
            value_references=[ to_lean_ident(ref) for ref in symbol.value_references] if symbol.value_references is not None else None,
            is_prop=symbol.is_prop
        )
    
    @classmethod
    def lean_create(cls, symbol: LeanSymbol) -> Self:
        return cls(
            kind=str(symbol.kind),
            name=to_lean_ident(symbol.name),
            type_full=symbol.type_full,
            type_readable=symbol.type_readable,
            type_fallback=symbol.type_fallback,
            type_references=[ to_lean_ident(ref) for ref in symbol.type_references],
            value_references=[ to_lean_ident(ref) for ref in symbol.value_references] if symbol.value_references is not None else None,
            is_prop=symbol.is_prop
        )
    
@match_jixia_any_compare
@dataclass_json
@dataclass
class RangeData:
    start: int = field(metadata={"allow_pp_none_match": True})
    stop: int = field(metadata={"allow_pp_none_match": True})

    parent: Any = field(default=None, repr=False, compare=False, hash=False, metadata=config(exclude=lambda x: True))

    @classmethod
    def create(cls, range: StringRange) -> Self:
        return cls(
            start=int(range.start),
            stop=int(range.stop)
        )
    
    @classmethod
    def lean_create(cls, range: LeanStringRange) -> Self:
        return cls(
            start=range.start,
            stop=range.stop
        )

@match_jixia_any_compare
@dataclass_json
@dataclass
class PPSyntaxData:
    original: bool = field(metadata={"allow_pp_none_match": True})
    range: Optional[RangeData] = field(metadata={"allow_pp_none_match": True})
    pp: Optional[str] = field(metadata={"allow_none_match": True, "allow_lstrip_match": True, "allow_normalize_match": True})

    parent: Any = field(default=None, repr=False, compare=False, hash=False, metadata=config(exclude=lambda x: True))

    @classmethod
    def create(cls, ppSyntax: PPSyntax) -> Self:
        obj = cls(
            original=ppSyntax.original,
            range=RangeData.create(ppSyntax.range) if ppSyntax.range is not None else None,
            pp=ppSyntax.pp
        )
        if obj.range: obj.range.parent = obj
        return obj
    
    @classmethod
    def lean_create(cls, ppSyntax: LeanPPSyntax) -> Self:
        obj = cls(
            original=ppSyntax.original,
            range=RangeData.lean_create(ppSyntax.range) if ppSyntax.range is not None else None,
            pp=ppSyntax.pp
        )
        if obj.range: obj.range.parent = obj
        return obj

@match_jixia_any_compare
@dataclass_json
@dataclass
class ParamData:
    ref: Optional[RangeData]
    id: Optional[RangeData]
    type: Optional[RangeData] = field(metadata={"allow_none_match": True})
    binder_info: str

    parent: Any = field(default=None, repr=False, compare=False, hash=False, metadata=config(exclude=lambda x: True))

    @classmethod
    def create(cls, param: Param) -> Self:
        obj = cls(
            ref=RangeData.create(param.ref) if param.ref is not None else None,
            id=RangeData.create(param.id) if param.id is not None else None,
            type=RangeData.create(param.type) if param.type is not None else None,
            binder_info=param.binder_info
        )
        for child in [obj.ref, obj.id, obj.type]:
            if child: child.parent = obj
        return obj
    
    @classmethod
    def lean_create(cls, param: LeanParam) -> Self:
        obj = cls(
            ref=RangeData.lean_create(param.ref) if param.ref is not None else None,
            id=RangeData.lean_create(param.id) if param.id is not None else None,
            type=RangeData.lean_create(param.type) if param.type is not None else None,
            binder_info=param.binder_info
        )
        for child in [obj.ref, obj.id, obj.type]:
            if child: child.parent = obj
        return obj

@match_jixia_any_compare
@dataclass_json
@dataclass
class ModifiersData:
    visibility: str
    compute_kind: str
    rec_kind: str
    is_unsafe: bool
    is_noncomputable: bool = False
    docstring: Optional[str] = field(default=None, metadata={"allow_none_match": True})
    has_docstring: Optional[bool] = field(default=None, metadata={"allow_none_match": True})

    parent: Any = field(default=None, repr=False, compare=False, hash=False, metadata=config(exclude=lambda x: True))

    @classmethod
    def create(cls, modifiers: Modifiers) -> Self:
        return cls(
            visibility=str(modifiers.visibility),
            compute_kind=str(modifiers.compute_kind),
            rec_kind=str(modifiers.rec_kind),
            is_unsafe=modifiers.is_unsafe,
            docstring=modifiers.docstring[0] if modifiers.docstring is not None else None,
            has_docstring=modifiers.docstring[1] if modifiers.docstring is not None else None,
            #is_noncomputable=modifiers.is_noncomputable
        )
    
    @classmethod
    def lean_create(cls, modifiers: LeanModifiers) -> Self:
        return cls(
            visibility=str(modifiers.visibility),
            compute_kind=str(modifiers.compute_kind),
            rec_kind=str(modifiers.rec_kind),
            is_unsafe=modifiers.is_unsafe,
            docstring=modifiers.docstring[0] if modifiers.docstring is not None else None,
            has_docstring=modifiers.docstring[1] if modifiers.docstring is not None else None,
            #is_noncomputable=modifiers.is_noncomputable
        )
    
@dataclass_json
@dataclass
class OpenDeclSimpleData:
    namespace: LeanIdent
    hiding: list[LeanIdent]

    parent: Any = field(default=None, repr=False, compare=False, hash=False, metadata=config(exclude=lambda x: True))

    @classmethod
    def create(cls, simple: OpenDecl.Simple):
        return cls(
            namespace=to_lean_ident(simple.namespace),
            hiding=[ to_lean_ident(item) for item in simple.hiding ]
        )
    
    @classmethod
    def lean_create(cls, simple: LeanOpenDeclSimple):
        return cls(
            namespace=to_lean_ident(simple.namespace),
            hiding=[ to_lean_ident(item) for item in simple.hiding ]
        )

@dataclass_json
@dataclass
class OpenDeclRenameData:
    name: LeanIdent
    as_: LeanIdent

    parent: Any = field(default=None, repr=False, compare=False, hash=False, metadata=config(exclude=lambda x: True))

    @classmethod
    def create(cls, rename: OpenDecl.Rename):
        return cls(
            name=to_lean_ident(rename.name),
            as_=to_lean_ident(rename.as_),
        )
    
    @classmethod
    def lean_create(cls, rename: LeanOpenDeclRename):
        return cls(
            name=to_lean_ident(rename.name),
            as_=to_lean_ident(rename.as_),
        )

@dataclass_json
@dataclass
class OpenDeclData:
    simple: Optional[OpenDeclSimpleData]
    rename: Optional[OpenDeclRenameData]

    parent: Any = field(default=None, repr=False, compare=False, hash=False, metadata=config(exclude=lambda x: True))

    @classmethod
    def create(cls, openDecl: OpenDecl):
        obj = cls(
            simple=OpenDeclSimpleData.create(openDecl.simple) if openDecl.simple is not None else None,
            rename=OpenDeclRenameData.create(openDecl.rename) if openDecl.rename is not None else None
        )
        for child in [obj.simple, obj.rename]:
            if child: child.parent = obj
        return obj
    
    @classmethod
    def lean_create(cls, openDecl: LeanOpenDecl):
        obj = cls(
            simple=OpenDeclSimpleData.lean_create(openDecl.simple) if openDecl.simple is not None else None,
            rename=OpenDeclRenameData.lean_create(openDecl.rename) if openDecl.rename is not None else None
        )
        for child in [obj.simple, obj.rename]:
            if child: child.parent = obj
        return obj

@match_jixia_any_compare
@dataclass_json
@dataclass
class ScopeInfoData:
    var_decls: list[str] = field(metadata={"allow_variable_match": True})
    include_vars: list[LeanIdent]
    omit_vars: list[LeanIdent]
    curr_namespace: LeanIdent
    open_decl: list[OpenDecl]

    parent: Any = field(default=None, repr=False, compare=False, hash=False, metadata=config(exclude=lambda x: True))

    @classmethod
    def create(cls, scopeInfo: ScopeInfo):
        obj = cls(
            var_decls=scopeInfo.var_decls,
            include_vars=[ to_lean_ident(var) for var in scopeInfo.include_vars ],
            omit_vars=[ to_lean_ident(var) for var in scopeInfo.omit_vars ],
            curr_namespace=to_lean_ident(scopeInfo.curr_namespace),
            open_decl=[ OpenDeclData.create(decl) for decl in scopeInfo.open_decl ],
        )
        for child in obj.open_decl: 
            if child: child.parent = obj
        return obj
    
    @classmethod
    def lean_create(cls, scopeInfo: LeanScopeInfo):
        obj = cls(
            var_decls=scopeInfo.var_decls,
            include_vars=[ to_lean_ident(var) for var in scopeInfo.include_vars ],
            omit_vars=[ to_lean_ident(var) for var in scopeInfo.omit_vars ],
            curr_namespace=to_lean_ident(scopeInfo.curr_namespace),
            open_decl=[ OpenDeclData.lean_create(decl) for decl in scopeInfo.open_decl ],
        )
        for child in obj.open_decl: 
            if child: child.parent = obj
        return obj

@match_jixia_any_compare
@dataclass_json
@dataclass
class DeclarationData:
    kind: str
    ref: PPSyntaxData
    name: LeanIdent = field(metadata={"allow_name_match": True, "allow_anonymous_name_match": True})
    signature: PPSyntaxData
    modifiers: ModifiersData
    params: list[ParamData] = field(metadata={"allow_param_empty_match": True})
    type: Optional[PPSyntaxData] = field(metadata={"allow_none_match": True, "remove_comment": True})
    value: Optional[PPSyntaxData] = field(metadata={"allow_none_match": True, "opaque_match": True})
    scope_info: Optional[ScopeInfoData]

    parent: Any = field(default=None, repr=False, compare=False, hash=False, metadata=config(exclude=lambda x: True))

    def compare_key(self):
        range = self.ref.range if self.ref is not None and self.ref.range is not None else None
        return f"{self.name}, {range}"

    @classmethod
    def create(cls, decl: Declaration):
        signature = PPSyntaxData.create(decl.signature) if decl.signature is not None else None
        value = PPSyntaxData.create(decl.value) if decl.value is not None else None
        # force set value is None since Lean does not have value because MACRO does not loaded
        if value is not None and signature is not None and value.original == False and signature.range == value.range:
            value = None
        obj = cls(
            kind=str(decl.kind),
            ref=PPSyntaxData.create(decl.ref),
            name=to_lean_ident(decl.name),
            signature=signature,
            modifiers=ModifiersData.create(decl.modifiers),
            params=[ ParamData.create(param) for param in decl.params ],
            type=PPSyntaxData.create(decl.type) if decl.type is not None else None,
            value=value,
            scope_info=ScopeInfoData.create(decl.scope_info) if decl.scope_info is not None else None
        )
        for child in [obj.ref, obj.signature, obj.modifiers, *obj.params, obj.type, obj.value, obj.scope_info]:
            if child: child.parent = obj
        return obj
    
    @classmethod
    def lean_create(cls, decl: LeanDeclaration):
        obj = cls(
            kind=str(decl.kind),
            ref=PPSyntaxData.lean_create(decl.ref),
            name=to_lean_ident(decl.name),
            signature=PPSyntaxData.lean_create(decl.signature),
            modifiers=ModifiersData.lean_create(decl.modifiers),
            params=[ ParamData.lean_create(param) for param in decl.params ],
            type=PPSyntaxData.lean_create(decl.type) if decl.type is not None else None,
            value=PPSyntaxData.lean_create(decl.value) if decl.value is not None else None,
            scope_info=ScopeInfoData.lean_create(decl.scope_info) if decl.scope_info is not None else None
        )
        for child in [obj.ref, obj.signature, obj.modifiers, *obj.params, obj.type, obj.value, obj.scope_info]:
            if child: child.parent = obj
        return obj
    
@dataclass_json
@dataclass
class PPSyntaxWithKindData(PPSyntaxData):
    kind: Optional[LeanIdent] = None

    @classmethod
    def create(cls, ppSyntax: PPSyntaxWithKind):
        obj = cls(
            original=ppSyntax.original,
            range=RangeData.create(ppSyntax.range) if ppSyntax.range is not None else None,
            pp=ppSyntax.pp,
            kind = to_lean_ident(ppSyntax.kind)
        )
        if obj.range: obj.range.parent = obj
        return obj
  
    @classmethod
    def lean_create(cls, ppSyntax: LeanPPSyntaxWithKind):
        obj = cls(
            original=ppSyntax.original,
            range=RangeData.lean_create(ppSyntax.range) if ppSyntax.range is not None else None,
            pp=ppSyntax.pp,
            kind = to_lean_ident(ppSyntax.kind)
        )
        if obj.range: obj.range.parent = obj
        return obj
    
@dataclass_json
@dataclass
class VariableData:
    id: LeanIdent
    name: LeanIdent
    binder_info: Optional[str]
    type: str
    value: Optional[str]
    is_prop: bool

    parent: Any = field(default=None, repr=False, compare=False, hash=False, metadata=config(exclude=lambda x: True))

    @classmethod
    def create(cls, variable: Variable):
        return cls(
            id=to_lean_ident(variable.id),
            name=to_lean_ident(variable.name),
            binder_info=variable.binder_info,
            type=variable.type,
            value=variable.value,
            is_prop=variable.is_prop
        )
    
    @classmethod
    def lean_create(cls, variable: LeanVariable):
        return cls(
            id=to_lean_ident(variable.id),
            name=to_lean_ident(variable.name),
            binder_info=variable.binder_info,
            type=variable.type,
            value=variable.value,
            is_prop=variable.is_prop
        )

@dataclass_json
@dataclass
class SpecialValueData:
    const: Optional[LeanIdent]
    fvar: Optional[LeanIdent]

    parent: Any = field(default=None, repr=False, compare=False, hash=False, metadata=config(exclude=lambda x: True))

    @classmethod
    def create(cls, value: SpecialValue):
        return cls(
            const=to_lean_ident(value.const) if value.const is not None else None,
            fvar=to_lean_ident(value.fvar) if value.fvar is not None else None
        )

    @classmethod
    def lean_create(cls, value: LeanSpecialValue):
        return cls(
            const=to_lean_ident(value.const) if value.const is not None else None,
            fvar=to_lean_ident(value.fvar) if value.fvar is not None else None
        )

@dataclass_json
@dataclass
class TermElabInfoData:
    context: list[Variable]
    type: str
    expected_type: Optional[str]
    value: str
    special: Optional[SpecialValue]

    parent: Any = field(default=None, repr=False, compare=False, hash=False, metadata=config(exclude=lambda x: True))

    @classmethod
    def create(cls, termElab: TermElabInfo):
        obj = cls(
            context=[ VariableData.create(var) for var in termElab.context ],
            type=termElab.type,
            expected_type=termElab.expected_type,
            value=termElab.value,
            special=SpecialValueData.create(termElab.special) if termElab.special is not None else None
        )
        for child in [*obj.context, obj.special]:
            if child: child.parent = obj
        return obj
    
    @classmethod
    def lean_create(cls, termElab: LeanTermElabInfo):
        obj = cls(
            context=[ VariableData.lean_create(var) for var in termElab.context ],
            type=termElab.type,
            expected_type=termElab.expected_type,
            value=termElab.value,
            special=SpecialValueData.lean_create(termElab.special) if termElab.special is not None else None
        )
        for child in [*obj.context, obj.special]:
            if child: child.parent = obj
        return obj

@dataclass_json
@dataclass
class GoalData:
    tag: LeanIdent
    context: list[VariableData]
    type: str
    is_prop: bool
    pp: Optional[str] = None

    parent: Any = field(default=None, repr=False, compare=False, hash=False, metadata=config(exclude=lambda x: True))

    @classmethod
    def create(cls, termElab: Goal):
        obj = cls(
            tag=to_lean_ident(termElab.tag),
            context=[ VariableData.create(var) for var in termElab.context ],
            type=termElab.type,
            is_prop=termElab.is_prop,
            pp=termElab.pp
        )
        for child in obj.context:
            if child: child.parent = obj
        return obj
    
    @classmethod
    def lean_create(cls, termElab: LeanGoal):
        obj = cls(
            tag=to_lean_ident(termElab.tag),
            context=[ VariableData.lean_create(var) for var in termElab.context ],
            type=termElab.type,
            is_prop=termElab.is_prop,
            pp=termElab.pp
        )
        for child in obj.context:
            if child: child.parent = obj
        return obj
    
@dataclass_json
@dataclass
class TacticElabInfoData:
    references: list[LeanIdent]
    before: list[GoalData]
    after: list[GoalData]

    parent: Any = field(default=None, repr=False, compare=False, hash=False, metadata=config(exclude=lambda x: True))

    @classmethod
    def create(cls, tactic: TacticElabInfo):
        obj = cls(
            references=[ to_lean_ident(ref) for ref in tactic.references ],
            before=[ GoalData.create(goal) for goal in tactic.before ],
            after=[ GoalData.create(goal) for goal in tactic.after ]
        )
        for child in [*obj.before, *obj.after]:
            if child: child.parent = obj
        return obj
    
    @classmethod
    def lean_create(cls, tactic: LeanTacticElabInfo):
        obj = cls(
            references=[ to_lean_ident(ref) for ref in tactic.references ],
            before=[ GoalData.lean_create(goal) for goal in tactic.before ],
            after=[ GoalData.lean_create(goal) for goal in tactic.after ]
        )
        for child in [*obj.before, *obj.after]:
            if child: child.parent = obj
        return obj

@dataclass_json
@dataclass
class ElabInfoData:
    term: Optional[TermElabInfoData]
    tactic: Optional[TacticElabInfoData]
    macro: Optional[PPSyntaxWithKindData]
    simple: Optional[str]

    parent: Any = field(default=None, repr=False, compare=False, hash=False, metadata=config(exclude=lambda x: True))

    @classmethod
    def create(cls, elabInfo: ElabInfo):
        obj = cls(
            term=TermElabInfoData.create(elabInfo.term) if elabInfo.term is not None else None,
            tactic=TacticElabInfoData.create(elabInfo.tactic) if elabInfo.tactic is not None else None,
            macro=PPSyntaxWithKindData.create(elabInfo.macro.expanded) if elabInfo.macro is not None else None,
            simple=str(elabInfo.simple) if elabInfo.simple is not None else None
        )
        for child in [obj.term, obj.tactic, obj.macro]:
            if child: child.parent = obj
        return obj
    
    @classmethod
    def lean_create(cls, elabInfo: LeanElabInfo):
        obj = cls(
            term=TermElabInfoData.lean_create(elabInfo.term) if elabInfo.term is not None else None,
            tactic=TacticElabInfoData.lean_create(elabInfo.tactic) if elabInfo.tactic is not None else None,
            macro=PPSyntaxWithKindData.lean_create(elabInfo.macro.expanded) if elabInfo.macro is not None else None,
            simple=str(elabInfo.simple) if elabInfo.simple is not None else None
        )
        for child in [obj.term, obj.tactic, obj.macro]:
            if child: child.parent = obj
        return obj

@dataclass_json
@dataclass
class InfoTreeData:
    info: ElabInfoData
    ref: PPSyntaxWithKindData
    children: list[Self]

    parent: Any = field(default=None, repr=False, compare=False, hash=False, metadata=config(exclude=lambda x: True))

    @classmethod
    def create(cls, infoTree: InfoTree):
        obj = cls(
            info=ElabInfoData.create(infoTree.info),
            ref=PPSyntaxWithKindData.create(infoTree.ref),
            children=[ InfoTreeData.create(child) for child in infoTree.children ]
        )
        for child in [obj.info, obj.ref, *obj.children]:
            if child: child.parent = obj
        return obj
    
    @classmethod
    def lean_create(cls, infoTree: LeanInfoTree):
        obj = cls(
            info=ElabInfoData.lean_create(infoTree.info),
            ref=PPSyntaxWithKindData.lean_create(infoTree.ref),
            children=[ InfoTreeData.lean_create(child) for child in infoTree.children ]
        )
        for child in [obj.info, obj.ref, *obj.children]:
            if child: child.parent = obj
        return obj

@dataclass_json
@dataclass
class ModuleTreeData:
    module: ModuleData
    symbols: list[SymbolData]
    decls: list[DeclarationData]
    infoTrees: list[InfoTreeData]

@dataclass
class ProjectData:
    def loadModuleTree(self, module_name):
        pass
