import os
import json
from enum import StrEnum
from typing import Optional, Iterable
from pathlib import Path
from argparse import ArgumentParser
import logging
from .abstruct_extract import AbstructExtract

class Plugin(StrEnum):
    MOD = "mod"
    DECL = "decl"
    SYM = "sym"
    ELAB = "elab"
    LINE = "line"
    AST = "ast"

class BuildProject(AbstructExtract):
    output_path: Path
    overwrite: bool
    run_initializers: bool

    def __init__(self, root_dir: str, output_path: str = ".jixia", overwrite: bool = False,
                 max_workers: int = os.cpu_count(), run_initializers: bool = True):
        super().__init__(root_dir, ["jixia"], max_workers)
        self.root_path = Path(root_dir).resolve()
        out_p = Path(output_path)
        self.output_path = out_p.resolve() if out_p.is_absolute() else (self.root_path / out_p).resolve()
        self.output_path.mkdir(exist_ok=True, parents=True)
        self.overwrite = overwrite
        self.run_initializers = run_initializers

    def execute_args(self, module_name: str, args):
        exec_args = []
        if self.run_initializers:
            exec_args.append("-i")
        need_run = False
        for arg in args:
            str_arg = f"{arg}"
            output_file = self.output_path / Path(f"{module_name}.{str_arg}.json")
            if self.overwrite or not output_file.exists():
                exec_args.extend(["-" + str_arg[0], str(output_file)])
                need_run = True
        return exec_args if need_run else None
    
    def jixia_build(self,
                    search_list: Optional[list] = None,
                    plugins: Iterable[Plugin] = list(Plugin)) -> list:

        return self.batch_build(search_list, plugins)

def main():
    parser = ArgumentParser()
    parser.add_argument("project_root", default=None, help="Project to be indexed")
    parser.add_argument("--search_list", default="", help="e.g., Init,Mathlib")
    parser.add_argument("--overwrite", default=True, help="overwrite when json file existing. e.g., True")
    parser.add_argument("--log_file", default="build.log", help="e.g., build.log")
    parser.add_argument("--log_mode", type=str, choices=["Info", "Debug"], default="Info", help="Log detail mode")
    args = parser.parse_args()

    log_level = logging.DEBUG if args.log_mode == "Debug" else logging.INFO
    log_format = '%(asctime)s - %(levelname)s - %(message)s'
    logging.basicConfig(
        level=log_level,
        format=log_format,
        handlers=[
            logging.FileHandler("build.log"),
            logging.StreamHandler()
        ]
    )

    logging.info(f"project_root: {args.project_root}")
    logging.info(f"search_list: {args.search_list}")
    logging.info(f"overwrite: {args.overwrite}")
    logging.info(f"log_file: {args.log_file}")

    log_path = Path(args.project_root) / Path("jixia_json.log")
    Path(log_path).unlink(missing_ok=True)

    project = BuildProject(args.project_root, overwrite=args.overwrite)
    plugins=[Plugin.MOD, Plugin.DECL, Plugin.SYM, Plugin.LINE, Plugin.AST, Plugin.ELAB]

    search_list = [p.strip() for p in args.search_list.split(",")]
    if len(search_list) == 0:
        search_list = ["Init,Mathlib,LeanTest"]
    elif len(search_list) == 1 and search_list[0] == "TEST":
        search_list = [
            "Init.Try",
            "Init.Data.Cast",
            "Mathlib.MeasureTheory.SetAlgebra",
            "Mathlib.MeasureTheory.PiSystem",
            "Mathlib.MeasureTheory.Constructions.SubmoduleQuotient",
            "Mathlib.MeasureTheory.Constructions.Projective",
            "Mathlib.MeasureTheory.OuterMeasure.Basic",
            "Mathlib.MeasureTheory.Function.AEEqFun",
            "Mathlib.MeasureTheory.Constructions.BorelSpace.Basic",
            "Mathlib.MeasureTheory.Function.AEEqFun.DomAct",
            "Mathlib.Tactic.Hint",
            "Mathlib.GroupTheory.GroupAction.Primitive",
            "Mathlib.Order.DirectedInverseSystem",
            "Mathlib.CategoryTheory.Limits.HasLimits",
            "Mathlib.Util.Export",
            "Mathlib.Util.MemoFix",
            "Mathlib.Algebra.Category.CommAlgCat.Monoidal",
            "Mathlib.CategoryTheory.Limits.HasLimits",
            "Mathlib.Topology.ContinuousMap.Bounded.Normed"
            "Mathlib.Tactic.Widget.LibraryRewrite",
            "Mathlib.Tactic.Widget.Calc",
            "Mathlib.Data.Nat.Init",
        ]
    elif len(search_list) == 1 and search_list[0] == "TEST2":
        search_list = ["Mathlib.MeasureTheory"]

    results = project.jixia_build(
        search_list=search_list,
        plugins=plugins,
    )
    logging.debug(f"Results for {project.root_path} with plugins: {plugins}:")
    try:
        logging.debug(json.dumps(results, indent=2))
    except:
        logging.debug(results)

if __name__ == "__main__":
    main()
    # python -m leanstmt.core.jixia_extract "/home/linfe/math/lean_test" --search_list TEST