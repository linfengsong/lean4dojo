from dataclasses import dataclass
import msgspec
from pathlib import Path
from .structs import LeanModuleInfo,LeanSymbol,LeanDeclaration,LeanLineModel,LeanInfoTree

def to_lean_ident(name: list[str]):
    return ".".join([str(v) for v in name])

@dataclass
class LeanModule:
    moduleInfo: LeanModuleInfo
    symbols: list[LeanSymbol]
    decls: list[LeanDeclaration]
    lines: list[LeanLineModel]
    infoTrees: list[LeanInfoTree] 

@dataclass
class LeanProject:
    working_dir: str
    json_dir: str

    def fetch_module(self, module_name):
        module = self._load_info(module_name, "mod", LeanModuleInfo)
        if module is None:
            return None
        symbols = self._load_info(module_name, "sym", list[LeanSymbol])
        decls = self._load_info(module_name, "decl", list[LeanDeclaration])
        lines = self._load_info(module_name, "line", list[LeanLineModel])
        infoTrees = self._load_info(module_name, "elab", list[LeanInfoTree])
        return LeanModule(module, symbols, decls, lines, infoTrees)

    def _load_info(self, module_name, type, objType):
        module_id = to_lean_ident(module_name)
        filename = f"{module_id}.{type}.json"
        file_path = Path(self.working_dir) / Path(self.json_dir) / Path(filename)
        if not file_path.exists():
            return None
        with file_path.open(encoding='utf-8') as fp:
            raw_json = fp.read()
            return msgspec.json.decode(raw_json, type=objType)
