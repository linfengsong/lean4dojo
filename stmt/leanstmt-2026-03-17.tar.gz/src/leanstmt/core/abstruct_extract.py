import re
from typing import Optional
from pathlib import Path
import concurrent.futures
from concurrent.futures.thread import ThreadPoolExecutor
import subprocess
from tqdm import tqdm
import logging

class AbstructExtract:
    root_path: Path
    common_args: list
    max_workers: Optional[int]
    all_lean_src_paths: list[Path]

    def __init__(self, 
                 root_dir: str,
                 common_args: list, 
                 max_workers: int = None,
                 all_lean_src_paths = None):
        self.root_path = Path(root_dir).resolve()
        self.common_args = common_args
        self.max_workers = max_workers
        self.all_lean_src_paths = all_lean_src_paths if all_lean_src_paths else self._all_lean_paths()

    def _get_lean4_version_from_config(self) -> str:
        lean4_ver_regex = re.compile(r"leanprover/lean4:(?P<version>.+)")
        config_path = self.root_path / 'lean-toolchain'
        with open(config_path, 'r') as file:
            content = file.read()
            m = lean4_ver_regex.search(content.strip())
            assert m is not None, f"Invalid config in {config_path}"
            v = m["version"]
            return v if v.startswith("v") or not v[0].isdigit() else "v" + v

    def _get_elan_toolchain_src_path(self) -> Path:
        version = self._get_lean4_version_from_config()
        lean_version = version[1:] if version.startswith("v") else version
        toolchain_name = f"leanprover--lean4---v{lean_version}"
        return Path.home() / ".elan/toolchains" / toolchain_name / "src/lean"

    def _all_lean_paths(self) -> list[Path]:
        paths = [self.root_path]
        packages_path = self.root_path.joinpath(".lake/packages")
        if packages_path.exists() and packages_path.is_dir:
            for item in packages_path.iterdir():
                if item.is_dir():
                    paths.append(item)
        paths.append(self._get_elan_toolchain_src_path())
        return paths

    def _path_of_module(self, module_name: str, base_dir: str) -> str:
        return str(Path(base_dir) / Path(*(module_name.split("."))).with_suffix(".lean"))

    def _find_tasks(self, search_list: Optional[list] = None) -> list[(str, str)]:
        task_dict = {}

        if search_list is not None:
            patterns = [f"{p.replace('.', '/')}/**/*.lean" for p in search_list]
            files = [f"{p.replace('.', '/')}.lean" for p in search_list]
        else:
            patterns = ["**/*.lean"]
            files = []
        for b_path in self.all_lean_src_paths:
            for file in files:
                if Path(b_path / file).exists():
                    rel_path = Path(file).with_suffix("")
                    m_name = ".".join(rel_path.parts)
                    if not m_name in task_dict:
                        task_dict[m_name] = (m_name, b_path)
            for p in patterns:
                for file_path in b_path.glob(p):
                    rel_path = file_path.relative_to(b_path).with_suffix("")
                    m_name = ".".join(rel_path.parts)
                    if not m_name in task_dict:
                        task_dict[m_name] = (m_name, b_path)
        return list(task_dict.values())
    
    def execute_args(self, module_name: str, args):
        return args

    def run_build(self,
            file: str,
            module_name: str,
            args,
        ) -> Optional[subprocess.CompletedProcess]:
        lake_args = ["lake", "env"]
        lake_args.extend(self.common_args)
        args = self.execute_args(module_name, args)
        if args is None:
            return
        if len(args) > 0:
            lake_args.extend(args)
        lake_args.append(str(Path(file).resolve()))
        logging.debug(f"Running args: {lake_args}")
        return subprocess.run(lake_args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=self.root_path, text=True)

    def batch_build(self,
        search_list: Optional[list],
        args: list) -> list:
        tasks = self._find_tasks(search_list)

        ret = []
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {
                executor.submit(
                    self.run_build,
                    file=self._path_of_module(m_name, b_dir),
                    module_name=m_name,
                    args=args,
                ): m_name
                for m_name, b_dir in tasks
            }

            with tqdm(total=len(futures), desc=f"Extract {','.join(search_list[:2])}", unit="file") as pbar:
                for f in concurrent.futures.as_completed(futures):
                    m = futures[f]
                    try:
                        r = f.result()
                        if r is not None:
                            msg = r.stdout.strip()
                            if len(msg) > 0:
                                logging.debug(msg)
                            if r.returncode != 0:
                                pbar.write(f"Error in {m}: {r.stderr.strip()}")
                                ret.append((m, r))
                                logging.error(r.stderr.strip())
                    except Exception as e:
                        pbar.write(f"Exception in {m}: {e}")
                        er = subprocess.CompletedProcess(f"Request file: {f}", -1, "", f"Exception in {m}: {e}")
                        ret.append((m, er))
                        logging.error(f"Request file: {f}, Exception in {m}: {e}")
                    pbar.update(1)
        return ret


