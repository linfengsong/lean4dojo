import os
from datetime import datetime
from .lean_project import LeanProject
from .verify_module import verifyModule
from .execute_module import executeModule
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm

def printResult(log_fp, result_str):
    if result_str and len(result_str) > 0:
        log_fp.write(result_str)
        log_fp.flush()

def processProjectDebug(log_fp, project: LeanProject, module_locations, execute_mode: bool, print_content: bool, verify_check: bool):
    total_count = 0
    total_diffs = 0
    for module_name in module_locations.keys():
        if not module_name in exclude_list:
            if execute_mode: 
                result_str, count, diff_count = executeModule(project.coreProject.root_dir, module_name, print_content, verify_check)
            else:
                result_str, count, diff_count = verifyModule(project, module_name)
            printResult(log_fp, result_str)
            total_count += count
            total_diffs += diff_count
    printResult(log_fp, f"Total count: {total_count}, Total diffs: {total_diffs}")
    return total_count, total_diffs

def processProject(log_fp, project: LeanProject, module_locations, execute_mode: bool, print_content: bool, verify_check: bool):
    max_workers = os.cpu_count()
    total_count = 0
    total_diffs = 0
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        if execute_mode: 
            futures = {
                executor.submit(executeModule, project.coreProject.root_dir, module_name, print_content, verify_check): module_name
                for module_name in module_locations.keys() if not module_name in exclude_list
            }
        else:
            futures = {
                executor.submit(verifyModule, project, module_name): module_name
                for module_name in module_locations.keys() if not module_name in exclude_list
            }
        for future in tqdm(as_completed(futures), total=len(futures), desc="Comparing Modules"):
            result_str = None
            try:
                 result_str, count, diff_count = future.result()
            except Exception as e:
                result_str = f"Process failure: {e}"
                count = 1
                diff_count =1
            if result_str and len(result_str) > 0:
                log_fp.write(result_str)
                log_fp.flush()
            total_count += count
            total_diffs += diff_count
    printResult(log_fp, f"Execute finished: Total failures: {total_diffs}/{total_count}")
    return total_count, total_diffs

def main(root_dir: str, search_list: list, exclude_list: list =[], execute_mode: bool = False, print_content: bool = False, verify_check: bool = True, bDebug: bool = False):
    project = LeanProject(root_dir)
    module_locations = project.coreProject.find_module_locations(search_list)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    label = "execute" if execute_mode else "verify"
    file_name = f"{label}_lean_{timestamp}.log"
    log_dir = os.path.join(root_dir, ".logs")
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, file_name)

    if not bDebug:
        bDebug = len(module_locations) <= 1

    with open(log_file, "w", encoding="utf-8") as log_fp:
        if bDebug:
            print(f"Debug mode Processing modules sequentially")
            total_count, total_diffs = processProjectDebug(log_fp, project, module_locations, execute_mode, print_content, verify_check)
        else:
           total_count, total_diffs = processProject(log_fp, project, module_locations, execute_mode, print_content, verify_check)
        print(f"Execute finished: Total failures: {total_diffs}/{total_count}")


if __name__ == "__main__":
    root_dir = "/home/linfe/math/lean_test"
    module_name = "LeanTest.Basic"
    module_name = "Mathlib.Data.Nat.Init"
    module_name = "Mathlib.Tactic.Widget.LibraryRewrite"
    #module_name = "Mathlib.Util.MemoFix"
    #module_name = "Mathlib.RingTheory.TensorProduct.Basic"
    #module_name = "Mathlib.MeasureTheory.Function.LpSpace.Basic"
    #main2(root_dir, module_name, print_content=False, verify_check=True)

    exclude_list = [
        "Init.WF",
        "Mathlib.Data.Prod.Basic"]

    search_list = [
            "Init.Try",
            "Init.Data.Array.Lemmas",
            "Init.Data.Cast",
            "Init.Data.Nat.Div.Basic",
            "Init.Data.Nat.Power2",
            "Init.Data.Option.Array",
            "Init.Data.RArray",
            "Init.Data.Sum.Lemmas",
            "Init.Data.Vector.Extract",
            "Init.GetElem",
            "Init.Grind.Ordered.Module",
            "Init.Meta.Defs",
            "Init.Prelude",
            "Init.Omega.LinearCombo",
            "Mathlib.CategoryTheory.Monoidal.Cartesian.CommGrp_",
            "Mathlib.Data.EReal.Operations",
            "Mathlib.Data.List.Chain",
            "Mathlib.Data.Nat.Init",
            "Mathlib.Data.Finset.NAry",
            "Mathlib.Data.Finsupp.Interval",
            "Mathlib.Data.Set.Basic",
            "Mathlib.Data.Sym.Basic",
            "Mathlib.MeasureTheory.SetAlgebra",
            "Mathlib.MeasureTheory.PiSystem",
            "Mathlib.MeasureTheory.Constructions.BorelSpace.Basic",
            "Mathlib.MeasureTheory.Constructions.HaarToSphere",
            "Mathlib.MeasureTheory.Constructions.Pi",
            "Mathlib.MeasureTheory.Constructions.Polish.Basic",
            "Mathlib.MeasureTheory.Constructions.SubmoduleQuotient",
            "Mathlib.MeasureTheory.Constructions.Projective",
            "Mathlib.MeasureTheory.Function.AEEqFun",
            "Mathlib.MeasureTheory.Function.AEEqFun.DomAct",
            "Mathlib.MeasureTheory.Function.SpecialFunctions.Inner",
            "Mathlib.MeasureTheory.Measure.GiryMonad",
            "Mathlib.MeasureTheory.Measure.Dirac",
            "Mathlib.MeasureTheory.OuterMeasure.Basic",
            "Mathlib.Algebra.Algebra.Subalgebra.Basic",
            "Mathlib.Algebra.Category.CommAlgCat.Monoidal",
            "Mathlib.Algebra.Category.MonCat.Colimits",
            "Mathlib.Analysis.Calculus.ContDiff.FTaylorSeries",
            "Mathlib.Analysis.NormedSpace.Alternating.Uncurry.Fin",
            "Mathlib.Analysis.SpecialFunctions.Log.Basic"
            "Mathlib.CategoryTheory.Limits.HasLimits",
            "Mathlib.GroupTheory.GroupAction.Primitive",
            "Mathlib.LinearAlgebra.Dimension.Localization",
            "Mathlib.LinearAlgebra.CliffordAlgebra.Even",
            "Mathlib.Order.DirectedInverseSystem",
            "Mathlib.RingTheory.TensorProduct.Basic", 
            "Mathlib.RingTheory.RingHom.Locally",
            "Mathlib.Tactic.MoveAdd",
            "Mathlib.Tactic.Hint",
            "Mathlib.Tactic.Widget.LibraryRewrite",
            "Mathlib.Tactic.Widget.Calc",
            "Mathlib.Topology.ContinuousMap.Bounded.Normed",
            "Mathlib.Topology.Order.LeftRightNhds",
            "Mathlib.Util.Export",
            "Mathlib.Util.MemoFix",
        ]
    
    #search_list = ["Init","Mathlib","LestTest"]
    #search_list = ["Init"]
    #search_list = ["Mathlib"]
    #search_list = ["Mathlib.Data"]
    #search_list = ["Mathlib.MeasureTheory"]
    #search_list = ["Mathlib.Analysis"]

    #search_list = ["Mathlib.Data.Nat.Init"]
    #search_list = ["Mathlib.MeasureTheory.PiSystem"]
    #search_list = ["Mathlib.MeasureTheory.SetAlgebra"]
    #search_list = ["Mathlib.MeasureTheory.Constructions.BorelSpace.Basic"]
    #search_list = ["Mathlib.MeasureTheory.Constructions.HaarToSphere"]
    
    search_list = ["Mathlib.MeasureTheory.Constructions.Pi"]
    #search_list = ["Mathlib.MeasureTheory.Constructions.Polish.Basic"]
    #search_list = ["Mathlib.MeasureTheory.Constructions.SubmoduleQuotient"]
    #search_list = ["Mathlib.MeasureTheory.Constructions.Projective"]
    #search_list = ["Mathlib.MeasureTheory.Function.AEEqFun"]
    #search_list = ["Mathlib.MeasureTheory.Function.AEEqFun.DomAct"]
    #search_list = ["Mathlib.MeasureTheory.Function.SpecialFunctions.Inner"]
    #search_list = ["Mathlib.MeasureTheory.Measure.GiryMonad"]
    #search_list = ["Mathlib.MeasureTheory.Measure.Dirac"]
    #search_list = ["Mathlib.MeasureTheory.OuterMeasure.Basic"]

    execute_mode = True
    print_content = False
    verify_check = True
    bDebug = False
    main(root_dir, search_list, exclude_list, execute_mode, print_content, verify_check, bDebug)
    # python -m leanstmt.generator.test