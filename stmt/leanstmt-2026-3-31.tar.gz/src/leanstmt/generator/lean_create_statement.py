import sys
from leanstmt.generator.lean_module import LeanModule
from .lean_statement import Statement, Variable
from .lean_file import LeanFileRange, LeanFilePos
from .lean_variable import parse_var_decl, parse_lean_variable

class LeanCreateStatement:
    def __init__(self, module_name: str, module: LeanModule, 
                 variables: list[Variable], test_section: str = None):
        self.module_name = module_name
        self.module = module
        self.variables = variables
        self.test_section = test_section

    def create_lean_text(self, statement: Statement):
        text = ""

        bprint = False #"has_iUnion" in statement.name
        if bprint:
            print(f"statement.name: {statement.name}")

        fileRange = statement.fileRange
        include_section_ranges =[]
        exclude_section_ranges =[]
        for scopeInfo in self.module.getScopeRangeInfos():
            if scopeInfo.kind == "section" and scopeInfo.range.inRange(fileRange):
                if scopeInfo.range.inRange(fileRange):
                    exclude_section_ranges.append(scopeInfo.range)
                else:
                    include_section_ranges.append(scopeInfo.range)
            if bprint:
                print(f"scopeInfo: {scopeInfo}")            
            
        imprts = self.module.getImports()
        if imprts:
            for imprt in imprts:
                text += "import " + ".".join(imprt).strip() + "\n"
        if self.test_section:
            text += "import " + self.module_name + "\n"

        for scoped_info in exclude_section_ranges:
            text += "import " + f"{self.module_name}.{scoped_info.name.strip()}" + "\n"

        if statement.scope_info.open_decl:
            for open_decl in statement.scope_info.open_decl:
                text += "open " + open_decl.strip() + "\n"
        if statement.scope_info.scoped_open_decl:
            for scoped_open_decl in statement.scope_info.scoped_open_decl:
                text += "open scoped " + scoped_open_decl.strip() + "\n"

        for scoped_info in include_section_ranges:
            text += "namespace " + scoped_info.name.strip() + "\n"
            if bprint:
                print(f"scoped_info.name: {scoped_info}")    
        if statement.scope_info.namespace:
            text += "--namespace " + statement.scope_info.namespace.strip() + "\n"
        if bprint:
            print(f"statement.scope_info.namespace: {statement.scope_info}")
    
        if self.test_section:
            text += "section " + self.test_section.strip() + "\n"

        #if self.variables and statement.scope_info and statement.scope_info.var_decls:
        text += self.create_variable_text(exclude_section_ranges, 
                            statement.fileRange,statement.scope_info.var_decls) + "\n"
    
        text += self.create_statement_text(statement).strip() + "\n"
        return text
        
    def create_statement_text(self, statement: Statement, prefix_name: str = "test_"):
        text = ""

        attrs = self.create_attrs_text(statement.modifiers.attrs)
        if attrs:
            text += attrs.strip() + "\n"
        if statement.modifiers.visibility:
            text += statement.modifiers.visibility.strip() + " "
        if statement.modifiers.compute_kind:
            text += statement.modifiers.compute_kind.strip() + " "
        if statement.modifiers.rec_kind:
            text += statement.modifiers.rec_kind.strip() + " "
        if statement.modifiers.is_unsafe:
            text += "unsafe "
        if statement.modifiers.rec_kind_left:
            text += statement.modifiers.rec_kind_left.strip() + " "
        text += statement.command.strip() + " "
        if statement.modifiers.rec_kind_right:
            text += statement.modifiers.rec_kind_right.strip() + " "
        if hasattr(statement, "name") and statement.name:
            text += prefix_name + statement.name.strip() + " "
        if hasattr(statement, "signature") and statement.signature:
            text += statement.signature + " "
        if hasattr(statement, "value") and statement.value:
            text += statement.value.rstrip()
        return text.strip()

    def create_attrs_text(self, attrs: list):
        if attrs is None or len(attrs) == 0:
            return None
        text = ""
        for attr in attrs:
            if len(text) > 0:
                text += ", "
            if attr.kind and attr.kind != "global":
                text += attr.kind.strip() + " "
            text += attr.content.strip()
        return f"@[{text}]"
    
    def create_variable_text(self, exclude_section_ranges, fileRange, var_decls: list, bprint=False):    
        text = ""
        bprint = False
        if bprint:
            print(f"create_variable_text fileRange: {fileRange}")
        exclude_section_ranges.append(LeanFileRange(fileRange.stop, LeanFilePos(sys.maxsize, sys.maxsize)))
        for variable in self.module.getContextEntries():
            if not variable.kind in ["notation", "variable"]:
                continue
            valid_var = True
            for exclude_section_range in exclude_section_ranges:
                if exclude_section_range.inRange(variable.range):
                    if bprint:
                        print(f"exclude variable: {variable.content}, variable.fileRange: {variable.range}, exclude_section_range: {exclude_section_range}")
                    valid_var = False
                    break
            if valid_var:
                if bprint:
                    print(f"add variable: {variable.content}, variable.fileRange: {variable.range}, exclude_section_range: {exclude_section_range}")
                text += variable.content.rstrip() + "\n"
        return text
    
    def create_variable_text2(self, fileRange, var_decls: list):
        text = ""
        variables = []
        for variable in self.variables:
            if variable.fileRange.stop <= fileRange.start:
                content_vars = parse_lean_variable(variable.content)
                variables.append((variable.content.rstrip(), content_vars))
        for var_decl in var_decls:
            decl_vars, original_text = var_decl.split(" ||| ")
            vars = parse_var_decl(decl_vars)
            breaked = False
            for content, content_vars in reversed(variables):
                if vars == content_vars:
                    text += content + "\n"
                    breaked = True
                    break
            #if not breaked:
            #    for content, content_vars in reversed(variables):
            #        if original_text in content:
            #            text += content + "\n"
            #            breaked = True
            #            break
            if not breaked:
                print(f"NOT find: var_decl: |{var_decl}|, vars: |{vars}|, variables: |{variables}|")
        return text

        #for var_decl in var_decls:
        #     assert var_decl.startswith("variables:")
             #vars = " ".join(var_decl[len("variables:"):].replace(",", "").strip().split())
             #vars = "{ " + vars + " }"
        #     vars = parse_var_decl(var_decl)
        #     print(f"vars: |{vars}|, var_decl: |{var_decl}|")
        #     for variable in reversed(self.variables):
             #   variable_check = variable.content.replace("}", " } ").replace("{", " { ").replace("(", " { ").replace("[", " { ")
             #   variable_check = variable_check.replace(":", " } ").replace(")", " } ").replace("]", " } ").replace("\n", " ").replace("\t", " ")
             #   variable_check = " ".join(variable_check.split())
        #        variable_check = parse_lean_variable(variable.content)
        #        print(f"variable_check: |{variable_check}|, variable_content: |{variable.content}|")
        #        diff = vars - variable_check
        #        if len(diff) > 0:
        #            text += variable.content.strip() + "\n"
        #            vars = vars - diff
        #return text