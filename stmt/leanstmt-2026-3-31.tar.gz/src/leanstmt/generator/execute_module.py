import os
import io

from .lean_statement import Theorem
from .lean_project import LeanProject
from .perfect_print import LeanPerfectPrint
from .lean_create_statement import LeanCreateStatement  
from .verify import verify_lean


"""
-- 1. Imports (通常從檔案頭部抓取)
import Mathlib.CategoryTheory.Basic

-- 2. Namespaces (來自 scope_info.curr_namespace)
namespace Mathlib.LibraryNote

-- 3. Opens (來自 scope_info.open_decl)
open CategoryTheory

-- 4. Context Variables (來自 scope_info.var_decls)
variable {C : Type u} [Category.{v} C] {X : C}

-- 5. Private Dependencies (如果有的話，從你的資料庫抓取)
private def helper_func := ...

-- 6. The Theorem Itself (你原始擷取的 Range)
protected theorem «exists» ... := by
  ... 證明主體 ...

end Mathlib.LibraryNote

"""

def verify(root_dir, statement_text):
    lean_file = "test.lean"
    lean_path = os.path.join(root_dir,lean_file)
  
    with open(lean_path, "w", encoding="utf-8") as f:
        f.write(statement_text)
        f.write("\n")

    return_code, message = verify_lean(root_dir, lean_file)

    return return_code, message

def print_statement(text, var_decls,output: io.StringIO = None):
    if output is None:
        output = io.StringIO()
    print("=====================================================", file=output)
    print(text, file=output)
    print("-----------------------------------------------------", file=output)
    if var_decls:
        for var_decl in var_decls:
            print(var_decl, file=output)
    print("=====================================================", file=output)

def executeModule(root_dir, module_name, print_content: bool = False, verify_check: bool = True):
    project = LeanProject(root_dir)
    module = project.get_module(module_name)

    statements = module.getStatements()
    variables = []
    for statement in statements:
        if statement.kind == "variable":
            variables.append(statement)

    statements = module.getStatements()
    output = io.StringIO()
    count = 0
    diff_count = 0
    for statement in statements:
        if statement.kind != "theorem":
            continue
        #print(f"Processing module: {module_name}, theorem: {statement.name} {statement.scope_info}")
        count = count + 1
        theorem: Theorem = statement

        create_statement = LeanCreateStatement(module_name, module, variables, "ValidateTest")

        statement_text = create_statement.create_lean_text(theorem)
        if print_content:
            print_statement(statement_text, output)

        if verify_check:
            return_code, message = verify(root_dir, statement_text)
            if return_code == 0:
                print(f"module: {module_name}, theorem: {theorem.name} pass testing", file=output)
            else:
                diff_count = diff_count + 1
                print(f"module: {module_name}, theorem: {theorem.name} fails with {message}", file=output)
                if not print_content:
                    print_statement(statement_text, statement.scope_info.var_decls, output)

    return_str = output.getvalue()
    return return_str, count, diff_count
