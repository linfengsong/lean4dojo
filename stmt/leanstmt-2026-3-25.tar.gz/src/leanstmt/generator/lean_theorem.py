import logging
from dataclasses import dataclass
from dataclasses_json import dataclass_json
from ..core.core_datasets import CoreDeclaration
from .lean_file import LeanFile, LeanFileRange
from .lean_statement import Statement
from .lean_elab import TacticProof, find_term, find_tactricProof

@dataclass_json
@dataclass(frozen=True, eq=False)
class TheoremAttribute:
    kind: str
    name: str
    fileRange: LeanFileRange

@dataclass_json
@dataclass(frozen=True, eq=False)
class Theorem(Statement):
    name: str

    namespace: str
    open_decl: list[str]

    attrs: list[TheoremAttribute]

    signature: str
    signatureFileRange: LeanFileRange

    proofOperator: str

    proof: str
    proofFileRange: LeanFileRange
    proofType: str
    
    tacticProof: TacticProof
    refTacticProofs: list[TacticProof]

    term_before: list

    def __str__(self):
        return f"range={self.fileRange}, name={self.name}, type={self.proofType}, proofTactic: {self.tacticProof}"
    
    def __eq__(self, other):
        return self.name == self.name and \
               self.fileRange == other.fileRange and \
               self.proofOperator == other.proofOperator and \
               self.tacticProof == other.tacticProof

def getToken(line: str, index: int):
    tokens = line.strip().replace("\n", " ").replace("\r", " ").replace("\t", " ").split()
    if index < 0:
        index = len(tokens) + index
    if index >= len(tokens):
        return None
    return tokens[index]

def getTheoremName(module_name: list[str], decl: CoreDeclaration):
    #first item is "_private" if it's a private declaration, we need to remove the prefix and get the real name
    # for example, if the declaration name is ["_private", "Init", "Nat", "add"], and the module name is ["Init", "Nat"], we need to remove the prefix and get the real name "add"  
    if decl.name is None or len(decl.name) == 0:
        return None
    if decl.name[0] != '_private':
        return ".".join(decl.name)
    private_name = decl.name[len(module_name) + 2:]
    return ".".join(private_name)

def extract_theorem(leanFile: LeanFile, module_name, decl, tacticProofs, terms):
    theorem_name = getTheoremName(module_name, decl)
    theorem_range = leanFile.createFileRange(decl.ref.range)
    theorem_proofRange = leanFile.createFileRange(decl.value.range)
    signatureRange = leanFile.createFileRange(decl.signature.range)
    content = leanFile.remove_comment(leanFile.getTextFromLineModule(theorem_range))
    if theorem_range == theorem_proofRange:
        # when statement has MACRO, Declarration.lean already process STX by MACRO produced statement
        statement = leanFile.remove_comment(decl.value.pp)
        signature = leanFile.remove_comment(decl.signature.pp)
    else:
        statement = leanFile.remove_comment(leanFile.getTextFromLineModule(theorem_proofRange))
        signature = leanFile.remove_comment(leanFile.getTextFromLineModule(signatureRange))
        
    tacticProofs = find_tactricProof(theorem_proofRange, tacticProofs)

    proofOperator = getToken(statement, 0)
    if proofOperator.startswith(":="):
        proofOperator = ":="
    if proofOperator != ":=" and proofOperator != "|" and proofOperator != "where":
        logging.warning(f"proofOperator {proofOperator}  is not valid, remove: {theorem_name} {module_name}")
        return None

    if statement is None:
        logging.warning(f"no proof, remove: {theorem_name} {module_name}")
        return None
    if proofOperator is None:
        logging.warning(f"no proofOperator, remove: {theorem_name} {module_name}")
        return None
    
    namespace = ".".join(decl.scope_info.curr_namespace) if decl.scope_info and decl.scope_info.curr_namespace else None

    open_decl = None
    if decl.scope_info and decl.scope_info.open_decl:
        open_decl = []
        for open_dl in decl.scope_info.open_decl:
            if open_dl.simple:
                open_ns = ".".join(open_dl.simple.namespace)
                open_decl.append(open_ns)
    
    attrs = []
    for attr in decl.modifiers.attrs:
        attrFileRange = leanFile.createFileRange(attr.stx)
        attrName = ".".join(attr.name)
        attrs.append(TheoremAttribute(attr.kind, attrName, attrFileRange))  
    
    if proofOperator != "|": 
        statement = statement.rstrip()[len(proofOperator) + 1:]
    startBy = True
    byToken = getToken(statement, 0)
    if byToken is None or byToken != "by":
        startBy = False

    theorem_proof = statement
    term_before = None
    tacticProof = None
    proofType = "Term"
    refTacticProofs =None
    if startBy:
        proofType = "Tactic"
        if len(tacticProofs) > 0:
            tacticProof = tacticProofs.pop(0)
        else:
            # when proof content is only MACRO, it does not have tactic generated in Lean
            # it needs fix
            pure_proof = " ".join(theorem_proof.replace("\n"," ").replace("\t"," ").split(" "))
            if " " in pure_proof:
                logging.info(f"ERROR cannot find tacticProof: {theorem_name} {module_name}, theorem_proof: {theorem_proof}")
                return None
    if len(tacticProofs) > 0:
        refTacticProofs = tacticProofs
    if tacticProof is None:
        name_array = theorem_name.split(".")
        term = None
        while term is None and len(name_array) > 0:
            search_name = ".".join(name_array)
            term = find_term(theorem_range, search_name, terms)
            if term is None and not search_name.startswith("@"):
                search_name = "@" + search_name
                term = find_term(theorem_range, search_name, terms)
            name_array.pop(0)
        if term is None:
            search_name = "_root_." + theorem_name
            term = find_term(theorem_range, search_name, terms)
            if term is None:
                search_name = "@" + search_name
                term = find_term(theorem_range, search_name, terms)
        if term is None:
            search_name = "«" + theorem_name.split('.')[-1] + "»"
            term = find_term(theorem_range, search_name, terms)
            if term is None:
                search_name = "@" + search_name
                term = find_term(theorem_range, search_name, terms)

        if term is not None:
            term_before = term.type
        elif startBy:
            logging.info(f"ERROR tactic_before is none on Tactic: {theorem_name} {module_name}")
            pass
        else:
            if decl.name[0] != '_private':
                logging.info(f"tactic_before is none, remove: {theorem_name} {module_name}")
                pass
            return None

    return Theorem(decl,content, theorem_range, theorem_name, namespace, open_decl, attrs, signature, signatureRange, proofOperator, theorem_proof, theorem_proofRange, proofType, tacticProof, refTacticProofs, term_before)
