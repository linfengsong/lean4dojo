import os
from .lean_project import LeanProject, LeanModule
from .perfect_print import LeanPerfectPrint
from .verify import verify_lean

def verify(lines: list[str]):
    lean_file = "test.lean"
    lean_path = os.path.join(root_dir,lean_file)
  
    with open(lean_path, "w", encoding="utf-8") as f:
        for line in lines:
            f.write(line)
            f.write("\n")

    return_code, message = verify_lean(root_dir, lean_file)

    return return_code, message

def print_lines(lines: list[str]):
    print("=====================================================")
    for line in lines:
        print(line)
    print("=====================================================")

def main2(root_dir: str, module_name: str, print_content: bool = False, verify_check: bool = True):

    project = LeanProject(root_dir)
    module = project.get_module(module_name)
    imports = module.getImports()
    imports.append(module_name.split("."))

    variables = []
    for variable in module.getVariables():
        variables.append(variable.content)

    for theorem in module.getTheorems():
        #print(f"docstring: {theorem.coreDeclaration.modifiers.docstring}")
        #print(f"attrs: {theorem.coreDeclaration.modifiers.attrs}")
        #print(f"Content: {theorem.content[:50]}")
        attrs = None
        if theorem.coreDeclaration.modifiers.attrs:
            attrs = []
            for attr in  theorem.attrs:
                attrName = attr.name
                attrs.append(f"@[{attrName}]") 
        proofOperator = theorem.proofOperator
        if proofOperator == "|":
            proofOperator = None
        open_decl = []
        if theorem.namespace:
            open_decl.append(theorem.namespace)
        if theorem.open_decl:
            for decl in theorem.open_decl:
                open_decl.append(decl)
        
        pp = LeanPerfectPrint("theorem",
                              attrs,
                              "Test." + theorem.name, 
                              theorem.signature,
                              proofOperator, 
                              theorem.proof, 
                              module.getImports(),
                              open_decl,
                              variables)
        lines = pp.printLines()
        if print_content:
            print_lines(lines)

        if verify_check:
            return_code, message = verify(lines)
            if return_code == 0:
                print(f"module: {module_name}, theorem: {theorem.name} pass testing")
            else:
                print(f"module: {module_name}, theorem: {theorem.name} fails with {message}")
                if not print_content:
                    print_lines(lines)

def main(root_dir: str, module_name: str, print_content: bool = False, verify_check: bool = True):
    project = LeanProject(root_dir)
    module = project.get_module(module_name)
    for statement in module.getStatements():
        if statement.kind == "structure": #"example": #"opaque": #"inductive": #"opaque": #"abbrev":#"definition": #"instance": #"structure": 
            print(f"name: {statement.name}")
            print(f"content: {statement.content}")
            print(f"signature: {statement.signature}")
            print(f"signatureRange: {statement.signatureRange} {statement.coreDeclaration.signature.range if statement.coreDeclaration.signature and statement.coreDeclaration.signature.range else None}")
            print(f"value: {statement.value}")
            print(f"valueRange: {statement.valueRange} {statement.coreDeclaration.value.range if statement.coreDeclaration.value and statement.coreDeclaration.value.range else None}")
            #print(f"scope_info {statement.coreDeclaration.scope_info}")
            print(f"scope_info {statement.coreDeclaration.modifiers}")

if __name__ == "__main__":
    root_dir = "/home/linfe/math/lean_test"
    module_name = "LeanTest.Basic"
    module_name = "Mathlib.Data.Nat.Init"
    module_name = "Mathlib.Tactic.Widget.LibraryRewrite"
    #module_name = "Mathlib.Util.MemoFix"
    #module_name = "Mathlib.RingTheory.TensorProduct.Basic"
    #module_name = "Mathlib.MeasureTheory.Function.LpSpace.Basic"
    main(root_dir, module_name, print_content=False, verify_check=True)
    #main2(root_dir, module_name, print_content=False, verify_check=True)

    # python -m leanstmt.generator.test