from dataclasses import dataclass
from dataclasses_json import dataclass_json
from ..core.core_project import CoreModule
from ..core.core_datasets import CoreDeclaration, CoreInfoTree
from .lean_statement import Abbrev, Declaration, Example, Inductive, Instance, Opaque, Structure, Variable
from .lean_theorem import extract_theorem
from .lean_file import LeanFile, LeanFileRange
from .lean_elab import collect_all_terms, collect_all_tacticProofs

@dataclass_json
@dataclass(frozen=True)
class LeanModule:
    name: str
    coreModule: CoreModule

    def getImports(self):
        return self.coreModule.moduleInfo.imports
    
    def getDocuments(self):
        return self.coreModule.moduleInfo.docstring
    
    def getStatements(self):
        leanFile = LeanFile(self.coreModule.lean_file, self.coreModule.lines)
        declarations:list[CoreDeclaration] = self.coreModule.decls
        infoTrees: list[CoreInfoTree] = self.coreModule.infoTrees
        tacticProofs = collect_all_tacticProofs(leanFile, infoTrees)
        terms = collect_all_terms(leanFile, infoTrees, self.name)
        statements = []
        for _, decl in enumerate(declarations):
            name = decl.name
            fileRange = leanFile.createFileRange(decl.ref.range)
            content = leanFile.remove_comment(leanFile.getTextFromLineModule(fileRange))
            signatureRange = leanFile.createFileRange(decl.signature.range) if decl.signature and decl.signature.range else None
            signature = leanFile.remove_comment(leanFile.getTextFromLineModule(signatureRange)) if signatureRange else None
            valueRange = leanFile.createFileRange(decl.value.range) if decl.value and decl.value.range else None
            value = leanFile.remove_comment(leanFile.getTextFromLineModule(valueRange)) if valueRange else None

            if decl.kind == "abbrev":
                statement = Abbrev(decl, content, fileRange, name, signature, signatureRange, value, valueRange)
            elif decl.kind == "definition":
                statement = Declaration(decl, content, fileRange, name, signature, signatureRange, value, valueRange)
            elif decl.kind == "example":
                statement = Example(decl, content, fileRange, name, signature, signatureRange, value, valueRange)
            elif decl.kind == "inductive":
                statement = Inductive(decl, content, fileRange, name, signature, signatureRange, value, valueRange)
            elif decl.kind == "instance":
                statement = Instance(decl, content, fileRange, name, signature, signatureRange, value, valueRange)
            elif decl.kind == "opaque":
                statement = Opaque(decl, content, fileRange, name, signature, signatureRange, value, valueRange)
            elif decl.kind == "structure":
                index = content.find("where")
                if index > 0:
                    value = content[index:]
                statement = Structure(decl, content, fileRange, name, signature, signatureRange, value, valueRange)       
            elif decl.kind == "theorem":
                if len(name) > 0: #?
                    # and theorem.proofOperator == ":=" and theorem.proofType == "Tactic":
                    statement = extract_theorem(leanFile, self.name, decl, tacticProofs, terms)
            elif decl.kind == "variable":
                statement = Variable(decl, content, fileRange)
            else:
                statement = None
            if statement is not None: 
                statements.append(statement)
        return statements
    
    def getTheorems(self):
        leanFile = LeanFile(self.coreModule.lean_file, self.coreModule.lines)
        declarations:list[CoreDeclaration] = self.coreModule.decls
        infoTrees: list[CoreInfoTree] = self.coreModule.infoTrees
        tacticProofs = collect_all_tacticProofs(leanFile, infoTrees)
        terms = collect_all_terms(leanFile, infoTrees, self.name)
        theorems = []
        for _, decl in enumerate(declarations):
            if decl.kind == "theorem":
                if len(decl.name) == 0:
                    continue
                theorem = extract_theorem(leanFile, self.name, decl, tacticProofs, terms)
                if theorem is not None: # and theorem.proofOperator == ":=" and theorem.proofType == "Tactic":
                    theorems.append(theorem)
        return theorems
    
    def getVariables(self):
        leanFile = LeanFile(self.coreModule.lean_file, self.coreModule.lines)
        declarations:list[CoreDeclaration] = self.coreModule.decls
        variables = []
        for _, decl in enumerate(declarations):
            if decl.kind == "variable":
                fileRange = leanFile.createFileRange(decl.ref.range)
                content = leanFile.remove_comment(leanFile.getTextFromLineModule(fileRange))
                variables.append(Variable(decl, content, fileRange))
        return variables

