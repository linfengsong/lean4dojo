from dataclasses import dataclass
from dataclasses_json import dataclass_json
from ..core.core_project import CoreModule
from ..core.core_datasets import CoreDeclaration, CoreInfoTree
from .lean_file import LeanFileRange


@dataclass_json
@dataclass(frozen=True)
class Statement:
    coreDeclaration: CoreDeclaration

    content: str
    fileRange: LeanFileRange

    @property
    def kind(self):
        return self.coreDeclaration.kind
    
@dataclass_json
@dataclass(frozen=True)
class Abbrev(Statement):
    name: str

    signature: str
    signatureRange: LeanFileRange
    value: str
    valueRange: LeanFileRange
    
@dataclass_json
@dataclass(frozen=True)
class Declaration(Statement):
    name: str

    signature: str
    signatureRange: LeanFileRange
    value: str
    valueRange: LeanFileRange

@dataclass_json
@dataclass(frozen=True)
class Example(Statement):
    name: str

    signature: str
    signatureRange: LeanFileRange
    value: str
    valueRange: LeanFileRange

@dataclass_json
@dataclass(frozen=True)
class Inductive(Statement):
    name: str

    signature: str
    signatureRange: LeanFileRange
    value: str
    valueRange: LeanFileRange

@dataclass_json
@dataclass(frozen=True)
class Instance(Statement):
    name: str

    signature: str
    signatureRange: LeanFileRange
    value: str
    valueRange: LeanFileRange

@dataclass_json
@dataclass(frozen=True)
class Opaque(Statement):
    name: str

    signature: str
    signatureRange: LeanFileRange
    value: str
    valueRange: LeanFileRange

@dataclass_json
@dataclass(frozen=True)
class Structure(Statement):
    name: str

    signature: str
    signatureRange: LeanFileRange
    value: str
    valueRange: LeanFileRange
    
@dataclass_json
@dataclass(frozen=True)
class Variable(Statement):
    pass
