python -m leanstmt.core.jixia_extract "/home/linfe/math/lean_test" --search_list Mathlib,Init,LeanTest
python -m leanstmt.generator.test
