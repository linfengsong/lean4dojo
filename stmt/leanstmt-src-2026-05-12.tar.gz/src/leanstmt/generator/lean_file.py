import sys
import re
from typing import Optional, List
from dataclasses import dataclass, field
from dataclasses_json import dataclass_json
from functools import total_ordering
from ..core.core_datasets import CoreStringRange, CoreLineModel

@total_ordering
@dataclass_json
@dataclass(frozen=True, order=False)
class LeanFilePos:
    line: int
    column: int

    def __str__(self):
        return self.to_json()
    
    def __eq__(self, other):
        return self.line == other.line and self.column == other.column
    
    def __lt__(self, other):
        return self.line < other.line or self.line == other.line and self.column < other.column

    @classmethod
    def createFilePos(cls, lines: list[CoreLineModel], bytePos: int):
        if len(lines) == 0:
            return cls(1, 1)
        start = 0
        lineNum = 1
        for index, line in enumerate(lines):
            if line.start > bytePos:
                break
            start = line.start
            lineNum = index + 1
        if lineNum > len(lines):
            lineNum = len(lines)
            bytePos = sys.maxsize
        textline = lines[lineNum - 1].line
        if textline is None:
            lineNum = lineNum -1
            bytePos = sys.maxsize
            textline = lines[lineNum - 1].line
        encoded_bytes = textline.encode("utf-8")[:bytePos - start]
        text = encoded_bytes.decode("utf-8")
        column = len(text) + 1
        return cls(lineNum, column)

@total_ordering
@dataclass_json
@dataclass(frozen=True, order=False)
class LeanFileRange:
    start: LeanFilePos
    stop: LeanFilePos

    def __str__(self):
        return self.to_json()
    
    def __eq__(self, other):
        return self.start == other.start and self.stop == other.stop
    
    def __lt__(self, other):
        return self.start < other.start or self.start == other.start and self.stop >= other.stop
    
    def inRange(self, fileRange):
        return self.start <= fileRange.start and fileRange.stop <= self.stop


class LeanLineModel():
    """An Line node with line information"""
    start: int
    line: str

    def __init__(self, start: int, line: str):
        self.start = start
        self.line = line

    def __str__(self):
        return self.to_json()

class LeanFile():
    """An Lean node with lean file information"""
    lines: list[LeanLineModel]

    def __init__(self, lineModels: list[CoreLineModel]):
        lines = []
        for line in lineModels:
            lines.append(LeanLineModel(line.start, line.line))
        assert(len(lines) > 0)
        self.lines = lines

    def createFileRange(self, stringRange: CoreStringRange):
        lines = self.lines
        start = LeanFilePos(1, 1)
        stop = LeanFilePos(len(lines) + 1, 1)
        if stringRange is not None:
            if stringRange.start is not None:
                start = LeanFilePos.createFilePos(lines, int(stringRange.start))
            if stringRange.stop is not None:
                stop  = LeanFilePos.createFilePos(lines, int(stringRange.stop))
        return LeanFileRange(start, stop)
    
    def nextPos(self, pos: LeanFilePos):
        if pos is None:
            return None
        length = len(self.lines)
        if length == 0:
            return LeanFilePos(1, 1)
        line = self.lines[pos.line - 1]
        if pos.column < len(line.line):
            return LeanFilePos(pos.line, pos.column + 1)
        if pos.line == length:
            return pos
        return LeanFilePos(pos.line + 1, 1)

    def getTextFromLineModule(self, fileRange: LeanFileRange):
        start_line = fileRange.start.line - 1
        stop_line = fileRange.stop.line - 1
        start_col = fileRange.start.column - 1
        stop_col = fileRange.stop.column
        if start_line < 0 or stop_line >= len(self.lines):
            return ""
        content = self.lines[start_line].line or ""
        if start_line == stop_line:
            return content[start_col:stop_col]
        result = []
        first_line = content
        result.append(first_line[start_col:])
        for i in range(start_line + 1, stop_line):
            result.append(self.lines[i].line or "")
        last_line = self.lines[stop_line].line or ""
        result.append(last_line[:stop_col])
        return "".join(result)

    def remove_comment(self, text: str):
        if text is None:
            return text
        result = []
        i = 0
        depth = 0
        n = len(text)
        while i < n:
            if text[i:i+2] == "/-":
                depth += 1
                i += 2
            elif text[i:i+2] == "-/" and depth > 0:
                depth -= 1
                i += 2
                if depth == 0:
                    result.append(" ")
            else:
                if depth == 0:
                    result.append(text[i])
                i += 1
        text = "".join(result)

        lines = []
        for line in text.split("\n"):
            index = line.find("--")
            if index >= 0:
                line = line[:index]
            if line.rstrip().endswith("#adaptation_note"):
                lines.append(line.rstrip()[:-len("#adaptation_note")])
            else:
                lines.append(line)
        text = "\n".join(lines)
        return text
    
    def space_comment(self, text: str):
        if text is None:
            return text
        result = []
        i = 0
        depth = 0
        n = len(text)
        while i < n:
            if text[i:i+2] == "/-":
                depth += 1
                i += 2
                result.append("  ")
            elif text[i:i+2] == "-/" and depth > 0:
                depth -= 1
                i += 2
                result.append("  ")
            else:
                if depth == 0:
                    result.append(text[i])
                else:
                    result.append(" ")
                i += 1
        text = "".join(result)

        lines = []
        for line in text.split("\n"):
            index = line.find("--")
            if index >= 0:
                line = line[:index] + " " * (len(line) - index)
            if line.rstrip().endswith("#adaptation_note"):
                lines.append(line.replace("#adaptation_note", "                "))
            else:
                lines.append(line)
        text = "\n".join(lines)
        return text
    
    def _is_ident_char(self, ch: str) -> bool:
        return ch.isalnum() or ch in {"_", "'"}

    def get_ident_ranges(self, ident_name: str, range: LeanFileRange) -> List[LeanFileRange]:
        out = []
        block_comment_depth = 0
        in_string = False
        for i, lineModel in enumerate(self.lines):
            if i + 1 < range.start.line:
                continue
            if i >= range.stop.line:
                break
            raw_line = lineModel.line
            line = raw_line.rstrip("\n\r")
            n = len(line)

            abs_line = i + 1
            j = 0
            while j < n:
                ch = line[j]
                if block_comment_depth > 0:
                    if j + 1 < n and line[j:j+2] == "/-":
                        block_comment_depth += 1
                        j += 2
                        continue
                    if j + 1 < n and line[j:j+2] == "-/":
                        block_comment_depth -= 1
                        j += 2
                        continue
                    j += 1
                    continue
                if in_string:
                    if ch == "\\" and j + 1 < n:
                        j += 2
                        continue
                    if ch == '"':
                        in_string = False
                        j += 1
                        continue
                    j += 1
                    continue
                if j + 1 < n and line[j:j+2] == "--":
                    break
                if j + 1 < n and line[j:j+2] == "/-":
                    block_comment_depth = 1
                    j += 2
                    continue
                if ch == '"':
                    in_string = True
                    j += 1
                    continue
                if line.startswith(ident_name, j):
                    left_ok = (j == 0) or (not self._is_ident_char(line[j - 1]))
                    end_j = j + len(ident_name)
                    right_ok = (end_j >= n) or (not self._is_ident_char(line[end_j]))
                    if left_ok and right_ok:
                        if i == 0:
                            start_col = range.start.column + j
                        else:
                            start_col = 1 + j
                        stop_col = start_col + len(ident_name) - 1
                        if abs_line < range.stop.line or stop_col <= range.stop.column:
                            out_range = LeanFileRange(LeanFilePos(abs_line, start_col), LeanFilePos(abs_line, stop_col))
                            out.append(out_range)
                    j = end_j
                    continue
                j += 1
        return out