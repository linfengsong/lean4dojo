from ..core.core_project import CoreProject

from .lean_module import LeanModule


class LeanProject:
    coreProject: CoreProject

    def __init__(self, root_dir):
        self.coreProject = CoreProject(root_dir, ".jixia")

    def get_module(self, module_name):
        module = self.coreProject.fetch_module(module_name)
        if module is None:
            return None
        return LeanModule(module_name, module)
