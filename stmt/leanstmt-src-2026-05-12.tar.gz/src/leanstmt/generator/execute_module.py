import os
import io
import sys
import traceback
import difflib
from .lean_statement import Theorem
from .lean_project import LeanProject
from .lean_create_module import ExclusiveConfig, LeanCreateModule
from .lean_create_statement import LeanCreateStatement, ConfigParameter
from .verify import verify_lean

"""
-- 1. Imports (通常從檔案頭部抓取)
import Mathlib.CategoryTheory.Basic

-- 2. Namespaces (來自 scope_info.curr_namespace)
namespace Mathlib.LibraryNote

-- 3. Opens (來自 scope_info.open_decl)
open CategoryTheory

-- 4. Context Variables (來自 scope_info.var_decls)
variable {C : Type u} [Category.{v} C] {X : C}

-- 5. Private Dependencies (如果有的話，從你的資料庫抓取)
private def helper_func := ...

-- 6. The Theorem Itself (你原始擷取的 Range)
protected theorem «exists» ... := by
  ... 證明主體 ...

end Mathlib.LibraryNote

"""
    
def verify(root_dir, lean_file, statement_text):
    lean_path = os.path.join(root_dir,lean_file)
  
    with open(lean_path, "w", encoding="utf-8") as f:
        f.write(statement_text)
        f.write("\n")

    return_code, message = verify_lean(root_dir, lean_file)

    return return_code, message

def print_statement(text, output: io.StringIO = None):
    if output is None:
        output = sys.stdout
    print("---------------------- Source Code ------------------", file=output)
    print(text, file=output)
    print("=====================================================", file=output)

def print_debug_info(text, diff_text, output: io.StringIO = None):
    if output is None:
        output = sys.stdout
    print("---------------------- DEBUG -----------------------", file=output)
    print(text, file=output)
    if diff_text:
        print("---------------------- DIFF -----------------------", file=output)
        print(diff_text, file=output)

def get_line_diffs(text, safeFile):
    if text and len(text) == 0 or not os.path.exists(safeFile):
        return None
    lines1 = text.splitlines()
    with open(safeFile, 'r', encoding='utf-8') as f:
        text2 = f.read()
        lines2 = text2.splitlines()
        diff = difflib.ndiff(lines2, lines1)
        return "\n".join([line for line in diff if line.startswith('+ ') or line.startswith('- ') or line.startswith('? ')])

def executeModule(root_dir: str, exclusiveConfig: ExclusiveConfig, module_name: str, print_content: bool = False, verify_check: bool = True):
    try:
        return executeModuleInternal(root_dir, exclusiveConfig, module_name, print_content, verify_check, True)
    except Exception as e:
        full_traceback = traceback.format_exc()
        result_str = f"Process failure on {module_name}:\n{full_traceback}\n"
        return result_str, 1, 1

def executeModuleInternal(root_dir: str, exclusiveConfig: ExclusiveConfig, module_name: str, 
                          print_content: bool = False, verify_check: bool = True, bDebug: bool = False):
    project = LeanProject(root_dir)
    module = project.get_module(module_name)

    create_module = LeanCreateModule(exclusiveConfig, module_name, module)

    output = io.StringIO()
    
    count = 0
    diff_count = 0
    hasPrivateInstances = create_module.hasPrivateInstances()
    for statement in create_module.getCreateStatements():
        #print(f"Processing module: {module_name}, theorem: {statement.name} {statement.scope_info}")
        count = count + 1

        debug_output = io.StringIO() if bDebug else None
        statement_name = statement.name
        isValid, statement_text = statement.create_lean_text(debug_output)
            
        if isValid:
            if verify_check:
                output_dir = root_dir + "/.test/" + module_name
                os.makedirs(output_dir, exist_ok=True)
                lean_file = output_dir + "/" + statement.name + ".lean"

                save_output_dir = root_dir + "/.save/" + module_name
                save_lean_file = save_output_dir + "/" + statement.name + ".lean"
                return_code, message = verify(root_dir, lean_file, statement_text)
                retryVerify = False
                if return_code != 0 and hasPrivateInstances:
                    config_parameters = [ConfigParameter("instance")]
                    retryVerify = True
                    isValid, statement_text = statement.create_lean_text(debug_output, config_parameters)
                    return_code, message = verify(root_dir, lean_file, statement_text)

                if return_code == 0:
                    print(f"module: {module_name}, theorem: {statement_name} pass testing", file=output)
                    os.makedirs(save_output_dir, exist_ok=True)
                    if os.path.exists(save_lean_file):
                        os.remove(save_lean_file)
                    os.rename(lean_file, save_lean_file)
                    if print_content:
                        if debug_output:
                            print_debug_info(debug_output.getvalue(), None, output)
                        print_statement(statement_text, output)
                else:
                    invalid = False
                    if exclusiveConfig.config:
                        exclusiveMsgs = exclusiveConfig.getConfigList("error_message")
                        if exclusiveMsgs:
                            for msg in exclusiveMsgs:
                                if msg in message:
                                    invalid = True
                    if invalid:
                        first_line = message.split("\n")[0]
                        print(f"module: {module_name}, theorem: {statement_name} invalid {first_line}", file=output)
                        if retryVerify:
                            print(f"    -- retry again with {config_parameters}", file=output)
                    else:
                        diff_count = diff_count + 1
                        print(f"module: {module_name}, theorem: {statement_name} fails with {message}", file=output)
                        if retryVerify:
                            print(f"    -- retry again with {config_parameters}", file=output)
                        if debug_output:
                            diff_text = get_line_diffs(statement_text, save_lean_file)
                            print_debug_info(debug_output.getvalue(), diff_text, output)
                            print_statement(statement_text, output)

    return_str = output.getvalue()
    return return_str, count, diff_count
