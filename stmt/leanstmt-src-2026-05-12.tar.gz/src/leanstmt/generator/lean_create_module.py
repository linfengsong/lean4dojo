from dataclasses import dataclass
from leanstmt.generator.lean_module import LeanModule
from .lean_file import LeanFilePos, LeanFileRange

Lean_keywords = [
    "def", "theorem", "lemma", "example",
    "inductive", "structure", "class", "instance",
    "constant", "axiom", "abbrev",
    "variable", "variables",
    "if", "then", "else",
    "match", "nomatch", "with",
    "do", "let", "mut",
    "for", "in", "at",
    "try", "catch", "finally",
    "return", "break", "continue",
    "forall", "exists",
    "fun", "λ",
    "have", "show", "suffices",
    "by",
    "from",
    "import", "prelude", "namespace", "section", "end",
    "open", "export", "hiding", "renaming",
    "private", "protected", "noncomputable", "unsafe", "partial",

    "infix", "infixl", "infixr",
    "postfix", "prefix",
    "notation",
    "macro",
    "syntax",
    "declare_syntax_cat", 
    "intro", "intros",
    "apply", "exact", "refine",
    "cases", "induction",
    "rewrite", "rw",
    "simp", "dsimp", "aesop",
    "refl", "rfl",
    "abbrev",
    "opaque","axiom", "constant",
    "attribute",
    "elab", "elab_rules", 
    "sorry",
    "forall", "exists",
    "true", "false" 
    "cexp",
]

class ExclusiveConfig: 
    def __init__(self, data: dict[str, list[str]]):
        self.config: dict[str, list[str]] = data

    def getConfigList(self, name: str):
        if self.config is None:
            return None
        return self.config[name] if name in self.config.keys() else None

@dataclass(frozen=True)
class ContextText:
    text: str
    comment: str
    pos: LeanFilePos
    blockIndex: int = None

@dataclass(frozen=True)
class DependentStatement:
    internal_name: str
    name: str
    kind: str
    protectedStatement: bool
    fileRange: LeanFileRange
    dependentStatements: list
    privateSymbol: bool

    @classmethod
    def create(cls, statement, dependentStatements, privateSymbol):
        return cls(
             ".".join([str(part) for part in statement.internal_name]),
             statement.name,
             statement.kind,
             statement.is_protected(),
             statement.fileRange,
             dependentStatements,
             privateSymbol
        )

@dataclass(frozen=True)
class ConfigParameter:
    namespace: str
    statement_name: str
    kind: str
    arguments: dict

class LeanCreateModule:
    alter_namespace: str = "LeanTest"
    config_parameters: list[ConfigParameter]

    def __init__(self, exclusiveConfig: ExclusiveConfig, module_name: str, module: LeanModule):
        self.exclusiveConfig = exclusiveConfig
        self.module_name = module_name
        self.module = module

        persistent_with_def = True
        statement_full_name_dict, persistant_name_dict = self._get_statement_name_dict(persistent_with_def)
        scope_instance_name_dict = self._get_scope_instance_name_dict()

        self._statements = []
        persistant_symbol_name_dict = {}
        all_namespaces = set()
        from .lean_create_statement import LeanCreateStatement
        for statement in module.statements:
            bprint = False #statement.kind == "irreducible_def" and statement.name == "mul" #statement.name == "npow" and statement.kind == "irreducible_def" #"linftyOpIsBoundedSMul" in statement.name #"delabFinsetArg" in statement.name
            statementSymbol = self.module.getStatementSymbol(statement, bprint)
            statementInstanceSymbol = self.module.getStatementInstanceSymbol(statement)
            if bprint: print(f"statement: {statement.id}, {statement.name}, statementInstanceSymbol: {statementInstanceSymbol}")
            dependent_statements, scope_namespaces = self._get_dependent_statements_from_symbols(statement_full_name_dict, scope_instance_name_dict, statementSymbol, statementInstanceSymbol, bprint)
            if bprint: print(f"statement: {statement.id}, {statement.name}, dependent_statements: {dependent_statements}")
            stmt_persistant_symbol_name_dict = self._get_persistant_symbol_name_dict(persistant_name_dict, statementSymbol, statementInstanceSymbol)
            if bprint: print(f"statement: {statement.id}, {statement.name}, stmt_persistant_symbol_name_dict: {stmt_persistant_symbol_name_dict}")
            for name in stmt_persistant_symbol_name_dict.keys():
                if not name in persistant_symbol_name_dict.keys():
                    persistant_symbol_name_dict[name] = stmt_persistant_symbol_name_dict[name]
            stmt = LeanCreateStatement(self, statement, stmt_persistant_symbol_name_dict.keys(), dependent_statements, scope_namespaces)
            self._statements.append(stmt)
            if statement.internal_namespace and not statement.internal_namespace in all_namespaces:
                all_namespaces.add(statement.internal_namespace)

        self.persistant_symbol_name_dict = persistant_symbol_name_dict
        self.all_namespaces = all_namespaces
        self.all_protected_statement_fullnames = []
        for full_name in statement_full_name_dict.keys():
            if statement_full_name_dict[full_name].protectedStatement:
                self.all_protected_statement_fullnames.append(full_name)

    def getStatements(self):
        return self._statements
    
    def getStatement(self, id):
        iId = int(id)
        if iId >= 0  and iId < len(self._statements):
            return self._statements[iId]
        return None
    
    def getScopeRangeInfos(self):
        return self.module.getScopeRangeInfos()
    
    def getCreateStatements(self):
        statements = []
        for statement in self._statements:
            if statement.statement.kind != "theorem":
                continue
            if statement.statement.is_private():
                continue
            statements.append(statement)
        return statements
    
    def hasPrivateInstances(self):
        for statement in self._statements:
            if statement.statement.kind == "instance" and statement.statement.is_private():
                return True
        return False
    
    def getStatementSymbol(self, statement):
        return self.module.getStatementSymbol(statement.statement)
    
    def getContextEntries(self):
        return self.module.getContextEntries()
    
    def getLeanFile(self):
        return self.module.getLeanFile()
    
    def getImports(self):
        return self.module.getImports()
    
    def getDependentStatements(self, statement, file):
        include_ids = set()
        include_ids.add(statement.id)
        if file: print(f"       add dependent_statements {statement.id}", file=file)
        required_ids = set()
        required_symbol_names = set()
        parent_persistant_symbol_names = set()
        self._get_dependent_statements(statement, include_ids, required_ids, required_symbol_names, parent_persistant_symbol_names, file)
        private_required_ids = set()
        self._add_private_statements(statement, include_ids, private_required_ids, file)
        for id in include_ids.copy():
            if not id in private_required_ids:
                stmt = self.getStatement(id)
                self._add_private_statements(stmt, include_ids, private_required_ids, file)
        return include_ids

    def _get_dependent_statements(self, statement, include_ids, required_ids, required_symbol_names, parent_persistant_symbol_names, file):        
        request_start = statement.statement.fileRange.start
        request_id = statement.id
        if request_id in required_ids:
            return
        required_ids.add(request_id)
        if file: print(f"    processing statement: {statement.name}, {statement.get_full_name()} kind: {statement.kind}, id: {request_id}, dependent_statements: {statement.dependent_statements}, persistant_symbol_names: {statement.persistant_symbol_names}", file=file)
        current_persistant_symbol_names = parent_persistant_symbol_names
        for name in statement.persistant_symbol_names:
            if not name in current_persistant_symbol_names:
                current_persistant_symbol_names.add(name)
        
        if len(parent_persistant_symbol_names) > 0:
            for stmt_id in statement.dependent_statements:
                stmt = self.getStatement(stmt_id)
                if stmt.statement.fileRange.start < request_start:
                    self._get_dependent_statements(stmt, include_ids, required_ids, required_symbol_names, current_persistant_symbol_names, file)
                if stmt_id in include_ids and not stmt.statement.is_private() and not request_id in include_ids:
                    include_ids.add(request_id)
                    if file: print(f"       add dependent_statement: {statement.name}, stmt_id: {stmt_id} in include_ids, request_id: {request_id}", file=file)

        for name in statement.persistant_symbol_names:
            statements = self.persistant_symbol_name_dict[name]
            if len(statements) > 0:
                if not request_id in include_ids:
                    if file: print(f"        add persistant_symbol_names by statement: {statement.name}, name: {name}, stmt_id: {request_id}", file=file)
                    include_ids.add(request_id)
                    if request_id in required_ids:
                        required_ids.remove(request_id)
            if name in required_symbol_names:
                continue
            required_symbol_names.add(name)
            for stmt_id in statements:
                if not stmt_id in include_ids:
                    stmt = self.getStatement(stmt_id)
                    if stmt.statement.fileRange.start < request_start:
                        if file: print(f"        add persistant_symbol_names: {name}, stmt_id: {stmt_id}", file=file)
                        include_ids.add(stmt_id)
                        self._get_dependent_statements(stmt, include_ids, required_ids, required_symbol_names, current_persistant_symbol_names, file)
        if file: print(f"      finish processing statement: {statement.name}, request_id: {request_id}", file=file)

    def _add_private_statements(self, statement, include_ids, required_ids, file):
        request_id = statement.id
        for stmt_id in statement.dependent_statements:
            if request_id == stmt_id or stmt_id in required_ids:
                continue
            required_ids.add(stmt_id)
            stmt = self.getStatement(stmt_id)
            if stmt.statement.is_private() and not stmt_id in include_ids:
                include_ids.add(stmt_id)
                if file: print(f"    add private statement: {statement.name}, stmt_id: {stmt_id} from statement: {request_id}", file=file)
            self._add_private_statements(stmt, include_ids, required_ids,file)
        

    def _get_all_reference_ids(self, statement):
        all_ref_ids = set()
        for id in statement.reference_statements:
            if id == statement.id:
                continue
            if not id in all_ref_ids:
                all_ref_ids.add(id)
            stmt = self.getStatement(id)
            ref_ids = self._get_all_reference_ids(stmt)
            for ref_id in ref_ids:
                if not ref_id in all_ref_ids:
                    all_ref_ids.add(ref_id)
        return all_ref_ids
    
    def _add_instance_statement_range_to_dict(self, statement, dict: dict, names: list):
        if names is None or len(names) == 0:
            return
        full_name = statement.get_full_name()
        
        if full_name is None:
            return
        ns_parts = full_name.split(".")
        nm = ns_parts[-1]
        #instAdd_1
        if nm.startswith("inst") and nm.endswith("_1"):
            nm = nm[4:-2].lower()
        if nm.endswith("'"):
            nm = nm[:-1]
        if nm in names:
            ns = ".".join(ns_parts[:-1]) if len(ns_parts) > 1 else ""
            if not ns in dict.keys():
                range_dict = {}
                dict[ns] = range_dict
            else:
                range_dict = dict[ns]
            if not nm in range_dict.keys():
                range_dict[nm] = statement

    def _get_scope_instance_name_dict(self):
        scope_instance_name_dict = {}
        for entry in self.module.contextEntries:
            if entry.kind == "attribute" and entry.namespace:
                parts = entry.content.split("\n")
                if len(parts) < 2:
                    continue
                nz_firstline = parts[0].replace("\t", " ").replace("\r", " ").replace("[", " [ ").replace("]", " ] ").strip()
                nz_firstline = " ".join(nz_firstline.split(" "))
                if nz_firstline != "attribute  [ scoped instance ]":
                    continue
                for part in parts[1:]:
                    part = part.strip()
                    if len(part) > 0:
                        scope_instance_name_dict[part] = entry.namespace
        return scope_instance_name_dict

    def _get_statement_name_dict(self, persistent_with_def):
        statement_full_name_dict = {}
        persistant_def_name_dict = {}
        
        inst_dict = {}
        private_names = set()
        for statement in self.module.statements:
            full_name = statement.get_full_name()
            if full_name:
                if full_name in statement_full_name_dict.keys():
                    dependentStatement = statement_full_name_dict[full_name]
                else:
                    dependentStatement = DependentStatement.create(statement, [], True)
                    statement_full_name_dict[full_name] = dependentStatement
                dependentStatement.dependentStatements.append(statement.id)                
            if  statement.kind == "definition":
                if  persistent_with_def and (statement.is_private() or statement.is_protected()):
                    persistant_def_name_dict[full_name] = dependentStatement
                    if not full_name in private_names:
                        private_names.add(full_name)
                    name = statement.name
                    persistant_def_name_dict[name] = dependentStatement
                    if not name in private_names:
                        private_names.add(name)
            elif statement.kind == "irreducible_def":
                dependentStatement = DependentStatement.create(statement, [], True)
                persistant_def_name_dict[full_name] = dependentStatement
                if not full_name in private_names:
                    private_names.add(full_name)
                name = statement.name
                persistant_def_name_dict[name] = dependentStatement
                if not name in private_names:
                    #private_names.add(name)
                    private_names.add(full_name)
                #if name in statement_full_name_dict.keys():
                #    dependentStatement = statement_full_name_dict[name]
                if full_name in statement_full_name_dict.keys():
                    dependentStatement = statement_full_name_dict[full_name]
                else:
                    dependentStatement = DependentStatement.create(statement, [], True)
                    statement_full_name_dict[name] = dependentStatement
                dependentStatement.dependentStatements.append(statement.id)

            if statement.kind == "instance":
                self._add_instance_statement_range_to_dict(statement, inst_dict, ["add", "neg", "sub", "mul"])
        for ns in inst_dict.keys():
            stmt_dict = inst_dict[ns]
            if "add" in stmt_dict.keys() and "neg" in stmt_dict.keys() and "sub" in stmt_dict.keys():
                stmt = stmt_dict["sub"]
                dependentStatement = DependentStatement.create(stmt, [stmt.id], False)
                persistant_def_name_dict["sub_eq_add_neg"] = dependentStatement
            if "mul" in stmt_dict.keys():
                stmt = stmt_dict["mul"]
                dependentStatement = DependentStatement.create(stmt, [stmt.id], False)
                persistant_def_name_dict["ofFinsupp_mul"] = dependentStatement

        self._dependent_statements_for_persistant_symbol(private_names, persistant_def_name_dict)
        return statement_full_name_dict, persistant_def_name_dict

    def _dependent_statements_for_persistant_symbol(self, private_names, persistant_def_name_dict):
        for stmt in self.module.statements:
            statement_symbol = self.module.getStatementSymbol(stmt)
            symbol_names = set()
            if statement_symbol:
                if statement_symbol.signature_symbols:
                    for symbol in statement_symbol.signature_symbols:
                        if symbol.name in private_names and not symbol.name in symbol_names:
                            symbol_names.add(symbol.name)
                if statement_symbol.value_symbols:
                    for symbol in statement_symbol.value_symbols:
                        for persistant_symbol_name in private_names:
                            if symbol.name == persistant_symbol_name or symbol.name.endswith("." + persistant_symbol_name): 
                                if not persistant_symbol_name in symbol_names:
                                    symbol_names.add(persistant_symbol_name)
            for name in symbol_names:
                dependentStatements = persistant_def_name_dict[name].dependentStatements
                if not stmt.id in dependentStatements:
                    dependentStatements.append(stmt.id)

    def _get_dependent_statements_from_symbols(self, statement_full_name_dict, scope_instance_name_dict, statement_symbol, statementInstanceSymbol, bprint = False):
        statements = set()
        if statement_symbol:
            if statement_symbol.signature_symbols:
                if bprint: print(f"statement_symbol.signature_symbols {len(statement_symbol.signature_symbols)}")
                for symbol in statement_symbol.signature_symbols:
                    stmts = self._get_match_statements(statement_full_name_dict, symbol)
                    for stmt in stmts:
                        if not stmt in statements:
                            statements.add(stmt)
            else:
                if bprint: print("statement_symbol.signature_symbols is None")
            if statement_symbol.value_symbols:
                if bprint: print(f"statement_symbol.value_symbols {len(statement_symbol.value_symbols)}")
                for symbol in statement_symbol.value_symbols:
                    stmts = self._get_match_statements(statement_full_name_dict, symbol)
                    for stmt in stmts:
                        if not stmt in statements:
                            statements.add(stmt)
            else:
                if bprint: print("statement_symbol.value_symbols is None")
        else:
            if bprint: print("statement_symbol is None")
        scope_namespaces = set()
        if statementInstanceSymbol:
            if bprint: print(f"statementInstanceSymbol.instances {len(statementInstanceSymbol.instances)}")
            for instanceName in statementInstanceSymbol.instances:
                if bprint: print(f"instanceName {instanceName}")
                stmts = self._get_match_instances(statement_full_name_dict, instanceName, bprint)
                for stmt in stmts:
                    if not stmt in statements:
                        statements.add(stmt)
                if instanceName in scope_instance_name_dict.keys():
                    namespace = scope_instance_name_dict[instanceName]
                    if not namespace in scope_namespaces:
                        scope_namespaces.add(namespace)
        else:
            if bprint: print("statementInstanceSymbol is None")
        return statements, scope_namespaces
    
    def is_match_statement(self, symbol, internal_name, name, full_name, fileRange):
        #bprint = symbol.src_name == "of_smul_def"
        if symbol.range.start < fileRange.start:
            #if bprint: print(f"False range, name: {name}, full_name: {full_name}, internal_name: {internal_name}, fileRange: {fileRange}, symbol: {symbol}")
            return False
        if internal_name == symbol.name:
            #if bprint: print(f"TRUE internal_name, name: {name}, full_name: {full_name}, internal_name: {internal_name}, fileRange: {fileRange}, symbol: {symbol}")
            return True
        if name == symbol.src_name:
            #if bprint: print(f"TRUE name, name: {name}, full_name: {full_name}, internal_name: {internal_name}, fileRange: {fileRange}, symbol: {symbol}")
            return True
        elif full_name == symbol.src_name:
            #if bprint: print(f"TRUE full_name, name: {name}, full_name: {full_name}, internal_name: {internal_name}, fileRange: {fileRange}, symbol: {symbol}")
            return True
    
    def _get_match_statements(self, statement_full_name_dict, symbol, bprint = False):
        if symbol.src_name is None:
            return 
        match_full_name = None
        if bprint: print(f"symbol: {symbol.name} {symbol.src_name}")
        for stmt_full_name in statement_full_name_dict.keys():
            if bprint: print(f"   stmt_full_name: {stmt_full_name}")
            dependentStatement = statement_full_name_dict[stmt_full_name]
            if self.is_match_statement(symbol, dependentStatement.internal_name, 
                        dependentStatement.name, stmt_full_name, dependentStatement.fileRange):
                match_full_name = stmt_full_name
                break
        if match_full_name:
            return statement_full_name_dict[match_full_name].dependentStatements
        return set()
    
    def _get_match_instances(self, statement_full_name_dict, instanceName, bprint = False):
        if bprint: print(f"instanceName: {instanceName}")
        for full_name in statement_full_name_dict.keys():
            dependentStatement = statement_full_name_dict[full_name]
            if dependentStatement.kind != "instance":
                continue
            #if bprint: print(f"   full_name: {full_name}")
            if full_name.startswith(instanceName):
                if bprint: print(f"             found: {dependentStatement.dependentStatements}")
                return dependentStatement.dependentStatements
            
        
        if instanceName.startswith("instH"):
            instanceName = instanceName[5:].lower()
        elif instanceName.startswith("inst"):
            instanceName = instanceName[4:].lower()
        for full_name in statement_full_name_dict.keys():
            dependentStatement = statement_full_name_dict[full_name]
            if dependentStatement.kind != "instance":
                continue
            name = full_name.split(".")[-1]
            #if bprint: print(f"   name: {name}, instanceName: {instanceName}")
            
            if instanceName in name.lower():
                if bprint: print(f"          name: {name}   found: {dependentStatement.dependentStatements}")
                return dependentStatement.dependentStatements
        if bprint: print(f"   name: {name}, dependentStatement is empty")
        return set()
            
    def _get_persistant_symbol_name_dict(self, persistant_name_dict, statementSymbol, statementInstanceSymbol, bprint = False):
        share_symbol_name_dict = {}
        if bprint: print(f"persistant_name_dict.keys: {persistant_name_dict.keys()}")
        if statementSymbol:
            if bprint: print(f"statementSymbol.signature_symbols: {len(statementSymbol.signature_symbols)}")
            if bprint: print(f"statementSymbol.value_symbols: {len(statementSymbol.value_symbols)}")
            for persistant_name_key in persistant_name_dict.keys():
                persistant_name = persistant_name_dict[persistant_name_key]
                if statementSymbol.signature_symbols:
                    for symbol in statementSymbol.signature_symbols:
                        if bprint: print(f"symbol.is_private: {symbol.is_private}, persistant_name.privateSymbol: {persistant_name.privateSymbol}")
                        if bprint: print(f"    symbol.name: {symbol.name}, persistant_name.persistant_name_key: {persistant_name_key}")
                        if symbol.is_private == persistant_name.privateSymbol:
                            if symbol.name == persistant_name_key or symbol.name.endswith("." + persistant_name_key):
                                share_symbol_name_dict[symbol.name] = persistant_name.dependentStatements

                if statementSymbol.value_symbols:
                    for symbol in statementSymbol.value_symbols:
                        if bprint: print(f"symbol.is_private: {symbol.is_private}, persistant_name.privateSymbol: {persistant_name.privateSymbol}")
                        if symbol.is_private == persistant_name.privateSymbol:
                            if symbol.name == persistant_name_key or symbol.name.endswith("." + persistant_name_key):
                                share_symbol_name_dict[symbol.name] = persistant_name.dependentStatements
        else:
            if bprint: print(f"statementSymbol is None")
        if statementInstanceSymbol:
            for instanceName in statementInstanceSymbol.instances:
                if statementInstanceSymbol.instances:
                    for instance in statementInstanceSymbol.instances:
                        if (instance == instanceName or instance.endswith("." +  instanceName)) and instanceName in persistant_name_dict.keys():
                            share_symbol_name_dict[instance] = persistant_name_dict[instanceName].dependentStatements
        return share_symbol_name_dict

    def _get_content_entry_name(self, kind, entry_content):
        entry_content = entry_content.replace("\n", " ").replace("\t", " ").replace("\r", " ").replace("()", " ").replace("[", " ")
        parts = entry_content.split(" " + kind + " ")
        if len(parts) < 2:
            return None
        if not (" private "  in " " + parts[0] + " "):
            return None
        parts = parts[1].split(" ")
        if len(parts) < 2:
            return None
        return parts[0].strip()
