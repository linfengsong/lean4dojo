import os
import glob
from datetime import datetime

class Record:
    module: str
    statement: str
    status: str
    error: str = None
    range: str = None
    source: str = None

    def __init__(self, module, statement, status, error, range = None):
        self.module = module
        self.statement = statement
        self.status = status
        self.error = error
    
    def key(self):
        return self.module + " " + self.statement


def get_process_file(log_dir: str):
    log_dir = ".logs"
    print(log_dir)
    files = glob.glob(log_dir + "/execute_lean_*.log")
    latest_file = max(files, key=os.path.getmtime)
    return os.path.basename(latest_file)

def get_log_file():
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_name = f"theorem_extract_{timestamp}.log"
    log_dir = os.path.join(root_dir, ".")
    os.makedirs(log_dir, exist_ok=True)
    return os.path.join(log_dir, file_name)

def extract_status(line):
    if line.startswith("Process failure on "):
        module = line.strip()[len("Process failure on "): -1]
        return module, None, "exception"
    elif not line.startswith("module"):
        return None, None, None
    parts = line.split(" ")
    if len(parts) < 5:
        return None, None, None
    if parts[0] != "module:" or not parts[1].endswith(",") or parts[2] != "theorem:" or not parts[4] in ["pass", "fails"]:
        return None, None, None
    return (parts[1])[:-1], parts[3], parts[4]

def processFile(log_fp, root_dir, process_file):

    print(f"process_file: {process_file}")

    records = {}
    line_state = None
    with open(process_file, 'r', encoding='utf-8') as file:
        message = []
        debug = []
        source = []
        error_message_dict = {}
        for line in file:
            if line_state == "exception":
                if line.startswith("module: "):
                    msg = None
                    for m in message:
                        m = m.strip()
                        if len(m) > 0:
                            msg = m
                    msg = "EXCEPTION: " + msg
                    if msg in error_message_dict.keys():
                        count = error_message_dict[msg]
                        error_message_dict[msg] = count + 1
                    else:
                        error_message_dict[msg] = 1
                    record = Record(module_name, theorem_name, status, msg)
                    records[record.key()] = record
                    line_state = None   
                else:
                    message.append(line) 
                    continue   
            if line_state is None:
                message = []
                debug = []
                source = []
                module_name, theorem_name, status = extract_status(line)
                message.append(line)
                if status == "exception":
                    line_state = "exception"
                elif status == "fails":
                    line_state = "message"
                    #print(f"module_name: {module_name} theorem_name: {theorem_name}, ")
                elif status != "pass":
                    pass
                module_name, theorem_name, status = extract_status(line)
                index = line.find("error:")
                if index >= 0:
                    label = "error"
                    msg_range = line[:index -1].strip()
                    msg = line[index + len("error:") + 1:].strip()
                else:
                    index = line.find("warning:")
                    label = "warning"
                    msg_range = line[:index -1].strip()
                    msg = line[index + len("warning:") + 1:].strip()

                if module_name:
                    if theorem_name is None:
                        return ""
                    record = Record(module_name, theorem_name, status, msg, msg_range)
                    records[record.key()] = record
                if status == "fails":
                    line_state = "message"
                    #print(f"module_name: {module_name} theorem_name: {theorem_name}, ")
                elif status != "pass":
                    print(line.rstrip())#, file=log_fp)
                    continue

            if line_state == "message":
                if line == "---------------------- DEBUG -----------------------\n":
                    line_state = "debug"
                else:
                    message.append(line)
            elif line_state == "debug":
                if line == "---------------------- Source Code ------------------\n":
                    line_state = "source"
                else:
                    debug.append(line)
            elif line_state == "source":
                if line == "=====================================================\n":
                    record.source = source
                    line_state = None
                    message_line = message[0]
                    lean_file = theorem_name + ".lean" 
                    index = message_line.find(lean_file)
                    message_line = message_line[index + len(lean_file): ].strip()
                    index = message_line.find("error:")
                    if index >= 0:
                        label = "error"
                        message_range = message_line[:index -1].strip()
                        message = message_line[index + len("error:") + 1:].strip()
                    else:
                        index = message_line.find("warning:")
                        label = "warning"
                        message_range = message_line[:index -1].strip()
                        message = message_line[index + len("warning:") + 1:].strip()
                    print(f"{module_name:<70} {theorem_name:<70} {message_range:<10} {label:<10}    {message}")
                    if message in error_message_dict.keys():
                        count = error_message_dict[message]
                        error_message_dict[message] = count + 1
                    else:
                        error_message_dict[message] = 1
                else:
                    source.append(line)
        #for key in error_message_dict.keys():
        #    print(f"{key:<200}, {error_message_dict[key]}")
    return records

def write_lines(file_path, lines):
    with open(file_path, "w", encoding="utf-8") as f:
        for line in lines:
            f.write(line + "\n")

def main(root_dir: str, file_name: str, file_name2: str = None):
    log_dir = root_dir + "/.logs/"
    log_diff_dir = root_dir + "/.logs_diff/"
    process_file = log_dir + "/" + file_name
    file_name2 = file_name2 if file_name2 else get_process_file(log_dir)
    process_file2 = log_dir + "/" + file_name2

    label = file_name.split("_")[2]
    label2 = file_name2.split("_")[2]

    log_file = get_log_file()
    log_file2 = get_log_file()

    with open(log_file, "w", encoding="utf-8") as log_fp:
        records = processFile(log_fp, root_dir, process_file)
    with open(log_file2, "w", encoding="utf-8") as log_fp:
        records2 = processFile(log_fp, root_dir, process_file2)

    same_keys = []
    diff_keys = []
    for key in records.keys():
        if key in records2.keys():
            if records[key].status == records2[key].status:
                same_keys.append(key)
            else:
                diff_keys.append(key)

    os.makedirs(log_diff_dir, exist_ok=True)

    print(f"same_keys: {len(same_keys)}, diff_keys: {len(diff_keys)}")
    print("module".ljust(50) + "statement".ljust(60) + label.ljust(12) + label2.ljust(12) + "error")
    for key in diff_keys:
        record = records[key]
        record2 = records2[key]
        error = record.error if record.status != "pass" else record2.error
        module_dir = log_diff_dir + "/" + record.module
        source_file_dir = module_dir + "/" + label
        source_file_dir2 = module_dir + "/" + label2
        os.makedirs(source_file_dir, exist_ok=True)
        os.makedirs(source_file_dir2, exist_ok=True)
        if record.statement and len(record.statement) > 0:
            source_file_path = source_file_dir + "/" + record.statement
            source_file_path2 = source_file_dir2 + "/" + record.statement
            if record.source:
                write_lines(source_file_path, record.source)
            if record2.source:
                write_lines(source_file_path2, record2.source)

        print(f"{record.module.ljust(50)}{record.statement.ljust(60)}{record.status.ljust(12)}{record2.status.ljust(12)}{error}")
  
if __name__ == "__main__":
    root_dir = "/home/linfe/math/lean_test"
    name_file = "execute_lean_20260430_134607_test.log"
    name_file2 = "execute_lean_20260501_012143_test.log"
    main(root_dir, name_file, name_file2)

    # python -m leanstmt.test.log_compare

