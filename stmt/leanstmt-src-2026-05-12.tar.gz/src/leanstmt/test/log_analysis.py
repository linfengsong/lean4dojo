import os
import glob
from datetime import datetime

def get_process_file(search_dir: str):
    log_dir = ".logs"
    print(search_dir + "/" + log_dir)
    files = glob.glob(search_dir + "/" + log_dir + "/execute_lean_*.log")
    latest_file = max(files, key=os.path.getmtime)
    return latest_file

def extract_status(line):
    if line.startswith("Process failure on "):
        module = line.strip()[len("Process failure on "): -1]
        return module, None, "exception"
    elif not line.startswith("module"):
        return None, None, None
    parts = line.split(" ")
    if len(parts) < 5:
        return None, None, None
    if parts[0] != "module:" or not parts[1].endswith(",") or parts[2] != "theorem:" or not parts[4] in ["pass", "fails"]:
        return None, None, None
    return (parts[1])[:-1], parts[3], parts[4]

def processFile(log_fp, root_dir, process_file):

    print(f"process_file: {process_file}")

    line_state = None
    with open(process_file, 'r', encoding='utf-8') as file:
        message = []
        debug = []
        source = []
        error_message_dict = {}
        for line in file:
            if line_state == "exception":
                if line.startswith("module: "):
                    msg = None
                    for m in message:
                        m = m.strip()
                        if len(m) > 0:
                            msg = m
                    msg = "EXCEPTION: " + msg
                    if msg in error_message_dict.keys():
                        count = error_message_dict[msg]
                        error_message_dict[msg] = count + 1
                    else:
                        error_message_dict[msg] = 1
                    line_state = None   
                else:
                    message.append(line) 
                    continue               
            if line_state is None:
                message = []
                debug = []
                source = []
                module_name, theorem_name, status = extract_status(line)
                message.append(line)
                if status == "exception":
                    line_state = "exception"
                elif status == "fails":
                    line_state = "message"
                    #print(f"module_name: {module_name} theorem_name: {theorem_name}, ")
                elif status != "pass":
                    print(line.rstrip())#, file=log_fp)
                    continue
            elif line_state == "message":
                if line == "---------------------- DEBUG -----------------------\n":
                    line_state = "debug"
                else:
                    message.append(line)
            elif line_state == "debug":
                if line == "---------------------- Source Code ------------------\n":
                    line_state = "source"
                else:
                    debug.append(line)
            elif line_state == "source":
                if line == "=====================================================\n":
                    line_state = None
                    message_line = message[0]
                    lean_file = theorem_name + ".lean" 
                    index = message_line.find(lean_file)
                    message_line = message_line[index + len(lean_file): ].strip()
                    index = message_line.find("error:")
                    if index >= 0:
                        label = "error"
                        message_range = message_line[:index -1].strip()
                        message = message_line[index + len("error:") + 1:].strip()
                        message = "ERROR: " + message
                    else:
                        index = message_line.find("warning:")
                        label = "warning"
                        message_range = message_line[:index -1].strip()
                        message = message_line[index + len("warning:") + 1:].strip()
                        if len(message.strip()) == 0:
                            print("warning empty: " + message_line)
                        message = "WARNING: " + message
                    print(f"{module_name:<70} {theorem_name:<70} {message_range:<10} {label:<10}    {message}")
                    if message in error_message_dict.keys():
                        count = error_message_dict[message]
                        error_message_dict[message] = count + 1
                    else:
                        error_message_dict[message] = 1
                else:
                    source.append(line)
        category = [0,0,0]
        for key in error_message_dict.keys():
            print(f"{error_message_dict[key]: <5}{key:<200}")
            if key.startswith("ERROR:"):
                category[0] = category[0] + error_message_dict[key] 
            elif key.startswith("WARNING:"):
                category[1] = category[1] + error_message_dict[key] 
            elif key.startswith("EXCEPTION:"):
                category[2] = category[2] + error_message_dict[key]
        print(f"Error: {category[0]}")
        print(f"Warning: {category[1]}")
        print(f"Expection: {category[2]}")

def main(root_dir: str, input_log_file: str):

    process_file = input_log_file if input_log_file else get_process_file(root_dir)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_name = f"theorem_extract_{timestamp}.log"
    log_dir = os.path.join(root_dir, ".")
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, file_name)

    with open(log_file, "w", encoding="utf-8") as log_fp:
        processFile(log_fp, root_dir, process_file)

 
if __name__ == "__main__":
    root_dir = "/home/linfe/math/lean_test"
    input_log_file = root_dir + "/.logs/" + "execute_lean_20260502_134404.log" #execute_lean_20260430_134607_test.log"#"/.logs/execute_lean_20260428_230809_test..log" #"/.logs/execute_lean_20260428_101146_test.log"
    main(root_dir, input_log_file)

    # python -m leanstmt.test.log_analysis

