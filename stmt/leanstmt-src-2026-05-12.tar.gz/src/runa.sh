python -m leanstmt.core.jixia_extract "/home/linfe/math/lean_test" --search_list Mathlib.MeasureTheory,Mathlib.Data,Mathlib.Algebra
python -m leanstmt.generator.test
