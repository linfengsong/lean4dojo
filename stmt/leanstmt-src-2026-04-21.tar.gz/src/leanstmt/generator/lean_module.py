import sys
import re
from typing import Optional
from dataclasses import dataclass
from dataclasses_json import dataclass_json
from ..core.core_project import CoreModule
from ..core.core_datasets import CoreDeclaration, CoreInfoTree
from .lean_statement import Attribute, ScopeInfo, Modifiers, StatementExtra, Statement, Abbrev, Axiom, ClassInductive, Declaration, Example, Inductive, Instance, Opaque, Structure, Variable, ProofWanted, Theorem
from .lean_file import LeanFile, LeanFileRange, LeanFilePos
from .lean_elab import collect_all_terms, collect_all_tacticProofs

Symbol_Unsafe_src_names =  [
    "rfl",
    "interior",
    "Inter",
    "iInter",
    "sInter",
    "closure",
    "nhds",
    "ofNat",
    "intro"
]

Symbol_Unsafe_names = {
    "Array.anyM.loop"
}

@dataclass_json
@dataclass(frozen=True)
class LeanScopeRangeInfo:
    kind : str
    name : str
    content: str
    range : LeanFileRange
    index: int

    def __str__(self):
        return self.to_json()

@dataclass_json
@dataclass(frozen=True)
class LeanContextEntryInfo:
    kind : str
    raw_kind: str
    namespace: str
    content : str
    range : LeanFileRange

    def __str__(self):
        return self.to_json()
    
    def getArguments(self):
        kind = self.raw_kind if self.raw_kind else self.kind
        content = self.content.replace("\n", " ").replace("\t", " ").replace("\r", " ")
        index = content.find(kind + " ")
        if index < 0:
            return None
        content = self.content[index + len(kind) + 1:].strip()
        if not content.startswith("["):
            return None
        index = content.find("]")
        if index < 0:
            return None
        content = content[1:index].strip()
        if len(content) == 0:
            return None
        return content.split(" ")

@dataclass_json
@dataclass(frozen=True)
class LeanSymbolReference:  
    name: str
    src_name: str
    range: LeanFileRange
    is_private: bool = False
    prefix_safe: bool = True
    prefix_reason: str = None

    def __str__(self):
        return self.to_json()

@dataclass_json
@dataclass(frozen=True)
class LeanStatementSymbol:
    kind: str
    name: str
    signature_symbols: list[LeanSymbolReference]
    value_symbols: Optional[list[LeanSymbolReference]] = None

    def __str__(self):
        return self.to_json()

@dataclass_json
@dataclass(frozen=True)
class LeanModule:
    name: str
    coreModule: CoreModule

    firsttime: bool = True

    statements: list[Statement] = None

    def __post_init__(self):
        statements = self._getStatements()
        object.__setattr__(self, 'statements', statements)

    def getStatements(self):
        return self.statements
    

    def getImports(self):
        return self.coreModule.moduleInfo.imports
    
    def _appendSymbolReference(self, leanFile, reference, symbols_dict):
        if reference.name is None:
            return
        name = ".".join([str(item) for item in reference.name])
        is_private = False
        if name.startswith("_private.0."):
            name = name[len("_private.0."):]
            is_private = True
        bprint = False #"getElem?_eq_some_iff" == name
        fileRange = LeanFileRange(LeanFilePos.createFilePos(leanFile.lines, reference.range[0]),
                         LeanFilePos.createFilePos(leanFile.lines, reference.range[1])) if reference.range else None
        src_name_raw = leanFile.getTextFromLineModule(fileRange) if fileRange else None
        src_name = leanFile.remove_comment(src_name_raw)
        # adjust correct range for name. InforTree does not setup right some cases
        if bprint: print(f"src_name_raw: |{src_name_raw}|, src_name: |{src_name}|, name |{name}|, fileRange: {fileRange}")
        adj_src_name = None
        if fileRange and fileRange.start.line == fileRange.stop.line:
            for item in reversed(reference.name):
                check_src_name = str(item) + "." + adj_src_name if adj_src_name else str(item)
                if check_src_name in src_name:
                    adj_src_name = check_src_name
                else:
                    break
            if adj_src_name:
                if src_name != adj_src_name:
                    index = src_name.index(adj_src_name)
                    if bprint: print(f"adj_src_name: |{adj_src_name}|, src_name |{src_name}|")
                    if bprint: print(f"          index: {index}, fileRange {fileRange}")
                    src_name = adj_src_name
                    fileRange = LeanFileRange(LeanFilePos(fileRange.start.line, fileRange.start.column + index),
                                LeanFilePos(fileRange.start.line, fileRange.start.column + index + len(adj_src_name) - 1))
                    if bprint: print(f"      src_name |{src_name}|, adj fileRange {fileRange}")
            else:
                if bprint: print(f"adj_src_name is none, src_name |{src_name}|, , name |{name}|")
        str_fileRange = f"{fileRange}" if fileRange else name
        if not str_fileRange in symbols_dict:
            namespace_prefix_reason = self._validate_namespace_prefix(leanFile, name, src_name, fileRange) #reference.namespace_prefix_reason
            namespace_prefix_safe = namespace_prefix_reason is None #reference.namespace_prefix_safe
            symbols_dict[str_fileRange] = LeanSymbolReference(name, src_name, fileRange, is_private, namespace_prefix_safe, namespace_prefix_reason)

    def getStatementSymbol(self, statement: Statement):
        kind = statement.kind
        internal_name = statement.internal_name
        if internal_name is None:
            return None
        if statement.name is None:
            return None
        if len(internal_name) > 1 and internal_name[0] == "_private":
            index  = 0
            for index, part in enumerate(internal_name):
                if isinstance(part, int):
                    internal_name = internal_name[index:]
                    assert (len(internal_name) > 0), f"Fail parse private statement name: {internal_name}"
                    internal_name.insert(0, "_private")
                    break
        statement_index = -1
        if kind == "instance":
            index = internal_name[-1].rfind("_")
            if index > 0:
                left_part = internal_name[-1][:index]
                right_part = internal_name[-1][index+1:]
                if len(right_part) > 0 and right_part.isdigit():
                    internal_name[-1] = left_part
                    statement_index = int(right_part) - 1
        name = ".".join([str(part) for part in internal_name])

        symbols = []
        for smbl in self.coreModule.symbols:
            if smbl.kind != kind:
                continue
            symbol_name = ".".join([str(item) for item in smbl.name ])
            if symbol_name == name:
                symbols.append(smbl)
        if len(symbols) == 0:
            return None
        
        leanFile = self.getLeanFile()

        if statement_index == -1:
            symbol = symbols[0]
        else:
            assert statement_index < len(symbols); f"statement_index: {statement_index} out of symbols range: {len(symbols)} on statement: {statement.internal_name}"
            symbol = symbols[statement_index]
        symbols_signature_dict = {}
        for reference in symbol.type_references:
            self._appendSymbolReference(leanFile, reference, symbols_signature_dict)
        signatureRefs = symbols_signature_dict.values()  

        valueRefs = None
        if hasattr(statement, "value"):
            symbols_value_dict = {}
            for reference in symbol.value_references:
                self._appendSymbolReference(leanFile, reference, symbols_value_dict)
            valueRefs = symbols_value_dict.values()
        
        return LeanStatementSymbol(kind, name, signatureRefs, valueRefs)
    
    def getScopeRangeInfos(self):
        def get_scope_name(kind, scope_range_name):
            if scope_range_name is None:
                return None
            if not scope_range_name.startswith(kind + " "):
                return None
            scope_range_name = " ".join(scope_range_name.split()) if scope_range_name else None
            parts = scope_range_name.split(" ")
            if len(parts) > 1:
                return parts[1]
            else:
                return None

        #print(f"xxxxx module name: {self.name}")
        #kind_set = set()
        #for scope_range in self.coreModule.moduleInfo.scope_range_infos:
        #    if not scope_range.kind in kind_set:
        #        kind_set.add(scope_range.kind)
        #    if scope_range.kind == "in_statement":
        #        print(f"xxxxxxx scope_info: {scope_range}")
        #print(f"xxxxx kind_set: {kind_set}")

        scopeRangeInfos = []
        #for scope_range in self.coreModule.moduleInfo.scope_range_infos:
        #    if scope_range.kind == "end" and scope_range.name:
        #        name = get_scope_name(scope_range.kind, scope_range.name)
        #        if name is not None:
        #            endMap[name] = scope_range.range.stop
        scope_name_dict = {}
        empty_sections = []
        leanFile = self.getLeanFile()
        for scope_range in self.coreModule.moduleInfo.scope_range_infos:
            name = scope_range.name.strip() if scope_range.name and scope_range.name != "anonymous" else None
            if scope_range.kind in ["namespace", "section"]:
                #print(f"xxxxx scope_range: {scope_range}")
                contentRange = LeanFileRange(LeanFilePos.createFilePos(leanFile.lines, scope_range.range.start), 
                                     LeanFilePos.createFilePos(leanFile.lines, scope_range.range.stop))
                range = LeanFileRange(contentRange.start, 
                                     LeanFilePos.createFilePos(leanFile.lines, sys.maxsize))
                content = leanFile.remove_comment(leanFile.getTextFromLineModule(contentRange)).strip()
                if scope_range.kind == "section" and name is None:
                    scopeInfo = LeanScopeRangeInfo(scope_range.kind, None, content, range, 0)
                    scopeRangeInfos.append(scopeInfo)
                    empty_sections.append(scopeInfo)
                    #print(f"xxxxx empty section: {scopeInfo}")
                elif name:
                    name_parts = name.split(".")
                    for i, part in enumerate(name_parts):
                        scopeInfo = LeanScopeRangeInfo(scope_range.kind, part, content, range, i)
                        #print(f"xxxx scopeInfo: {scopeInfo}")
                        scopeRangeInfos.append(scopeInfo)
                        if part in scope_name_dict:
                            array = scope_name_dict[part]
                            array.append(scopeInfo)
                        else:
                            scope_name_dict[part] = [scopeInfo]
            elif scope_range.kind == "end":
                name = get_scope_name(scope_range.kind, scope_range.name)
                if name is None:
                    orgScopeInfo = empty_sections.pop()
                    #print(f"xxxxx empty section pop: {orgScopeInfo}")
                    if orgScopeInfo:
                        endPos = LeanFilePos.createFilePos(leanFile.lines, scope_range.range.stop)
                        object.__setattr__(orgScopeInfo.range, "stop", endPos)
                else:
                    name_parts = name.split(".")
                    for part in name_parts:
                        if not part in scope_name_dict:
                            continue
                        array = scope_name_dict[part]
                        if len(array) > 0:
                            orgScopeInfo = array.pop()
                            if orgScopeInfo:
                                endPos = LeanFilePos.createFilePos(leanFile.lines, scope_range.range.stop)
                                object.__setattr__(orgScopeInfo.range, "stop", endPos)
        #print(f"xxxx scopeRangeInfos: {len(scopeRangeInfos)}")            
        return scopeRangeInfos
    
    def getNamespaceByScopeRanges(self, range):
        scopeRanges = []
        for scopeRange in self.getScopeRangeInfos():
            if scopeRange.kind == "namespace" and scopeRange.range.inRange(range):
                scopeRanges.append(scopeRange)
        if len(scopeRanges) == 0:
            return None
        return ".".join([scopeRange.name for scopeRange in sorted(scopeRanges, key=lambda x: x.range)])

    def getContextEntries(self):
        contextEntries = []
        leanFile = self.getLeanFile()
        inRangeEntry = None
        context_entries = sorted(self.coreModule.localContext.context_entries, key=lambda x: x.range) 
        wantedMacros = [ "assert_not_imported", "assert_not_exists", "mk_iff_of_inductive_prop", "library_note2", "irreducible_def" ]
        # "commandAssert_not_imported_"
        # "commandMk_iff_of_inductive_prop"

        for context_entry in context_entries:
            #if context_entry.kind == "Lean.Parser.Command.attribute" or context_entry.kind == "irreducible_def":
            #    print(f"context_entry.kind : {context_entry.kind}, {context_entry.content}")
            range = LeanFileRange(LeanFilePos.createFilePos(leanFile.lines, context_entry.range.start), 
                                LeanFilePos.createFilePos(leanFile.lines, context_entry.range.stop))
            content = leanFile.remove_comment(context_entry.content)
            kind = None
            raw_kind = None
            macro_kind = context_entry.kind[len("command"):1].lower() if context_entry.kind.startswith("command") else None            
            if context_entry.kind == "Batteries.Tactic.Alias.alias" or context_entry.kind == "Batteries.Tactic.Alias.aliasLR":
                kind = "alias"
            elif context_entry.kind == "irreducible_def":
                kind = "custom_macro"
                raw_kind = "irreducible_def"
            elif context_entry.kind.startswith("Lean.Parser.Command."):
                kind = context_entry.kind[len("Lean.Parser.Command."):]
            elif macro_kind in wantedMacros:
                kind = "custom_macro"
                raw_kind = macro_kind
            if kind:
                namespace = self.getNamespaceByScopeRanges(range)
                entry = LeanContextEntryInfo(kind, raw_kind, namespace, content, range)
                prev_entry = contextEntries.pop() if len(contextEntries) > 0 else None
                if prev_entry:
                    if not entry.range.inRange(prev_entry.range):
                        inRangeEntry = entry
                        contextEntries.append(prev_entry)
                elif inRangeEntry and inRangeEntry.range.inRange(entry.range):
                    entry = None
                    inRangeEntry = None 
                if entry:
                    contextEntries.append(entry)

        return contextEntries
    
    def getDocuments(self):
        return self.coreModule.moduleInfo.docstring
    
    def getLeanFile(self):
        return LeanFile(self.coreModule.lean_file, self.coreModule.lines)
    
    def _getStatements(self):
        leanFile = self.getLeanFile()
        declarations:list[CoreDeclaration] = self.coreModule.decls
        infoTrees: list[CoreInfoTree] = self.coreModule.infoTrees
        tacticProofs = collect_all_tacticProofs(leanFile, infoTrees)
        terms = collect_all_terms(leanFile, infoTrees, self.name)
        statements = []
        fileRanges = []
        next_id = 0
        for _, decl in enumerate(declarations):
            next_id = next_id + 1
            id = next_id
            raw_name = self._getRawName(decl.name)
            internal_name = decl.name
            internal_namespace = ".".join(decl.scope_info.curr_namespace) if decl.scope_info and decl.scope_info.curr_namespace else None
            fileRange = leanFile.createFileRange(decl.ref.range)
            content = leanFile.remove_comment(leanFile.getTextFromLineModule(fileRange))
            signature, signatureRange, value, valueRange = self._createSignatureAndValue(decl, leanFile, fileRange)
            scope_info = self._createScopeInfo(decl)
            modifiers = self._createModifiers(decl, leanFile)
            extra = self._createExtra(decl, leanFile)
            name = self._getName(signatureRange, raw_name)

            statement = None
            if decl.kind == "abbrev":
                statement = Abbrev(decl, content, fileRange, id, name, internal_name, internal_namespace, scope_info, modifiers, extra, signature, signatureRange, value, valueRange)
            elif decl.kind == "axiom":
                statement = Axiom(decl, content, fileRange, id, name, internal_name, internal_namespace, scope_info, modifiers, extra, signature, signatureRange)
            elif decl.kind == "classInductive":
                statement = ClassInductive(decl, content, fileRange, id, name, internal_name, internal_namespace, scope_info, modifiers, extra, signature, signatureRange, value, valueRange)
            elif decl.kind == "definition":
                InExist = False
                for exist_fileRange in fileRanges:
                    if exist_fileRange.inRange(fileRange):
                        InExist = True
                if not "._@." in name and valueRange and not InExist: #remove MACRO declaration
                    statement = Declaration(decl, content, fileRange, id, name, internal_name, internal_namespace, scope_info, modifiers, extra, signature, signatureRange, value, valueRange)
            elif decl.kind == "example":
                statement = Example(decl, content, fileRange, id, name, internal_name, internal_namespace, scope_info, modifiers, extra, signature, signatureRange, value, valueRange)
            elif decl.kind == "inductive":
                statement = Inductive(decl, content, fileRange, id, name, internal_name, internal_namespace, scope_info, modifiers, extra, signature, signatureRange, value, valueRange)
            elif decl.kind == "instance":
                InExist = False
                for exist_fileRange in fileRanges:
                    if exist_fileRange.inRange(fileRange):
                        InExist = True
                #if not (".inst" in name or name.startswith("inst")) and not ("_hyg" in name or InExist):
                statement = Instance(decl, content, fileRange, id, name, internal_name, internal_namespace, scope_info, modifiers, extra, signature, signatureRange, value, valueRange)
            elif decl.kind == "opaque":
                if signatureRange and fileRange != signatureRange: # other case is MACRO and need fix for MACRO
                    statement = Opaque(decl, content, fileRange, id, name, internal_name, internal_namespace, scope_info, modifiers, extra, signature, signatureRange, value, valueRange)
            elif decl.kind == "structure": 
                statement = Structure(decl, content, fileRange, id, name, internal_name, internal_namespace, scope_info, modifiers, extra, signature, signatureRange, value, valueRange)
            elif decl.kind == "theorem":
                if signature and value:
                    statement = Theorem.create(decl, content, fileRange, id, name, internal_name, internal_namespace, scope_info, modifiers, extra, signature, signatureRange, value, valueRange, tacticProofs, terms)
            elif decl.kind == "variable":
                InExist = False
                for exist_fileRange in fileRanges:
                    if exist_fileRange.inRange(fileRange):
                        InExist = True # skip variable defined in the statement
                if not InExist:
                    statement = Variable(decl, content, fileRange, id, name, internal_name, internal_namespace, scope_info, modifiers, extra, signature, signatureRange, )
            elif decl.kind == "proofWanted":
                statement = ProofWanted(decl, content, fileRange, id, name, internal_name, internal_namespace, scope_info, modifiers, extra, signature, signatureRange, value, valueRange)
            else:
                print(f"ERROR decl.kind: {decl.kind} does not support at {self.name}")
                statement = None
            if statement is not None:
                fileRanges.append(statement.fileRange)
                statements.append(statement)
        return statements
    
    def _getRawName(self, name: str):
        #first item is "_private" if it's a private declaration, we need to remove the prefix and get the real name
        # for example, if the declaration name is ['_private', 'Mathlib', 'Data', 'EReal', 'Operations', 0, 'EReal', 'exists_lt_add_right'],
        # and the module name is ["Init", "Nat"], we need to remove the prefix and get the real name "add"  
        if name is None or len(name) == 0:
            return None
        
        if name[0] == '_private':
            p_name = name[1:]
            module_name_array = self.name.split(".")
            if len(p_name) + 1 > len(module_name_array):
                name_prefix_array = p_name[:len(module_name_array)]
                if name_prefix_array == module_name_array:
                    p_name = p_name[len(name_prefix_array):]
            if not isinstance(p_name[0], int):
                print(f"ERROR decl.name: {name} format is invalid for private {p_name}")
                print(f"         p_name: {p_name}, module: {self.name}")
            else:
                name = p_name[1:]
        return ".".join([str(item) for item in name ])
    
    def _getName(self, signatureRange: LeanFileRange, raw_name: str):
        statement_name = raw_name
        if signatureRange:
            pre_signatureRange = LeanFileRange(LeanFilePos(signatureRange.start.line - 1, 1), signatureRange.start)
            pre_signature = self.getLeanFile().getTextFromLineModule(pre_signatureRange)[:-1].strip()
            index = pre_signature.rfind(" ")
            if index >= 0:
                check_name = pre_signature[index:].strip()
            else:
                check_name = pre_signature[:].strip()
            if statement_name.endswith(check_name):
                return check_name
        return statement_name
    
    def _createSignatureAndValue(self, decl: CoreDeclaration, leanFile: LeanFile,fileRange: LeanFileRange):
        signatureRange = leanFile.createFileRange(decl.signature.range) if decl.signature and decl.signature.range else None
        valueRange = leanFile.createFileRange(decl.value.range) if decl.value and decl.value.range else None
        adjustment = False
        signature = leanFile.getTextFromLineModule(signatureRange) if signatureRange else None
        if signatureRange:
            if valueRange is None:
                next_pos = leanFile.nextPos(signatureRange.stop)
                if next_pos < fileRange.stop:
                    valueRange = LeanFileRange(next_pos, fileRange.stop)
                    adjustment = True
            if valueRange and signatureRange == valueRange:
                valueRange = None
        if valueRange and valueRange.stop < fileRange.stop:
            valueRange = LeanFileRange(valueRange.start, fileRange.stop)
        value = leanFile.getTextFromLineModule(valueRange) if valueRange else None
        if valueRange and signatureRange and signatureRange.stop == valueRange.start:
            last_signature_char = signature[-1]
            if last_signature_char == ":" or last_signature_char == "-":
                signature, signatureRange, value, valueRange = \
                    self._move_left_one_position(signature, signatureRange, value, valueRange)
        elif adjustment: # bug in extract to have ":" when no space between ":=" or "--" 
            last_signature_char = signature[-1]
            if last_signature_char == ":" or last_signature_char == "-":
                signature, signatureRange, value, valueRange = \
                self._move_left_one_position(signature, signatureRange, value, valueRange)
        if value and value.strip().startswith("|") and not value.strip(" \t").startswith("\n"):
            if signature[-1] == "\n":
                signature, signatureRange, value, valueRange = \
                    self._move_left_one_position(signature, signatureRange, value, valueRange)
            else:
                valueRange = LeanFileRange(LeanFilePos(signatureRange.stop.line, signatureRange.stop.column+1), valueRange.stop) 
                value = "\n" + value #some issue to lost last line feed
        signature = leanFile.remove_comment(signature) if signature else None
        value = leanFile.remove_comment(value).rstrip() if value else None
        return signature, signatureRange, value, valueRange
    
    def _move_left_one_position(self, signature, signatureRange, value, valueRange):
        last_signature_char = signature[-1]
        signature = signature[:-1]
        value = last_signature_char + value
        valueRange = LeanFileRange(signatureRange.stop, valueRange.stop)
        signatureRange = LeanFileRange(signatureRange.start,
                                       LeanFilePos(signatureRange.stop.line, signatureRange.stop.column-1))          
        return signature, signatureRange, value, valueRange
    
    
    def _createScopeInfo(self, decl: CoreDeclaration):
        namespace = ".".join(decl.scope_info.curr_namespace) if decl.scope_info and decl.scope_info.curr_namespace else None
        omit_vars = decl.scope_info.omit_vars if decl.scope_info and decl.scope_info.omit_vars else None
        open_decl = None
        if decl.scope_info and decl.scope_info.open_decl:
            open_decl = []
            for open_dl in decl.scope_info.open_decl:
                if open_dl.simple:
                    open_ns = ".".join(open_dl.simple.namespace)
                    open_decl.append(open_ns)
        scoped_open_decl = None
        if decl.scope_info and decl.scope_info.scoped_open_decl:
            scoped_open_decl = []
            for open_dl in decl.scope_info.scoped_open_decl:
                open_ns = ".".join(open_dl)
                if open_decl and not open_ns in open_decl and open_ns != namespace:
                    scoped_open_decl.append(open_ns)
        #if decl.kind == "theorem" and self.name.startswith("Init") and len(decl.scope_info.var_decls) > 0:
        #if decl.kind == "theorem" and len(decl.scope_info.var_decls) > 0:
            #print(f"include_vars: {decl.scope_info.var_decls} in declaration {decl.name} in module {self.name}")
            #print(f"declaration {decl.name} in module {self.name} {decl.scope_info}")
        return ScopeInfo(decl.scope_info.var_decls, decl.scope_info.include_vars, omit_vars, namespace, open_decl, scoped_open_decl)
    
    def _createModifiers(self, decl: CoreDeclaration, leanFile: LeanFile):
        attrs = None
        for attr in decl.modifiers.visibility:
            attrs = []
            for attr in decl.modifiers.attrs:
                attrFileRange = leanFile.createFileRange(attr.stx)
                attrName = ".".join(attr.name)
                attrContent = leanFile.remove_comment(leanFile.getTextFromLineModule(attrFileRange)) if attrFileRange else None
                if attrContent and (attrContent.endswith("]") or attrContent.endswith(",")):
                    attrContent = attrContent.strip()[:-1].strip()
                else:
                    attrExFileRange = LeanFileRange(attrFileRange.stop, LeanFilePos(attrFileRange.stop.line, sys.maxsize))
                    attrEx = leanFile.getTextFromLineModule(attrExFileRange)[1:]
                    attrCommaIndex = attrEx.find(",")
                    attrEndIndex = attrEx.find("]")
                    if attrCommaIndex >= 0 and attrCommaIndex < attrEndIndex:
                        attrContent = attrContent + attrEx[:attrCommaIndex].strip()
                    elif attrEndIndex >= 0:
                        attrContent = attrContent + attrEx[:attrEndIndex].strip()
                attrs.append(Attribute(attr.kind, attrName, attrContent, attrFileRange))

        return Modifiers(
                decl.modifiers.visibility if decl.modifiers.visibility != "regular" else None,
                attrs,
                decl.modifiers.compute_kind if decl.modifiers.compute_kind != "regular" else None,
                decl.modifiers.rec_kind if decl.modifiers.rec_kind != "default" else None,
                decl.modifiers.is_unsafe
            )
    
    def _createExtra(self, decl: CoreDeclaration, leanFile: LeanFile):
        if decl.extra is None:
            return None
        if decl.extra.self_call_ranges:
            self_call_ranges = []
            for range in decl.extra.self_call_ranges:
                self_call_ranges.append(leanFile.createFileRange(range))
            return StatementExtra(self_call_ranges)
        return None

    def _validate_namespace_prefix(self, leanFile, name, src_name, range):
        if range is None or src_name is None:
            return None
        
        bprint = False #src_name.strip() == "div_le_iff_le_mul"
        #if not name.strip().endswith("." + src_name.strip()):
            #if bprint: print(f"xxxxx name: |{name}|, src_name: |{src_name}|")
            #return False
        if src_name in Symbol_Unsafe_src_names:
            return "reserve src keyword with namespace"
        
        if src_name in Symbol_Unsafe_names:
            return "reserve keyword with namespace"
        
        
        if not re.match(r'^[a-zA-Z_]', src_name.strip()):
            return "Not ident"
        if name != src_name and not name.endswith("." + src_name):
            return "Not namespace prefix"
        
        line = range.start.line
        if range.start.column > 1:
            prerange = LeanFileRange(LeanFilePos(line, 1), LeanFilePos(line, range.start.column -1))
            pre_str = self.normalize(leanFile.getTextFromLineModule(prerange))
            #if pre_str.endswith("@"):
            #    return "prefix @"
            if pre_str.endswith("."):
                return "prefix ."
            if pre_str.endswith("@"):
                pre_str = pre_str[:-1]
            if pre_str.strip().endswith(" |") or pre_str.strip() == "|":
                return "induction |"    
        postrange = LeanFileRange(LeanFilePos(line, range.stop.column + 1), LeanFilePos(line, sys.maxsize))
        post_str = leanFile.getTextFromLineModule(postrange)
        if post_str.startswith("(") or post_str.startswith("[") or post_str.startswith("["):
            return "macro with () or []"
        return None

    def normalize(self, str):
        str = str.replace("\t", " ").replace("\r", " ").replace("\n", " ")
        return " ".join(str.split())
    
def get_in_statement_prefix(full_source, decl_start_pos, scoped_open_names):
    """
    full_source: 移除註解後的原始碼字串
    decl_start_pos: 定理起始的 byte_offset
    scoped_open_names: Lean getScopeInfo 回傳的 ["Function", "MeasureTheory", ...]
    """
    # 1. 往回抓取一段文字（例如 200 字元，足以包含一個 open scoped 指令）
    lookback_fragment = full_source[max(0, decl_start_pos - 200):decl_start_pos].strip()
    
    # 2. 正則表達式：尋找以 'in' 結尾的指令
    # 模式說明：(指令類型) (內容) in (結尾可選空白)
    # 範例：open scoped Function in
    in_pattern = r"(open\s+scoped\s+([\w\.]+)\s+in)\s*$"
    match = re.search(in_pattern, lookback_fragment)
    
    if match:
        full_in_stmt = match.group(1) # "open scoped Function in"
        ns_name = match.group(2)      # "Function"
        
        # 3. 交叉驗證：檢查這個命名空間是否在 Lean 報出的 scopedOpenDecl 裡
        if ns_name in scoped_open_names:
            return full_in_stmt
            
    return ""

