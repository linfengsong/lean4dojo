import sys
from dataclasses import dataclass
from operator import attrgetter
from leanstmt.generator.lean_module import LeanModule
from .lean_statement import Statement, Variable
from .lean_file import LeanFileRange, LeanFilePos
from .lean_module import LeanSymbolReference

Lean_keywords = [
    "def", "theorem", "lemma", "example",
    "inductive", "structure", "class", "instance",
    "constant", "axiom", "abbrev"
    "variable", "variables",
    "if", "then", "else",
    "match", "nomatch", "with",
    "do", "let", "mut",
    "for", "in", "at",
    "try", "catch", "finally",
    "return", "break", "continue",
    "forall", "exists",
    "fun", "λ"
    "have", "show", "suffices",
    "by",
    "from",
    "import", "prelude", "namespace", "section", "end",
    "open", "export", "hiding", "renaming",
    "private", "protected", "noncomputable", "unsafe", "partial",

    "infix", "infixl", "infixr",
    "postfix", "prefix",
    "notation",
    "macro",
    "syntax",
    "declare_syntax_cat", 
    "intro", "intros",
    "apply", "exact", "refine",
    "cases", "induction"
    "rewrite", "rw",
    "simp", "dsimp", "aesop",
    "refl", "rfl",
    "abbrev",
    "opaque","axiom", "constant",
    "attribute",
    "elab", "elab_rules", 
    "sorry",
    "forall", "exists",
    "true", "false" 
    "cexp",
]

class ExclusiveConfig: 
    def __init__(self, data: dict[str, list[str]]):
        self.config: dict[str, list[str]] = data

    def getConfigList(self, name: str):
        if self.config is None:
            return None
        return self.config[name] if name in self.config.keys() else None

@dataclass(frozen=True)
class ContextText:
    text: str
    comment: str
    pos: LeanFilePos
    blockIndex: int = None

class LeanCreateStatement:
    def __init__(self, exclusiveConfig: ExclusiveConfig, module_name: str, module: LeanModule, statements: list[Statement]):
        self.exclusiveConfig = exclusiveConfig
        self.module_name = module_name
        self.module = module
        self.statements = statements

        private_kinds = ["theorem", "definition", "inductive", "abbrev", "structure"]
        private_stmts = []
        for statement in self.statements:
            if not statement.kind in private_kinds:
                continue
            if statement.modifiers and statement.modifiers.visibility == "private":
                private_stmts.append(statement)  
        self.private_stmts = sorted(private_stmts, key=lambda x: x.fileRange, reverse=True)

    def get_statement_name(self, namespace, statement):
        statement_name = statement.name if hasattr(statement, "name") and statement.name else None
        if statement_name:
            if namespace and statement_name.startswith(namespace + "."):
                last_name_port = statement_name[len(namespace) + 1:]
                if not last_name_port in Lean_keywords:
                    statement_name = last_name_port
        if statement.signatureRange:
            pre_signatureRange = LeanFileRange(LeanFilePos(statement.signatureRange.start.line, 1),statement.signatureRange.start)
            pre_signature = self.module.getLeanFile().getTextFromLineModule(pre_signatureRange)[:-1].strip()
            index = pre_signature.rfind(" ")
            if index >= 0:
                check_name = pre_signature[index:].strip()
                if check_name.endswith(statement_name):
                    return check_name
        return statement_name

    def create_lean_text(self, statement: Statement, file):
        text = ""

        namespace = statement.scope_info.namespace.strip() if statement.scope_info.namespace else None
        bprint = False #statement.name.endswith("not_injective_infinite_finite")#.name == "Filter.EventuallyEq.iteratedFDeriv" #statement.name.endswith("volume_pi")
        if file: print(f"statement.name: |{statement.name}| namespace: |{namespace}|", file=file)

        imprts = self.module.getImports()
        if imprts:
            for imprt in imprts:
                imprt_name = ".".join(imprt).strip() 
                if imprt_name != "Init":
                    text += "import " + imprt_name + " -- from module imports\n"
        # Only need to create own module file for testing
        text += "import " + self.module_name + " -- module name\n"

        contexts_namespace, contexts, post_contexts = self.create_local_context(statement.fileRange, namespace, file, bprint)

        num_in = 0
        for context in reversed(contexts):
            if self.normalize(context.text).endswith(" in"):
                num_in += 1
            else:
                break
        if contexts and len(contexts) > 0:
            for context in contexts[:-num_in] if num_in > 0 else contexts:
                text += context.text
                text += f" -- {context.comment}\n" if file else "\n"

        needNamespace, statement_name = self.needNamespace(contexts, contexts_namespace, statement, bprint=bprint)
        if statement_name.startswith("_root_."):
            statement_name = statement_name[len("_root_."):]
        if bprint: print(f"namespace: {contexts_namespace}, needNamespace: {needNamespace}, num_in: {num_in}, statement: {statement.name}, statement_name: {statement_name}")
        if needNamespace:
            text += f"namespace {needNamespace} -- statement namespace\n"
        text += "namespace LeanTestCheckAndValidation\n"
        if num_in > 0:
            for context in contexts[len(contexts)-num_in:]:
                text += context.text
                text += f" -- {context.comment}\n" if file else "\n"

        if bprint: print(f"statement_name: {statement_name}, needNamespace: {needNamespace}")
        isValid, result_text = self.create_statement_text(statement, statement_name, file)
        if isValid:
            text += result_text.strip() + "\n"
            text += "end LeanTestCheckAndValidation\n"
            if needNamespace:
                text += f"end {needNamespace} -- statement namespace\n"
            for context in post_contexts:
                text += context.text
                text += f" -- {context.comment}\n" if file else "\n"
            return True, text
        else:
            return False, result_text
        
    def needNamespace(self, contexts, namespace, statement, bprint=False):
        statement_name = self.get_statement_name(namespace, statement)
        if bprint: print(f"XXXX needNamespace: namespace: {namespace}, statement_name: {statement_name}")  
        name_parts = statement_name.split(".")
        if len(name_parts) > 1:
            statement_namespace = ".".join(name_parts[:-1])
        else:
            return None, statement_name
        for context in contexts:
            nz_context = self.normalize(context.text)
            if not nz_context.startswith("namespace "):
                continue
            if nz_context.endswith(statement_namespace):
                if bprint: print(f"find namespace context: {context.text} for namespace: {statement_namespace}")  
                return None, statement_name
        has_namespace = False
        for stmt in self.statements:
            if stmt.name is None or stmt.name == statement.name:
                continue
            if stmt.modifiers and stmt.modifiers.visibility == "private":
                continue
            stmt_name_parts = stmt.name.split(".")
            if len(stmt_name_parts) == 1:
                continue
            st_ns = ".".join(stmt_name_parts[:-1])
            if st_ns.endswith(statement_namespace):
                has_namespace = True
        if not has_namespace:
            return None, statement_name
            
        return statement_namespace, statement_name
   
    def get_replace_symbols(self, all_symbols, fileRange, file):
        if all_symbols is None:
            return []
        
        inRangeNamespaces = []
        outRangeNamespaaces = []
        current_namespace_parts = []
        for scopeInfo in self.module.getScopeRangeInfos():
            if scopeInfo.range is None or scopeInfo.name is None or scopeInfo.kind != "namespace":
                continue
            if scopeInfo.range.start > fileRange.stop or scopeInfo.range.stop < fileRange.start:
                outRangeNamespaaces.append(scopeInfo)
            else:
                inRangeNamespaces.append(scopeInfo)
                current_namespace_parts.append(scopeInfo.name)

        symbols = []
        replace_dict = {}
        statement_namespace_set = set()
        current_statement = None
        statement_last_parts = []
        for statement in self.statements:
            if statement.fileRange.start == fileRange.start:
                current_statement = statement
            if statement.name:
                name_parts = statement.name.split(".")
                statement_last_part = name_parts[-1] if len(name_parts) > 1 else statement.name
                statement_last_parts.append(statement_last_part)
                name_parts = statement.name.split(".")
                if len(name_parts) > 1:
                    last_ns = name_parts[-2]
                    if not last_ns in statement_namespace_set:
                        statement_namespace_set.add(last_ns)

        bprint = False #current_statement.name.endswith("enorm_toLp")
        force_symbol_namespaces = []
        for entry in self.module.getContextEntries():
            context = entry.content.rstrip()
            nz_context = self.normalize(context.replace("(", " ( ").replace(")", " ) "))
            if not nz_context.startswith("open "):
                continue

            ns_list_str = nz_context[4:]            
            index = nz_context.find("(")
            if index > 0:
                ns_list_str = ns_list_str[:index]
                open_ns_specs = nz_context[index + 1: -1].strip().split(" ")
                for ns_spec in open_ns_specs:
                    for symbol in all_symbols:
                        if symbol.src_name == ns_spec.strip():
                            str_symbol_range = str(symbol.range)
                            if str_symbol_range not in replace_dict.keys():
                                replace_dict[str_symbol_range] = symbol
                                symbols.append(symbol)
                                if file: print(f"replace symbol: {symbol}", file=file)
            ns_list = ns_list_str.strip().split(" ")
            for ns in ns_list:
                if ns in statement_namespace_set and not ns in force_symbol_namespaces:
                    force_symbol_namespaces.append(ns)
        # fail the check case to general . Fail on introduction it does not allow add namespace
        if bprint: print(f"force_symbol_namespaces: {force_symbol_namespaces}")

        current_statement_last_namespace = None
        current_namespace_last = current_namespace_parts[-1] if len(current_namespace_parts) > 0 else None
        if current_statement.scope_info.namespace:
            current_namespace = current_statement.scope_info.namespace.strip()
            current_statement_name = self.get_statement_name(current_namespace, current_statement)
            current_statement_name_parts = current_statement_name.split(".")
            current_statement_last_namespace = current_statement_name_parts[-2] if len(current_statement_name_parts) > 1 else None
        for symbol in all_symbols:
            if symbol.name.startswith("_private."):
                continue
            name_parts = symbol.name.split(".")
            if len(name_parts) > 1:
                last_ns = name_parts[-2]
                last_name = name_parts[-1]
                if bprint: print(f"last_name: {last_name}, symbol.src_name: {symbol.src_name}, last_ns: {last_ns}")
                if last_name != symbol.src_name:
                    continue
                bprint = "List.support_sum_subset" == current_statement.name
                if bprint: print(f"current_statement_last_namespace: {current_statement_last_namespace}, current_namespace_last: {current_namespace_last}, last_ns: {last_ns}")
                if last_ns in force_symbol_namespaces: 
                    if str(symbol.range) not in replace_dict.keys():
                        replace_dict[str(symbol.range)] = symbol
                        symbols.append(symbol)
                        if file: print(f"replace symbol with open conflict: {symbol}", file=file)

                if current_statement_last_namespace and  ( \
                        current_statement_last_namespace != current_namespace_last and current_statement_last_namespace == last_ns):
                    # only for testing since testing add additional namespace
                    if str(symbol.range) not in replace_dict.keys():
                        replace_dict[str(symbol.range)] = symbol
                        symbols.append(symbol)
                        if file: print(f"replace symbol with statement prefix namespace: {symbol}", file=file)  

        for statement in self.statements:
            if not (statement.kind == "theorem" or statement.kind == "definition" or statement.kind == "inductive") or statement.name is None:
                continue

            beforeCurrentStatement = False
            if statement.fileRange.start < fileRange.start:
                beforeCurrentStatement = True

            statement_name = statement.name
            for scopeInfo in inRangeNamespaces:
                if statement_name.startswith(scopeInfo.name):
                    statement_name = statement_name[len(scopeInfo.name) + 1:]
            for scopeInfo in outRangeNamespaaces:
                if statement_name.startswith(scopeInfo.name):
                    statement_name = statement_name[len(scopeInfo.name) + 1:]

            name_parts = statement_name.split(".")
            statement_last_part = name_parts[-1] if len(name_parts) > 1 else statement_name
            
            for symbol in all_symbols:
                if symbol.name.startswith("_private."):
                    continue
                if symbol.src_name == statement_last_part:
                    str_symbol_range = str(symbol.range)
                    
                    inStatements = statement.name != symbol.src_name and statement_last_part in statement_last_parts
                    if symbol.name == symbol.src_name and (not beforeCurrentStatement or inStatements):
                        symbol = LeanSymbolReference("_root_." + symbol.name, symbol.src_name, symbol.range, True)
                        if file: print(f" create root symbol: {symbol}", file=file)
                        if str_symbol_range in replace_dict.keys():
                            in_symbol = replace_dict.pop(str_symbol_range)
                            symbols.remove(in_symbol)

                    if str_symbol_range not in replace_dict.keys():
                        replace_dict[str(symbol.range)] = symbol
                        symbols.append(symbol)
                        if file: print(f"replace symbol by statement: {symbol}", file=file)

        namespaces = [ scopeInfo.name for scope in inRangeNamespaces]
        if file: print(f"current_theorem_name: {current_statement.name}, namespaces: {namespaces} replace_symbols: {len(symbols)}", file=file)
        return sorted(symbols, key=lambda x: x.range, reverse=True) 
    
    def create_local_context(self, fileRange: LeanFileRange, namespace: str, file, bprint):

        if file:
            print(f"scopeInfo check fileRange: {fileRange}", file=file)
        
        fileRanges = [fileRange]
        ex_texts = []
        last_stop_pos = None
        for private_stmt in self.private_stmts:
            if private_stmt.fileRange.stop < fileRange.start:
                private_stmt_namespace = private_stmt.scope_info.namespace.strip() if private_stmt.scope_info.namespace else None
                statement_name = self.get_statement_name(private_stmt_namespace, private_stmt)
                valid, text = self.create_statement_text(private_stmt,statement_name, file=file)
                if valid:
                    ex_texts.append(ContextText(text, "", private_stmt.fileRange.start))
                    fileRanges.append(private_stmt.fileRange)
                    last_stop_pos = private_stmt.fileRange.stop if last_stop_pos and last_stop_pos < private_stmt.fileRange.stop else private_stmt.fileRange.stop
                else:
                    return False, text
        
        exclude_ranges =[]
        ecllude_namesspaces = []
        block_index = 0
        current_namespaces = []
        for scopeInfo in self.module.getScopeRangeInfos():
            hasStatement = False
            for range in fileRanges:
                if scopeInfo.range.inRange(range):
                    hasStatement = True
            if scopeInfo.kind == "section":
                if not hasStatement:
                    exclude_ranges.append(scopeInfo.range)
                    if file: print(f"add exclude section range: {scopeInfo}", file=file)
                else:
                    block_index += 1
                    ex_texts.append(ContextText(scopeInfo.content, "scopeInfo section", scopeInfo.range.start, block_index))
                    end_content = f"end {scopeInfo.name}" if scopeInfo.name else "end"
                    ex_texts.append(ContextText(end_content, f"scopeInfo section: {scopeInfo.content} {scopeInfo.range} {block_index}", scopeInfo.range.stop, block_index))
                    if file: print(f"add texts: {scopeInfo.content}, {scopeInfo}", file=file)                                      
            elif scopeInfo.kind == "namespace":
                namespaces = scopeInfo.name.split(".")
                if bprint: print(f"#### hasStatement: {hasStatement}, scopeInfo.name: {scopeInfo.name}, namespace: {namespace}")
                if not hasStatement:
                    exclude_ranges.append(scopeInfo.range)
                    ecllude_namesspaces.append(scopeInfo.name)
                    if file: print(f"add exclude namespace range: {scopeInfo}", file=file)
                else:
                    full_namespace = (".".join(current_namespaces) + ".") if len(current_namespaces) > 0 else "" + scopeInfo.name
                    if bprint: print(f"#### full_namespace: {full_namespace}")
                    #if namespace and namespace.startswith(full_namespace):
                    current_namespaces.extend(namespaces)
                    block_index += 1
                    ex_texts.append(ContextText(f"namespace {scopeInfo.name}", "scopeInfo namespace", scopeInfo.range.start, block_index))
                    ex_texts.append(ContextText(f"end {scopeInfo.name}", f"scopeInfo {scopeInfo.name} {scopeInfo.range} {block_index}", scopeInfo.range.stop, block_index))
                    if file: print(f"add texts: namespace {namespace}, {scopeInfo}", file=file)


        last_stop_pos = fileRange.stop if last_stop_pos and last_stop_pos < fileRange.stop else fileRange.stop
        exclude_ranges.append(LeanFileRange(last_stop_pos, LeanFilePos(sys.maxsize, sys.maxsize)))
        context_dict = {}
        texts =[]
        blocks = []
        for entry in self.module.getContextEntries(): 
            if entry.range.start > last_stop_pos:  
                continue
            invalid_entry = self.inRange(exclude_ranges, entry.range)
            if invalid_entry:
                if file: print(f"exclude variable: {entry.content}, variable.fileRange: {entry.range}, exclude_section_range: {exclude_ranges}", file=file)
                continue
            if entry.kind in ["notation", "notation3", "variable","open", "universe", "set_option", "noncomputable", "include", "custom_macro", "attribute", "in", "mixfix", "alias", "macro", "macro_rules", "syntax", "prefix"]:
                if entry.kind == "set_option":
                    if "linter.indexVariables" in entry.content or "linter.listVariables" in entry.content: # Lean Internal variable
                        continue
                 
                self.append_ex_texts(ex_texts, blocks, texts, context_dict, entry.range.start, file)

                hasStatement = False
                for range in fileRanges:
                    if entry.range.inRange(range):
                        hasStatement = True

                if entry.kind == "in" and not hasStatement:
                    continue
                context = entry.content.rstrip()
                nz_context = self.normalize(context)
                if entry.kind in ["notation", "notation3", "mixfix", "attribute", "macro", "macro_rules", "syntax", "prefix", "alias", "custom_macro"]:
                    if not self.isLocalContext(entry):
                        continue

                if nz_context in context_dict:
                    previous_content = context_dict[nz_context]
                    del previous_content

                #if nz_context.startswith("open ") and "(" in nz_context and ")" in nz_context:
                #    index = context.find("(")
                #    context = context[:index]

                context_dict[nz_context] = context
                if file: print(f"add entry: {context}, entry.range: {entry.range}", file=file)
                raw_kind = entry.raw_kind if entry.raw_kind else ""
                comment = f"context kind: {entry.kind} {raw_kind}"
                texts.append(ContextText(context, comment, entry.range.start))

        self.append_ex_texts(ex_texts, blocks, texts, context_dict, fileRange.start, file)

        post_texts = []
        ex_texts = [ex_text for ex_text in ex_texts if ex_text.blockIndex]
        ex_texts.sort(key=attrgetter("pos"))
        ex_texts.sort(key=attrgetter('blockIndex'), reverse=True) 
        for ex_text in ex_texts:
            if ex_text.pos < fileRange.stop or ex_text.blockIndex is None:
                continue            
            if ex_text.blockIndex in blocks:
                post_texts.append(ex_text)
        
        current_namespace = ".".join(current_namespaces) if len(current_namespaces) > 0 else None
        texts.sort(key=attrgetter("pos"))
        return current_namespace, texts, post_texts
    
    def isLocalContext(self, entry):
        context = entry.content.rstrip()
        nz_context = self.normalize(context)
        if nz_context.startswith("@["):
            index = nz_context.find("]")
            if index > 0:
                nz_context = nz_context[index + 1:].strip()
        if nz_context.startswith("local") or nz_context.startswith("private"): #or nz_context.startswith("scoped") 
            return True
        
        nz_context = nz_context.replace("[ ", "[").replace(" ]", "]")
        if entry.kind == "attribute":
            if "[local instance" in nz_context or "[local simp]" in nz_context:
                return True
        return False
    
    def inRange(self, ranges, check_range):
        for exclude_range in ranges:
            if exclude_range.inRange(check_range):
                return True
        return False
    
    def append_ex_texts(self, ex_texts, blocks, texts, context_dict, currentPos: LeanFilePos, file):
        i = 0
        for ex_text in ex_texts[:]:
            if ex_text.pos >= currentPos:
                continue
            if ex_text.blockIndex:
                if ex_text.text.startswith("end"):
                    blocks.remove(ex_text.blockIndex) 
                else:
                    blocks.append(ex_text.blockIndex)
            nz_context = self.normalize(ex_text.text)
            if nz_context in context_dict:
                previous_content = context_dict[nz_context]
                del previous_content
                
            context_dict[nz_context] = ex_text
            if file: print(f"add ex_text: {ex_text.text}, ex_text.rangepos: {ex_text.pos}", file=file)
            texts.append(ex_text)
            ex_texts.remove(ex_text)
        
    def create_statement_text(self, statement: Statement, statement_name: str,file = None):
        internal_name = statement.internal_name if hasattr(statement, "internal_name") else statement_name
        all_symbols = self.module.getSymbols(statement.kind, internal_name)
        if all_symbols is None and internal_name != statement_name:
            all_symbols = self.module.getSymbols(statement.kind, statement_name)
        if all_symbols:
            exclusiveSymbols = None
            if self.exclusiveConfig.config:
                exclusiveSymbols = self.exclusiveConfig.getConfigList("symbol")
            if file: print(f"internal_name: {internal_name}, kind: {statement.kind}, all_symbols: {len(all_symbols)}, theorem name: {statement_name}", file=file)
            for symbol in all_symbols:
                if file: print(f"    symbol: {symbol}", file=file)
                if exclusiveSymbols:
                    if symbol.name in exclusiveSymbols:
                        return False, f"Symbol: {symbol}"
        else:
            if file: print(f"internal_name: {internal_name}, kind: {statement.kind}, all_symbols: None, theorem name: {statement_name}", file=file)
        replace_symbols = self.get_replace_symbols(all_symbols, statement.fileRange, file=file) 
        text = ""

        attrs = self.create_attrs_text(statement.modifiers.attrs)
        if attrs:
            text += attrs.strip() + "\n"
        if statement.modifiers.visibility:
            text += statement.modifiers.visibility.strip() + " "
        if statement.modifiers.compute_kind:
            text += statement.modifiers.compute_kind.strip() + " "
        if statement.modifiers.rec_kind:
            text += statement.modifiers.rec_kind.strip() + " "
        if statement.modifiers.is_unsafe:
            text += "unsafe "
        if statement.modifiers.rec_kind_left:
            text += statement.modifiers.rec_kind_left.strip() + " "
        text += statement.command.strip() + " "
        if statement.modifiers.rec_kind_right:
            text += statement.modifiers.rec_kind_right.strip() + " "
        if statement_name:
            text += statement_name + " "
        if hasattr(statement, "signature") and statement.signature and statement.signatureRange:
            signature = self.replaceContent(statement.signatureRange, replace_symbols, statement_name, file) + " "
            text += signature
        if hasattr(statement, "value") and statement.value and statement.valueRange:         
            value = self.replaceContent(statement.valueRange, replace_symbols, statement_name, file).rstrip()
            text += value
        return True, text.strip()
    
    def replaceSymbolLine(self, line, range, symbol, last_item, replace_name, file):
        replace_symbol = symbol.src_name.replace(last_item, replace_name)
        start_column = range.start.column if range.start.line == symbol.range.start.line else 1
        column_start = symbol.range.start.column - start_column                  
        column_stop = symbol.range.stop.column - start_column
        previous_char = line[column_start-1:column_start] if column_start > 1 else None
        if previous_char == ".":
            if file: print(f"replaceContent skip with '.': line: {line}, symbol: {symbol}", file=file)
            return line
        else:
            if file: print(f"replaceContent not skip with '{previous_char}': line: {line}, symbol: {symbol}", file=file)
        replace_line = line[:column_start] + replace_symbol + line[column_stop + 1:]
        if file: print(f"replaceContent: symbol {symbol}, range: {range}", file=file)
        if file: print(f"replaceContent: replace_symbol |{line}| |{replace_line}|", file=file)
        return replace_line

    def replaceContent(self, range: LeanFileRange, replace_symbols, statement_name, file):
        if range is None:
            return None
        leanFile = self.module.getLeanFile()
        content = leanFile.getTextFromLineModule(range)
        lines = content.split("\n")
        for symbol in replace_symbols:
            if not symbol.namespace_prefix_safe:
                if file: print(f"replaceContent skip not namespace_prefix_safe: {symbol}", file=file)
                continue
            if symbol.range is None or not range.inRange(symbol.range):
                if file: print(f"replaceContent not in range: range: {range}, symbol.range: {symbol.range}", file=file)
                continue
            line_index = symbol.range.start.line - range.start.line
            replace_name = symbol.name
            name_parts = symbol.src_name.split(".")
            if len(name_parts) > 1:
                name_parts = name_parts[-2:]
                last_item = None
                for item in reversed(name_parts):
                    check_item = item + "." + last_item if last_item else item
                    if symbol.src_name.endswith(check_item): 
                        last_item = check_item
            else:
                last_item = symbol.src_name
            if last_item is None:
                if file: print(f"replaceContent Fail last_item: {last_item}, replace_name: {replace_name}, symbol: {symbol}", file=file)
                continue
            if last_item == replace_name:
                if file: print(f"replaceContent skip symbol: {symbol}", file=file)
                continue
            if symbol.range.start.line != symbol.range.stop.line:
                if file: print(f"replaceContent Fail line: {symbol.src_name} {symbol.range.start.line}, {symbol.range.stop.line}", file=file)
                continue
            if line_index < 0 or line_index >= len(lines):
                if file: print(f"replaceContent Fail line range: {symbol.src_name} {range.start.line}, {symbol.range.start.line}, {len(lines)}", file=file)
                continue
            if symbol.range.stop.column - symbol.range.start.column + 1 != len(symbol.src_name):
                if file: print(f"replaceContent Fail column range: {symbol.src_name} {symbol.range.start.column}, {symbol.range.stop.column}, {len(symbol.src_name)}", file=file)
                continue
            lines[line_index] = self.replaceSymbolLine(lines[line_index], range, symbol, last_item, replace_name, file)
        return leanFile.remove_comment("\n".join(lines))

    def create_attrs_text(self, attrs: list):
        if attrs is None or len(attrs) == 0:
            return None
        text = ""
        for attr in attrs:
            if attr.name == "to_additive":
                nz_content = self.normalize(attr.content.replace("(", "( ").replace(":=", " := "))
                if nz_content.startswith("to_additive ( attr := "):
                    continue

                if nz_content == "to_additive":
                    continue

            if len(text) > 0:
                text += ", "
            if attr.kind and attr.kind != "global":
                text += attr.kind.strip() + " "
            text += attr.content.strip()
        if len(text) == 0:
            return None
        return f"@[{text}]"

    def normalize(self, str):
        str = str.replace("\t", " ").replace("\r", " ").replace("\n", " ")
        return " ".join(str.split())
