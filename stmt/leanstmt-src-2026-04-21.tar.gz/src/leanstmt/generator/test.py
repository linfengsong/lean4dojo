import os
from datetime import datetime
from .lean_project import LeanProject
from .verify_module import verifyModule
from .execute_module import executeModule, executeModuleInternal
from .lean_create_statement import ExclusiveConfig
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm

def printResult(log_fp, result_str):
    if result_str and len(result_str) > 0:
        log_fp.write(result_str)
        log_fp.flush()

def processProjectDebug(log_fp, project: LeanProject, exclusiveConfig, module_locations, execute_mode: bool, print_content: bool, verify_check: bool):
    total_count = 0
    total_diffs = 0
    for module_name in module_locations.keys():
        if not module_name in exclude_list:
            if execute_mode: 
                result_str, count, diff_count = executeModuleInternal(project.coreProject.root_dir, exclusiveConfig, module_name, print_content, verify_check)
            else:
                result_str, count, diff_count = verifyModule(project, module_name)
            printResult(log_fp, result_str)
            total_count += count
            total_diffs += diff_count
    printResult(log_fp, f"Total count: {total_count}, Total diffs: {total_diffs}")
    return total_count, total_diffs

def processProject(log_fp, project: LeanProject, exclusiveConfig, module_locations, execute_mode: bool, print_content: bool, verify_check: bool):
    max_workers = os.cpu_count()
    total_count = 0
    total_diffs = 0
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        if execute_mode: 
            futures = {
                executor.submit(executeModule, project.coreProject.root_dir, exclusiveConfig, module_name, print_content, verify_check): module_name
                for module_name in module_locations.keys() if not module_name in exclude_list
            }
        else:
            futures = {
                executor.submit(verifyModule, project, module_name): module_name
                for module_name in module_locations.keys() if not module_name in exclude_list
            }
        for future in tqdm(as_completed(futures), total=len(futures), desc="Comparing Modules"):
            result_str = None
            try:
                result_str, count, diff_count = future.result()
            except Exception as e:
                result_str = f"Process failure: {e}\n"
                count = 1
                diff_count =1
            if result_str and len(result_str) > 0:
                log_fp.write(result_str)
                log_fp.flush()
            total_count += count
            total_diffs += diff_count
    printResult(log_fp, f"Execute finished: Total failures: {total_diffs}/{total_count}")
    return total_count, total_diffs

def main(root_dir: str, search_list: list, exclude_list: list =[],  exclusiveData= {}, execute_mode: bool = False, print_content: bool = False, 
         verify_check: bool = True, bDebug: bool = False, bParallel: bool = False):
    project = LeanProject(root_dir)
    module_locations = project.coreProject.find_module_locations(search_list)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    label = "execute" if execute_mode else "verify"
    file_name = f"{label}_lean_{timestamp}.log"
    log_dir = os.path.join(root_dir, ".logs")
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, file_name)



    exclusiveConfig = ExclusiveConfig(exclusiveData)

    #if not bDebug:
    #    bDebug = len(module_locations) <= 1

    with open(log_file, "w", encoding="utf-8") as log_fp:
        if bDebug:
            print(f"Debug mode Processing modules sequentially")
        if bParallel:
            total_count, total_diffs = processProject(log_fp, project, exclusiveConfig, module_locations, execute_mode, print_content, verify_check)
        else:
            total_count, total_diffs = processProjectDebug(log_fp, project, exclusiveConfig, module_locations, execute_mode, print_content, verify_check)
           
        print(f"Execute finished: Total failures: {total_diffs}/{total_count}")


if __name__ == "__main__":
    root_dir = "/home/linfe/math/lean_test"
    module_name = "LeanTest.Basic"
    module_name = "Mathlib.Data.Nat.Init"
    module_name = "Mathlib.Tactic.Widget.LibraryRewrite"
    #module_name = "Mathlib.Util.MemoFix"
    #module_name = "Mathlib.RingTheory.TensorProduct.Basic"
    #module_name = "Mathlib.MeasureTheory.Function.LpSpace.Basic"
    #main2(root_dir, module_name, print_content=False, verify_check=True)

    exclusiveData = {
        "error_message": [
            "Unknown constant `Array.shrink.loop`",
            "Unknown constant `Array.mapM.map`",
            "Cannot add attribute `[unbox]` to declaration `Prod`"
            ],
        "symbol": [
            "Array.anyM.loop"
        ]
    }

    exclude_list = [
        "Init.WF",
        "Mathlib.Data.Prod.Basic"]

    search_list = [
            "Init.Try",
            #"Init.Data.Array.Lemmas", symbol fail
            "Init.Data.Cast",
            "Init.Data.Nat.Div.Basic",
            #"Init.Data.Nat.Power2", #many place fail
            "Init.Data.Option.Array",
            "Init.Data.RArray",
            "Init.Data.Sum.Lemmas",
            "Init.Data.Vector.Extract",
            #"Init.GetElem", # rfl fail
            "Init.Grind.Ordered.Module",
            #"Init.Meta.Defs", # getUtf8Byte' call fail
            #"Init.Prelude", # fail on: show LT.lt (dite _ _ _) y from
            "Init.Omega.LinearCombo",
            "Mathlib.CategoryTheory.Monoidal.Cartesian.CommGrp_",
            "Mathlib.Data.EReal.Operations",
            "Mathlib.Data.List.Chain",
            "Mathlib.Data.Nat.Init",
            #"Mathlib.Data.Finset.NAry", # simp fail
            "Mathlib.Data.Finsupp.Interval",
            #"Mathlib.Data.Set.Basic", # simp fail
            #"Mathlib.Data.Sym.Basic", #rw fail 
            "Mathlib.MeasureTheory.SetAlgebra",
            "Mathlib.MeasureTheory.PiSystem",
            "Mathlib.MeasureTheory.Constructions.BorelSpace.Basic",
            "Mathlib.MeasureTheory.Constructions.HaarToSphere",
            "Mathlib.MeasureTheory.Constructions.Pi",
            "Mathlib.MeasureTheory.Constructions.Polish.Basic",
            "Mathlib.MeasureTheory.Constructions.SubmoduleQuotient",
            "Mathlib.MeasureTheory.Constructions.Projective",
            "Mathlib.MeasureTheory.Function.AEEqFun",
            "Mathlib.MeasureTheory.Function.AEEqFun.DomAct",
            "Mathlib.MeasureTheory.Function.SpecialFunctions.Inner",
            "Mathlib.MeasureTheory.Measure.GiryMonad",
            "Mathlib.MeasureTheory.Measure.Dirac",
            "Mathlib.MeasureTheory.OuterMeasure.Basic",
            #"Mathlib.Algebra.Algebra.Subalgebra.Basic", #simp
            #"Mathlib.Algebra.Category.CommAlgCat.Monoidal", #symbol missing in signature, it only extract from value
            "Mathlib.Algebra.Category.MonCat.Colimits",
            #"Mathlib.Analysis.Calculus.ContDiff.FTaylorSeries", # rw fail
            #"Mathlib.Analysis.NormedSpace.Alternating.Uncurry.Fin", # do not know symbol fail
            "Mathlib.Analysis.SpecialFunctions.Log.Basic"
            "Mathlib.CategoryTheory.Limits.HasLimits",
            "Mathlib.GroupTheory.GroupAction.Primitive",
            #"Mathlib.LinearAlgebra.Dimension.Localization", #isLocalizedModule_iff_isLocalization access local section variable
            #"Mathlib.LinearAlgebra.CliffordAlgebra.Even", #no Goal issue
            "Mathlib.Order.DirectedInverseSystem",
            #"Mathlib.RingTheory.TensorProduct.Basic", # suffices fail
            #"Mathlib.RingTheory.RingHom.Locally", #simp fail
            "Mathlib.Tactic.MoveAdd",
            "Mathlib.Tactic.Hint",
            "Mathlib.Tactic.Widget.LibraryRewrite",
            "Mathlib.Tactic.Widget.Calc",
            #"Mathlib.Topology.ContinuousMap.Bounded.Normed", # simp fail
            "Mathlib.Topology.Order.LeftRightNhds",
            "Mathlib.Util.Export",
            "Mathlib.Util.MemoFix",
        ]
    
    #search_list = ["Mathlib.Algebra.Category.CommAlgCat.Monoidal"] # symbol fail to retrieve
    
    ##search_list = ["Init","Mathlib","LestTest"]
    ##search_list = ["Init"]
    #search_list = ["Mathlib"]
    ##search_list = ["Mathlib.Data"]
    #search_list = ["Mathlib.MeasureTheory"]
    ##search_list = ["Mathlib.Analysis"]

    #search_list = ["Init.Data.Sum.Lemmas"]
    #search_list = ["Init.Data.Vector.Extract"]
    #search_list = ["Mathlib.Data.Nat.Init"]
    #search_list = ["Mathlib.MeasureTheory.PiSystem"]
    #search_list = ["Mathlib.MeasureTheory.SetAlgebra"]
    #search_list = ["Mathlib.MeasureTheory.Constructions.BorelSpace.Basic"]
    #search_list = ["Mathlib.MeasureTheory.Constructions.HaarToSphere"]
    
    #search_list = ["Mathlib.MeasureTheory.Constructions.Pi"]
    #search_list = ["Mathlib.MeasureTheory.Constructions.Polish.Basic"]
    #search_list = ["Mathlib.MeasureTheory.Constructions.SubmoduleQuotient"]
    #search_list = ["Mathlib.MeasureTheory.Constructions.Projective"]
    #search_list = ["Mathlib.MeasureTheory.Function.AEEqFun"]
    #search_list = ["Mathlib.MeasureTheory.Function.AEEqFun.DomAct"]
    #search_list = ["Mathlib.MeasureTheory.Function.SpecialFunctions.Inner"]
    #search_list = ["Mathlib.MeasureTheory.Measure.GiryMonad"]
    #search_list = ["Mathlib.MeasureTheory.Measure.Dirac"]
    #search_list = ["Mathlib.MeasureTheory.OuterMeasure.Basic"]
    ##search_list = ["Mathlib.LinearAlgebra.CliffordAlgebra.Even"]
    ##search_list = ["Mathlib.LinearAlgebra.Dimension.Localization"]
    #search_list = ["Mathlib.Data.List.Chain"]
    #search_list = ["Mathlib.Topology.ContinuousMap.Bounded.Normed"]

    #search_list = ["Mathlib.Algebra.Category.CommAlgCat.Monoidal"]
    #search_list = ["Init.GetElem"]
    #search_list = ["Mathlib.Data.EReal.Operations"]
    #search_list = ["Mathlib.Analysis.Calculus.ContDiff.FTaylorSeries"]
    #search_list = ["Mathlib.RingTheory.TensorProduct.Basic"]
    #search_list = ["Mathlib.Data.Sym.Basic"]
    #search_list = ["Init.Data.Nat.Div.Basic"]
    #search_list = ["Init.Data.Array.Lemmas"]
    #search_list = ["Init.Prelude"]
    #search_list = ["Mathlib.Analysis.NormedSpace.Alternating.Uncurry.Fin"]
    #search_list = ["Mathlib.Order.DirectedInverseSystem"]

    search_list2 = [
        "Mathlib.MeasureTheory.Constructions.BorelSpace.Metric",
        "Mathlib.MeasureTheory.Function.ConditionalExpectation.AEMeasurable",
        "Mathlib.MeasureTheory.Function.SimpleFuncDenseLp",
        "Mathlib.MeasureTheory.MeasurableSpace.Embedding",  # test need add _root_.
        "Mathlib.MeasureTheory.Function.ConvergenceInMeasure",
        "Mathlib.MeasureTheory.Constructions.BorelSpace.Metric",
        "Mathlib.MeasureTheory.Function.L1Space.Integrable",
        #"Mathlib.MeasureTheory.Integrable",
        "Mathlib.MeasureTheory.Integral.TorusIntegral",
        "Mathlib.MeasureTheory.Integral.Marginal",
        "Mathlib.MeasureTheory.Constructions.Polish.Basic",
        #"Mathlib.GroupTheory.GroupAction.Hom",
        "Mathlib.Data.Quot",
        #"Mathlib.Data.Finmap",
        #"Mathlib.Data.Finsupp.Defs", #irreducible_def
        "Mathlib.Data.Finsupp.SMul",
        #"Mathlib.Data.Rel",  #missing @[inherit_doc] scoped infixl:62 " ○ " => comp. fix to remove scopd notation
        #"Mathlib.Data.Complex.Basic", #extra: @[inherit_doc] notation "ℂ" => Complex. fixed but other issue break
        #"Mathlib.Data.Set.Card", #extra: macro_rules, fixed but other issue break. need replace simpl with rw
        "Mathlib.GroupTheory.Torsion", #extra: attribute [deprecated IsMulTorsionFree 
                                       #       @[to_additive (attr := deprecated Pi.instIsMulTorsionFree fixed but other break
        #"Mathlib.GroupTheory.Sylow", # when call theoren self. it use @<current method name> @exists_subgroup_card_pow_prime_le _ _ n (m - 1) _ to @test_exists_subgroup_card_pow_prime_le _ _ n (m - 1) _#
        "Mathlib.GroupTheory.Coxeter.Length",   #local prefix:100 "ℓ" => cs.length
        "Mathlib.Algebra.Group.Even", #@[to_additive (attr := aesop safe) Even.two_nsmul]
        "Mathlib.Algebra.Group.Center", ##@[to_additive]
        "Mathlib.Algebra.Order.Group.DenselyOrdered", # private theorem using in theorem body
        #"Mathlib.Algebra.Group.Submonoid.Operations", # when namespace end, it should not add open that namespace
        #"Mathlib.Algebra.Order.Monoid.Units", # extra: rfl
        "Mathlib.Algebra.Star.RingQuot", #private irreducible_def
        "Mathlib.NumberTheory.NumberField.FinitePlaces",
        "Mathlib.MeasureTheory.MeasurableSpace.Defs",
        "Mathlib.NumberTheory.Cyclotomic.Three",
        "Mathlib.AlgebraicGeometry.Spec",
        "Mathlib.MeasureTheory.Constructions.BorelSpace.Metric",
        "Mathlib.MeasureTheory.Function.AEEqFun",
        "Mathlib.Topology.Order.DenselyOrdered",
        "Mathlib.MeasureTheory.Function.L1Space.HasFiniteIntegral", # missing namespace: MeasureTheory.HasFiniteIntegral HasFiniteIntegral.enorm, test self call as well
        "Mathlib.MeasureTheory.OuterMeasure.Caratheodory", #Need call self: isCaratheodory_iUnion_lt to test_isCaratheodory_iUnion_lt, problem cannot find range for this case to fix
        "Mathlib.NumberTheory.JacobiSum.Basic", # section only for variable and not for others. so private should be in lean file scope
        "Mathlib.Data.ENNReal.Inv",
        "Mathlib.Algebra.Star.SelfAdjoint", # fix marco with <name>(n) syntax error
        "Mathlib.Analysis.Asymptotics.LinearGrowth", #namespace before open issue, it could test marco with <name>(n) fix as well

        "Mathlib.MeasureTheory.Measure.Lebesgue.EqHaar", # need root on parallelepiped 
        "Mathlib.MeasureTheory.Covering.Differentiation",  # #adaptation_note /-- .-/
        #"Mathlib.Data.TypeVec", #@[typevec] does not allow
        "Mathlib.Data.Finset.Card", #grind issue
        "Mathlib.Topology.MetricSpace.Polish", # open namespace fail. there is no such namespace
        "Mathlib.Topology.Algebra.StarSubalgebra", # multiple in statement
        "Mathlib.Topology.Algebra.Order.Floor", # ceil symbol not match
        #"Mathlib.Topology.Compactness.Compact", # fail to add symbol namespace, Function.compl ∘ t
        "Mathlib.Order.CompleteBooleanAlgebra", # two namespace conflict
        #"Mathlib.RepresentationTheory.Basic", # two namespace conflict, namespace issue fix, it still has simp problem
        #"Mathlib.RepresentationTheory.Homological.GroupCohomology.Functoriality", #elementwise (attr := simp)]
        "Mathlib.Algebra.Lie.UniversalEnveloping", # replace sign symbo

        "Mathlib.Algebra.BigOperators.Group.Finset.Defs", #private inductive
        #"Mathlib.MeasureTheory.Measure.LevyProkhorovMetric",# remove module import work, problem is symbol and need add: lean_notation = f'local notation:25 {src_template}:25 => {name} α β' to and it can handle "→ᵇ"
        #"Mathlib.Algebra.Order.BigOperators.Ring.Finset", # private alias, fix but different error
        "Mathlib.CategoryTheory.Sites.Coherent.SequentialLimit", #structure
        #"Mathlib.Algebra.Group.UniqueProds.Basic", # abbrev, other problem class member cannot access UniqueProds at structure, it need add symbol replacement to check if name start with strucure name
        "Mathlib.Util.Export", #opaque, works but no theorem
        "Mathlib.Data.Fintype.Fin", # need restrict: open <namespace> (something)
        "Mathlib.Data.Fintype.Sum", # not allow add namepsace on introduction. error: replace symbol with open conflict:
        "Mathlib.Data.Fintype.EquivFin", # replace private def symbole
        "Mathlib.Data.Sign.Defs",
        "Mathlib.Data.Finsupp.BigOperators",
        "Mathlib.Data.TypeVec", #@[typevec, remove
        "Mathlib.Data.Fintype.BigOperators", #rfl not replace
        "Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic", # symbol add _root_
        "Mathlib.MeasureTheory.Integral.Bochner.L1", # symbol include after current statement to match
        "Mathlib.MeasureTheory.VectorMeasure.Decomposition.Lebesgue", #private symbol load

        "Mathlib.Data.Finset.Card" #grind
        "Mathlib.Data.Nat.Squarefree",
        "Mathlib.Data.Nat.Factorization.PrimePow", # test @ of symbol
        "Mathlib.Data.Nat.Factorial.Basic", # statement name has "." to allow access same "." pattern resource
        "Mathlib.Data.Real.Basic", # multiple statement using same private local declarations
        "Mathlib.Data.Option.NAry", # attribute local test
        "Mathlib.MeasureTheory.Measure.WithDensityFinite" # Attribute local as private statement
    ]

    search_list.extend(search_list2)
    #search_list = ["Mathlib"]
    #search_list = ["Mathlib.MeasureTheory"]
    search_list = ["Mathlib.Data"]

    #search_list = ["Mathlib.MeasureTheory.Constructions.BorelSpace.Metric"]
    #search_list = ["Mathlib.MeasureTheory.Function.ConditionalExpectation.AEMeasurable"]

    #search_list = ["Mathlib.MeasureTheory.Function.SimpleFuncDenseLp"]
    #search_list = ["Mathlib.MeasureTheory.MeasurableSpace.Embedding"]  # test need add _root_.
    #search_list = ["Mathlib.MeasureTheory.Function.ConvergenceInMeasure"]
    #search_list = ["Mathlib.MeasureTheory.Constructions.BorelSpace.Metric"]
    #search_list = ["Mathlib.MeasureTheory.Function.L1Space.Integrable"]
    ##search_list = ["Mathlib.MeasureTheory.Integrable"]
    #search_list = ["Mathlib.MeasureTheory.Integral.TorusIntegral"]
    #search_list = ["Mathlib.MeasureTheory.Integral.Marginal"]
    #search_list = ["Mathlib.MeasureTheory.Constructions.Polish.Basic"]
    
    ##search_list = ["Mathlib.GroupTheory.GroupAction.Hom"]
    #search_list = ["Mathlib.Data.Quot"]
    ##search_list = ["Mathlib.Data.Finmap"]
    ##search_list = ["Mathlib.Data.Finsupp.Defs"] #irreducible_def
    #search_list = ["Mathlib.Data.Finsupp.SMul"]
    
    ##search_list = ["Mathlib.Data.Rel"]  #missing @[inherit_doc] scoped infixl:62 " ○ " => comp. fix to remove scopd notation
    ##search_list = ["Mathlib.Data.Complex.Basic"] #extra: @[inherit_doc] notation "ℂ" => Complex. fixed but other issue break
    ##search_list = ["Mathlib.Data.Set.Card"] #extra: macro_rules, fixed but other issue break. need replace simpl with rw
    #search_list = ["Mathlib.GroupTheory.Torsion"] #extra: attribute [deprecated IsMulTorsionFree 
                                                  #       @[to_additive (attr := deprecated Pi.instIsMulTorsionFree fixed but other break
    ##search_list = ["Mathlib.GroupTheory.Sylow"] # when call theoren self. it use @<current method name> @exists_subgroup_card_pow_prime_le _ _ n (m - 1) _ to @test_exists_subgroup_card_pow_prime_le _ _ n (m - 1) _#
    #search_list = ["Mathlib.GroupTheory.Coxeter.Length"]   #local prefix:100 "ℓ" => cs.length
    #search_list = ["Mathlib.Algebra.Group.Even"] #@[to_additive (attr := aesop safe) Even.two_nsmul]
    #search_list = ["Mathlib.Algebra.Group.Center"] ##@[to_additive]
    #search_list = ["Mathlib.Algebra.Order.Group.DenselyOrdered"] # private theorem using in theorem body
    ##search_list = ["Mathlib.Algebra.Group.Submonoid.Operations"] # when namespace end, it should not add open that namespace
    ##search_list = ["Mathlib.Algebra.Order.Monoid.Units"] # extra: rfl
        #search_list = ["Mathlib.Algebra.Star.RingQuot"] #private irreducible_def, test statement namespace
       #search_list = ["Mathlib.NumberTheory.NumberField.FinitePlaces"]
    #search_list = ["Mathlib.MeasureTheory.MeasurableSpace.Defs"]
    #search_list = ["Mathlib.NumberTheory.Cyclotomic.Three"]
    #search_list = ["Mathlib.AlgebraicGeometry.Spec"]
    #search_list = ["Mathlib.MeasureTheory.Constructions.BorelSpace.Metric"]
    #search_list = ["Mathlib.MeasureTheory.Function.AEEqFun"]
    #search_list = ["Mathlib.Topology.Order.DenselyOrdered"]
    #search_list = ["Mathlib.MeasureTheory.Function.L1Space.HasFiniteIntegral"] # missing namespace: MeasureTheory.HasFiniteIntegral HasFiniteIntegral.enorm, test self call as well
    #search_list = ["Mathlib.MeasureTheory.OuterMeasure.Caratheodory"] #Need call self: isCaratheodory_iUnion_lt to test_isCaratheodory_iUnion_lt, problem cannot find range for this case to fix
    #search_list = ["Mathlib.NumberTheory.JacobiSum.Basic"] # section only for variable and not for others. so private should be in lean file scope
    #search_list = ["Mathlib.Data.ENNReal.Inv"]
    #search_list = ["Mathlib.Algebra.Star.SelfAdjoint"] # fix marco with <name>(n) syntax error
    #search_list = ["Mathlib.Analysis.Asymptotics.LinearGrowth"] #namespace before open issue, it could test marco with <name>(n) fix as well
    #search_list = ["Mathlib.MeasureTheory.Function.ConditionalExpectation.CondexpL1"] # test in case
    ##search_list = ["Mathlib.MeasureTheory.Function.LpSpace.Basic"] # should not open MemLp, MemLp.enorm conflict without any information to indicate but it in symbol list
    
    #search_list = ["Mathlib.MeasureTheory.Measure.Lebesgue.EqHaar"] # need root on parallelepiped 
    #search_list = ["Mathlib.MeasureTheory.Covering.Differentiation"] # #adaptation_note /-- .-/
    ##search_list = ["Mathlib.Data.TypeVec"] #@[typevec] does not allow
    #search_list = ["Mathlib.Data.Finset.Card"] #grind issue
    #search_list = ["Mathlib.Topology.MetricSpace.Polish"] # open namespace fail. there is no such namespace
    #search_list = ["Mathlib.Topology.Algebra.StarSubalgebra"] # multiple in statement
    #search_list = ["Mathlib.Topology.Algebra.Order.Floor"] # ceil symbol not match
    ##search_list = ["Mathlib.Topology.Compactness.Compact"] # fail to add symbol namespace, Function.compl ∘ t
    #search_list = ["Mathlib.Order.CompleteBooleanAlgebra"] # two namespace conflict
    ##search_list = ["Mathlib.RepresentationTheory.Basic"] # two namespace conflict, namespace issue fix, it still has simp problem
    ##search_list = ["Mathlib.RepresentationTheory.Homological.GroupCohomology.Functoriality"] #elementwise (attr := simp)]
    #search_list = ["Mathlib.Algebra.Lie.UniversalEnveloping"] # replace sign symbo
    
    
    
    
    #search_list = ["Mathlib.Algebra.BigOperators.Group.Finset.Defs"] #private inductive
    ##search_list = ["Mathlib.MeasureTheory.Measure.LevyProkhorovMetric"]# remove module import work, problem is symbol and need add: lean_notation = f'local notation:25 {src_template}:25 => {name} α β' to and it can handle "→ᵇ"

    ##search_list = ["Mathlib.Algebra.Order.BigOperators.Ring.Finset"] # private alias, fix but different error
    #search_list = ["Mathlib.CategoryTheory.Sites.Coherent.SequentialLimit"] #structure
    ##search_list = ["Mathlib.Algebra.Group.UniqueProds.Basic"] # abbrev, other problem class member cannot access UniqueProds at structure, it need add symbol replacement to check if name start with strucure name
    #search_list = ["Mathlib.Util.Export"] #opaque, works but no theorem
    
    #search_list = ["Mathlib.Data.Fintype.Fin"] # need restrict: open <namespace> (something)
    #search_list = ["Mathlib.Data.Fintype.Sum"] # not allow add namepsace on introduction. error: replace symbol with open conflict:
    #search_list = ["Mathlib.Data.Fintype.EquivFin"] # replace private def symbole

    #search_list = ["Mathlib.Data.Sign.Defs"]
    #search_list = ["Mathlib.Data.Finsupp.BigOperators"]

    #search_list = ["Mathlib.Data.TypeVec"] #@[typevec] remove

    #search_list = ["Mathlib.Data.Fintype.BigOperators"] #rfl not replace
    #search_list = ["Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic"] # symbol add _root_
    #search_list = ["Mathlib.MeasureTheory.Integral.Bochner.L1"] # symbol include after current statement to match
    #search_list = ["Mathlib.MeasureTheory.VectorMeasure.Decomposition.Lebesgue"] #private symbol load
    
    #search_list = ["Mathlib.Data.Finset.Card"] #grind
    #search_list = ["Mathlib.Data.Nat.Squarefree"]
    #search_list = ["Mathlib.Data.Nat.Factorization.PrimePow"] # test @ of symbol
    #search_list = ["Mathlib.Data.Nat.Factorial.Basic"] # statement name has "." to allow access same "." pattern resource
    #search_list = ["Mathlib.Data.Real.Basic"] # multiple statement using same private local declarations
    #search_list = ["Mathlib.Data.Option.NAry"] # attribute local test

    #search_list = ["Mathlib.MeasureTheory.Measure.WithDensityFinite"]
    #search_list = ["Mathlib.MeasureTheory.Integral.Lebesgue.Countable"] # | @abc not replace
    #search_list = ["Mathlib.MeasureTheory.Measure.Haar.NormedSpace"]

    execute_mode = True
    print_content = False
    verify_check = True
    bDebug = True
    bParallel = True
    main(root_dir, search_list, exclude_list, exclusiveData, execute_mode, print_content, verify_check, bDebug, bParallel)
    # python -m leanstmt.generator.test