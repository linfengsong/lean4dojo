import sys
from dataclasses import dataclass
from operator import attrgetter
from leanstmt.generator.lean_module import LeanModule
from .lean_statement import Statement, Variable
from .lean_file import LeanFileRange, LeanFilePos
from .lean_module import LeanSymbolReference

Lean_keywords = [
    "def", "theorem", "lemma", "example",
    "inductive", "structure", "class", "instance",
    "constant", "axiom", "abbrev",
    "variable", "variables",
    "if", "then", "else",
    "match", "nomatch", "with",
    "do", "let", "mut",
    "for", "in", "at",
    "try", "catch", "finally",
    "return", "break", "continue",
    "forall", "exists",
    "fun", "λ",
    "have", "show", "suffices",
    "by",
    "from",
    "import", "prelude", "namespace", "section", "end",
    "open", "export", "hiding", "renaming",
    "private", "protected", "noncomputable", "unsafe", "partial",

    "infix", "infixl", "infixr",
    "postfix", "prefix",
    "notation",
    "macro",
    "syntax",
    "declare_syntax_cat", 
    "intro", "intros",
    "apply", "exact", "refine",
    "cases", "induction",
    "rewrite", "rw",
    "simp", "dsimp", "aesop",
    "refl", "rfl",
    "abbrev",
    "opaque","axiom", "constant",
    "attribute",
    "elab", "elab_rules", 
    "sorry",
    "forall", "exists",
    "true", "false" 
    "cexp",
]

class ExclusiveConfig: 
    def __init__(self, data: dict[str, list[str]]):
        self.config: dict[str, list[str]] = data

    def getConfigList(self, name: str):
        if self.config is None:
            return None
        return self.config[name] if name in self.config.keys() else None

@dataclass(frozen=True)
class ContextText:
    text: str
    comment: str
    pos: LeanFilePos
    blockIndex: int = None

class LeanCreateStatement:
    def __init__(self, exclusiveConfig: ExclusiveConfig, module_name: str, module: LeanModule, statements: list[Statement]):
        self.exclusiveConfig = exclusiveConfig
        self.module_name = module_name
        self.module = module
        self.statements = statements

        private_kinds = ["theorem", "definition", "inductive", "abbrev", "structure", "instance"]
        private_stmts = []
        for statement in self.statements:
            if not statement.kind in private_kinds:
                continue
            if statement.modifiers and statement.modifiers.visibility == "private":
                private_stmts.append(statement)  
        self.private_stmts = sorted(private_stmts, key=lambda x: x.fileRange, reverse=True)

    def add_dependency_statements(self, contexts, reserveFileRanges, statements, dependent_ids, file):
        stmts = [stmt for stmt in statements if stmt.id not in dependent_ids]
        for stmt in stmts:
            if not stmt.id in dependent_ids:
                dependent_ids.add(stmt.id)
                valid, text, private_stmts = self.create_statement_text(stmt, None, stmt.name, file=file)
                if valid:
                    contexts.append(ContextText(text, None, stmt.fileRange.start))
                    reserveFileRanges.append(stmt.fileRange)
                    self.add_dependency_statements(contexts, reserveFileRanges, private_stmts, dependent_ids, file)

    def create_lean_text(self, statement: Statement, file):
        namespace = statement.scope_info.namespace.strip() if statement.scope_info.namespace else None
        bprint = False #statement.name.endswith("not_injective_infinite_finite")#.name == "Filter.EventuallyEq.iteratedFDeriv" #statement.name.endswith("volume_pi")        
        if file: print(f"statement.name: |{statement.name}| namespace: |{namespace}|", file=file)

        contexts = []
        reserveFileRanges = []
        dependent_ids = set()
        statement_namespace, statement_name = self.needNamespace(contexts, statement, bprint=bprint)
        primaryIsValid, primary_text, private_statements = self.create_statement_text(statement, statement_namespace, statement_name, file)
        reserveFileRanges.append(statement.fileRange)
        self.add_dependency_statements(contexts, reserveFileRanges, private_statements, dependent_ids, file)

        dependent_statements = self.get_dependent_statements_for_private_symbols(statement)
        self.add_dependency_statements(contexts, reserveFileRanges, dependent_statements, dependent_ids, file)

        current_namespace, post_contexts = self.create_local_context(contexts, statement.fileRange, reserveFileRanges, namespace, file, bprint)

        text = ""
        imprts = self.module.getImports()
        if imprts:
            for imprt in imprts:
                imprt_name = ".".join(imprt).strip() 
                if imprt_name != "Init":
                    text += "import " + imprt_name + "\n"

        if bprint: print(f"statement_name: {statement_name}, needNamespace: {statement_namespace}")
        # Only need to create own module file for testing
        text += "import " + self.module_name + " -- module name\n"

        num_in = 0
        for context in reversed(contexts):
            if self.normalize(context.text).endswith(" in"):
                num_in += 1
            else:
                break
        if contexts and len(contexts) > 0:
            for context in contexts[:-num_in] if num_in > 0 else contexts:
                text += context.text
                text += f" -- {context.comment}\n" if context.comment and file else "\n"

        if statement_name.startswith("_root_."):
            statement_name = statement_name[len("_root_."):]
        if bprint: print(f"current_namespace: {current_namespace}, statement_namespace: {statement_namespace}, num_in: {num_in}, statement: {statement.name}, statement_name: {statement_name}")
        if statement_namespace:
            text += f"namespace {statement_namespace} -- statement namespace\n"
        #text += "namespace LeanTestCheckAndValidation\n"
        if num_in > 0:
            for context in contexts[len(contexts)-num_in:]:
                text += context.text
                text += f" -- {context.comment}\n" if context.comment and file else "\n"

        if primaryIsValid:
            text += primary_text.strip() + "\n"
            #text += "end LeanTestCheckAndValidation\n"
            if statement_namespace:
                text += f"end {statement_namespace} -- statement namespace\n"
            for context in post_contexts:
                text += context.text
                text += f" -- {context.comment}\n" if context.comment and file else "\n"
            
            return True, text
        else:
            return False, primary_text
        
    def needNamespace(self, contexts, statement, bprint=False):
        statement_name = statement.name 
        name_parts = statement_name.split(".")
        if len(name_parts) > 1:
            statement_namespace = ".".join(name_parts[:-1])
        else:
            return None, statement_name
        for context in contexts:
            nz_context = self.normalize(context.text)
            if not nz_context.startswith("namespace "):
                continue
            if nz_context.endswith(statement_namespace):
                return None, statement_name
        has_namespace = False
        for stmt in self.statements:
            if stmt.name is None or stmt.name == statement.name:
                continue
            if stmt.modifiers and stmt.modifiers.visibility == "private":
                continue
            stmt_name_parts = stmt.name.split(".")
            if len(stmt_name_parts) == 1:
                continue
            st_ns = ".".join(stmt_name_parts[:-1])
            if st_ns.endswith(statement_namespace):
                has_namespace = True
        if not has_namespace:
            return None, statement_name
            
        return statement_namespace, statement_name
    
    def get_private_symbol_names(self, statement):
        names = set()

        statementSymbol = self.module.getStatementSymbol(statement)
        if statementSymbol == None:
            return names
        for symbol in statementSymbol.signature_symbols:
            if symbol.is_private:
                if not symbol.name in names:
                    names.add(symbol.name)
        for symbol in statementSymbol.value_symbols:
            if symbol.is_private:
                if not symbol.name in names:
                    names.add(symbol.name)
        return names
    
    def get_local_share_symbols(self, symbols):
        share_symbol = set()
        for entry in self.module.getContextEntries():
            content = " ".join(entry.content.split("\n"))
            if entry.raw_kind == "irreducible_def":
                name = self.get_content_entry_name(entry.raw_kind, entry.content)
                if name:
                    name = name  + "_def"
                    if entry.namespace:
                        name = entry.namespace + "." + name
                    if name in symbols:
                        share_symbol.add(name)
        return share_symbol
    
    def get_content_entry_name(self, kind, entry_content):
        entry_content = entry_content.replace("\n", " ").replace("\t", " ").replace("\r", " ").replace("()", " ").replace("[", " ")
        parts = entry_content.split(" " + kind + " ")
        if len(parts) < 2:
            return None
        if not (" private "  in " " + parts[0] + " "):
            return None
        parts = parts[1].split(" ")
        if len(parts) < 2:
            return None
        return parts[0].strip()
    
    def get_dependent_statements_for_private_symbols(self, statement):
        stmts = []
        symbol_names = self.get_private_symbol_names(statement)
        if len(symbol_names) == 0:
            return stmts
        symbol_names = self.get_local_share_symbols(symbol_names)
        
        for stmt in self.module.getStatements():
            if stmt.kind == statement.kind and stmt.name == statement.name:
                continue
            if stmt.kind != "instance":
                continue
            stmt_names = self.get_local_share_symbols(self.get_private_symbol_names(stmt))
            if len(stmt_names) == 0:
                continue
            diff = symbol_names - stmt_names
            if len(diff) < len(symbol_names):
                stmts.append(stmt)
        return stmts
    
    def get_scope_info_by_range(self, fileRange,):
        inRangeNamespaces = []
        outRangeNamespaaces = []
        current_namespace_parts = []
        for scopeInfo in self.module.getScopeRangeInfos():
            if scopeInfo.range is None or scopeInfo.name is None or scopeInfo.kind != "namespace":
                continue
            if scopeInfo.range.start > fileRange.stop or scopeInfo.range.stop < fileRange.start:
                outRangeNamespaaces.append(scopeInfo)
            else:
                inRangeNamespaces.append(scopeInfo)
                current_namespace_parts.append(scopeInfo.name)
        range_namespace = ".".join(current_namespace_parts) if len(current_namespace_parts) > 0 else None
        return range_namespace, inRangeNamespaces, outRangeNamespaaces
    
    def get_statement_name_namespace(self, statement_name):
        if statement_name is None:
            return None, None
        name_parts = statement_name.split(".")
        if len(name_parts) == 1:
            return None, statement_name
        return ".".join(name_parts[:-1]), name_parts[-1]
    
    def addSymbols(self, symbolWithReasons, symbols, replaceDict, file):
        for symbol, msg, is_add in symbolWithReasons:
            str_symbol_range = str(symbol.range)
            if is_add:
                if not str_symbol_range in replaceDict.keys():
                    symbols.append(symbol)
                    replaceDict[str_symbol_range] = symbol
                    if file and msg: print(f"replace symbol with {msg}: {symbol}", file=file)
            else:
                if str_symbol_range in replaceDict.keys():
                    in_symbol = replaceDict.pop(str_symbol_range)
                    symbols.remove(in_symbol)
                    if file and msg: print(f"replace symbol with {msg}: {symbol}", file=file)
    
    def getSymbbolInOpenRestrict(self, refSymbols, open_namespace):
        symbolWithReasons = []
        if refSymbols is None:
            return symbolWithReasons
        for symbol in refSymbols:
            if symbol.is_private or symbol.range is None or not symbol.prefix_safe:
                continue
            if symbol.src_name == open_namespace:
                symbolWithReasons.append((symbol, "open restriction", True))
        return symbolWithReasons
    
    def getSymbolByNamespace(self, refSymbols, current_namespace, statement_namespace, inRange_namespace, force_symbol_namespaces, open_namespaces):
        symbolWithReasons = []
        if refSymbols is None:
            return symbolWithReasons
        for symbol in refSymbols:
            if symbol.is_private or symbol.range is None or not symbol.prefix_safe:
                continue
            name_namespace, name_statement_name = self.get_statement_name_namespace(symbol.name)
            if name_namespace:
                bprint = False
                if bprint: print(f"name_statement_name: {name_statement_name}, symbol.src_name: {symbol.src_name}, name_namepsace: {name_namespace}")
                if name_statement_name != symbol.src_name:
                    continue
                if bprint: print(f"current_namespace: {current_namespace}, inRange_namespace: {inRange_namespace}, name_namepsace: {name_namespace}")
                if name_namespace in force_symbol_namespaces:
                    symbolWithReasons.append((symbol, "open conflict", True))
                    continue
                if  statement_namespace is None and current_namespace and symbol.name.endswith(current_namespace + "." + symbol.src_name):
                    symbolWithReasons.append((symbol, "statement prefix namespace", True))
                    continue

                if current_namespace is None:
                    continue
                if name_namespace in open_namespaces:
                    continue

                alter_current_namespace = current_namespace if current_namespace else None
                if alter_current_namespace and inRange_namespace:
                    alter_current_namespace = inRange_namespace + "." + alter_current_namespace
                in_current_namespace = (name_namespace == inRange_namespace or inRange_namespace.startswith(name_namespace + ".")) if inRange_namespace else False
                if not in_current_namespace and alter_current_namespace:
                    in_current_namespace = name_namespace == alter_current_namespace
                #if statement_name.endswith("list_chain'") or statement_name.endswith("iterate_eq_of_apply_eq") or statement_name.endswith("star") or statement_name.endswith("support_sum_subset"): 
                #    print(f"current_namespace: {current_namespace}, alter_current_namespace: {alter_current_namespace}, statement_namespace: {statement_namespace}, inRange_namespace: {inRange_namespace}, name_namepsace: {name_namespace}, open_namespaces: {open_namespaces}, in_current_namespace: {in_current_namespace}")

                if not in_current_namespace or in_current_namespace and current_namespace == name_namespace and statement_namespace is None:
                    # only for testing since testing add additional namespace  support_sum_subset
                    symbolWithReasons.append((symbol, "statement in range", True))
        return symbolWithReasons

    def getSymbolByStatement(self, refSymbols, fileRange, statement_name, inRangeNamespaces, stmt, file):
        if refSymbols is None:
            return [], False
        if stmt.name is None:
            return [], False
        
        stmt_name = stmt.name
        stmt_range = stmt.fileRange
        stmt_full_name = stmt.get_full_name()

        private_kinds = ["theorem", "definition", "inductive", "abbrev", "structure", "instance"]
        is_private = stmt.kind in private_kinds and stmt.modifiers and stmt.modifiers.visibility == "private"
        if stmt.modifiers and stmt.modifiers.attrs:
            for attr in stmt.modifiers.attrs:
                if attr.kind == "local":
                    is_private = True
        
        symbolWithReasons = []
        has_stmt_symbol = False
        for symbol in refSymbols:
            if is_private and stmt_range.stop < fileRange.start and (stmt_full_name.endswith(symbol.name) or symbol.src_name == stmt_full_name):
                has_stmt_symbol = True
                if file: print(f"private statement in symbole: stmt_full_name: {stmt_full_name}, symbol.name: {symbol.name} ", file=file)
                   
            if symbol.is_private or symbol.range is None or not symbol.prefix_safe:
                continue
            if symbol.name == stmt_name or symbol.name.endswith("." + stmt_name) or stmt_name == symbol.src_name  or stmt_name.endswith("." + symbol.src_name):
                if file: print(f"replace check stmt_name: {stmt_name}: {symbol}", file=file)
                #if symbol.name == symbol.src_name:
                #    continue 
                #if symbol.src_name == stmt_last_part:
                    #if beforeCurrentStatement and stmt_name == symbol.src_name:
                    #    if file: print(f"replace exclude symbol by beforeCurrentStatement and {stmt_name} == {symbol.src_name}: {symbol}", file=file)
                    #    continue                    
                if symbol.name == symbol.src_name:
                    #inStatements = stmt.name != symbol.src_name and statement_last_part in statement_last_parts
                    #statement_name == symbol.src_name or statement_name.endswith("." + symbol.src_name)
                    if fileRange.start <= stmt_range.start:
                        symbolWithReasons.append((symbol, None, False))
                        if file: print(f" create root symbol: {symbol}", file=file)
                        symbol = LeanSymbolReference("_root_." + symbol.name, symbol.src_name, symbol.range, True)
                    else:
                        if file: print(f"replace exclude symbol name and src_name equals and {fileRange.start} > {stmt_range.start}: {symbol}", file=file)
                        continue
                    
                if statement_name != symbol.src_name and not statement_name.endswith("." + symbol.src_name):
                    name = symbol.name
                    for scopeInfo in inRangeNamespaces:
                        if name.startswith(scopeInfo.name):
                            if name[len(scopeInfo.name) + 1:] == symbol.src_name:
                                name = None
                                break
                    if name is None and fileRange.start > stmt_range.start:
                        if file: print(f"replace exclude symbol in namespace and statement before current: {symbol}", file=file)
                        continue
                #if symbol.name == "MeasureTheory.Lp.simpleFunc.toSimpleFunc_toLp" or symbol.name == "TypeVec.repeatEq" or symbol.name == "Int.sign" or symbol.name == "Int.negSucc_lt_zero": 
                #    print(f"stmt_name: {stmt_name}, symbol: {symbol.name}, statement_name: {statement_name}, statement_namespace: {statement_namespace}, current_namespace: {current_namespace}")
                symbolWithReasons.append((symbol, "statement", True))
        return symbolWithReasons, has_stmt_symbol

    def get_replace_symbols(self, statementSymbol, statement_namespace, statement_name, fileRange, file):
        if statementSymbol is None:
            if file: print(f"statement_name: {statement_name}, statementSymbol is None ", file=file)
            return [], [], []
        
        if statementSymbol.signature_symbols:
            if file: print(f"statement_name: {statement_name}, signature_symbols: {len(statementSymbol.signature_symbols)}", file=file)
            for symbol in statementSymbol.signature_symbols:
                if file: print(f"    name: {symbol.name}, src_name: {symbol.src_name}, is_private: {symbol.is_private}, prefix_safe: {symbol.prefix_safe}, prefix_reason: {symbol.prefix_reason}, range: {symbol.range}", file=file)
        else:
            if file: print(f"statement_name: {statement_name}, statementSymbol.signature_symbols is None ", file=file)
        if statementSymbol.value_symbols:
            if file: print(f"statement_name: {statement_name}, value_symbols: {len(statementSymbol.value_symbols)}", file=file)
            for symbol in statementSymbol.value_symbols:
                if file: print(f"    name: {symbol.name}, src_name: {symbol.src_name}, is_private: {symbol.is_private}, prefix_safe: {symbol.prefix_safe}, prefix_reason: {symbol.prefix_reason}, range: {symbol.range}", file=file)
        else:
            if file: print(f"statement_name: {statement_name}, statementSymbol.value_symbols is None ", file=file)
        inRange_namespace, inRangeNamespaces, outRangeNamespaaces = self.get_scope_info_by_range(fileRange)

        signatureSymbols = []
        signatureReplaceDict = {}
        valueSymbols = []
        valueReplaceDict = {}
        statement_namespace_set = set()
        current_statement = None
        statement_last_parts = []
        for statement in self.statements:
            if statement.fileRange.start == fileRange.start:
                current_statement = statement
            if statement.name:
                name_parts = statement.name.split(".")
                statement_last_part = name_parts[-1] if len(name_parts) > 1 else statement.name
                statement_last_parts.append(statement_last_part)
                name_parts = statement.name.split(".")
                if len(name_parts) > 1:
                    last_ns = name_parts[-2]
                    if not last_ns in statement_namespace_set:
                        statement_namespace_set.add(last_ns)

        bprint = False #current_statement.name.endswith("support_sum_subset")
        force_symbol_namespaces = []
        open_namespaces = []
        for entry in self.module.getContextEntries():
            context = entry.content.rstrip()
            nz_context = self.normalize(context.replace("(", " ( ").replace(")", " ) "))
            if not nz_context.startswith("open "):
                continue

            ns_list_str = nz_context[4:]            
            index = nz_context.find("(")
            if index > 0:
                ns_list_str = ns_list_str[:index]
                open_ns_specs = nz_context[index + 1: -1].strip().split(" ")
                for ns_spec in open_ns_specs:
                    self.addSymbols(self.getSymbbolInOpenRestrict(statementSymbol.signature_symbols, ns_spec.strip()), 
                                    signatureSymbols, signatureReplaceDict, file)
                    self.addSymbols(self.getSymbbolInOpenRestrict(statementSymbol.value_symbols, ns_spec.strip()), 
                                    valueSymbols, valueReplaceDict, file)
            ns_list = ns_list_str.strip().split(" ")
            for ns in ns_list:
                if ns in statement_namespace_set and not ns in force_symbol_namespaces:
                    force_symbol_namespaces.append(ns)
                if ns not in open_namespaces:
                    open_namespaces.append(ns)
        # fail the check case to general . Fail on introduction it does not allow add namespace
        if bprint: print(f"force_symbol_namespaces: {force_symbol_namespaces}")

        current_namespace, _ = self.get_statement_name_namespace(statement_name)
        self.addSymbols(
            self.getSymbolByNamespace(statementSymbol.signature_symbols, current_namespace, statement_namespace, inRange_namespace, force_symbol_namespaces, open_namespaces),
            signatureSymbols, signatureReplaceDict, file)
        self.addSymbols(
            self.getSymbolByNamespace(statementSymbol.value_symbols, current_namespace, statement_namespace, inRange_namespace, force_symbol_namespaces, open_namespaces),
            valueSymbols, valueReplaceDict, file)
       
        private_statements = []
        for stmt in self.statements:
            #if current_namespace and statement_namespace is None:
            #    if not stmt.name.startswith(current_namespace):
            #        continue

            beforeCurrentStatement = False
            if stmt.fileRange.start < fileRange.start:
                beforeCurrentStatement = True

            #for scopeInfo in inRangeNamespaces:
            #    if stmt_name.startswith(scopeInfo.name):
            #        stmt_name = stmt_name[len(scopeInfo.name) + 1:]
            #for scopeInfo in outRangeNamespaaces:
            #    if stmt_name.startswith(scopeInfo.name):
            #        stmt_name = stmt_name[len(scopeInfo.name) + 1:]

            #name_parts = stmt_name.split(".")
            #stmt_last_part = name_parts[-1] if len(name_parts) > 1 else stmt_name
            sigSymbols, sig_has_stmt_symbol = self.getSymbolByStatement(statementSymbol.signature_symbols, fileRange, statement_name, inRangeNamespaces, stmt, file)
            self.addSymbols(sigSymbols, signatureSymbols, signatureReplaceDict, file)

            valSymbols, val_has_stmt_symbol = self.getSymbolByStatement(statementSymbol.value_symbols, fileRange, statement_name, inRangeNamespaces, stmt, file)
            self.addSymbols(valSymbols, valueSymbols, valueReplaceDict, file)
            if sig_has_stmt_symbol or val_has_stmt_symbol:
                private_statements.append(stmt)

        if file: print(f"current_theorem_name: {current_statement.name}, replace_signature_symbols: {len(signatureSymbols)}, replace_value_symbols: {len(valueSymbols)}", file=file)
        return sorted(signatureSymbols, key=lambda x: x.range, reverse=True), sorted(valueSymbols, key=lambda x: x.range, reverse=True), private_statements
    
    def create_local_context(self, texts, fileRange: LeanFileRange, reserveFileRanges: list,namespace: str, file, bprint):

        if file: print(f"scopeInfo check fileRange: {fileRange}", file=file)
        
        ex_texts = []
        last_stop_pos = None
        
        exclude_ranges =[]
        ecllude_namesspaces = []
        block_index = 0
        current_namespaces = []
        for scopeInfo in self.module.getScopeRangeInfos():
            hasStatement = False
            for range in reserveFileRanges:
                if scopeInfo.range.inRange(range):
                    hasStatement = True
            if scopeInfo.kind == "section":
                if not hasStatement:
                    exclude_ranges.append(scopeInfo.range)
                    if file: print(f"add exclude section range: {scopeInfo}", file=file)
                else:
                    block_index += 1
                    ex_texts.append(ContextText(scopeInfo.content, None, scopeInfo.range.start, block_index))
                    end_content = f"end {scopeInfo.name}" if scopeInfo.name else "end"
                    ex_texts.append(ContextText(end_content, None, scopeInfo.range.stop, block_index))
                    if file: print(f"add texts: {scopeInfo.content}, {scopeInfo}", file=file)                                      
            elif scopeInfo.kind == "namespace":
                namespaces = scopeInfo.name.split(".")
                if bprint: print(f"#### hasStatement: {hasStatement}, scopeInfo.name: {scopeInfo.name}, namespace: {namespace}")
                if not hasStatement:
                    exclude_ranges.append(scopeInfo.range)
                    ecllude_namesspaces.append(scopeInfo.name)
                    if file: print(f"add exclude namespace range: {scopeInfo}", file=file)
                else:
                    full_namespace = (".".join(current_namespaces) + ".") if len(current_namespaces) > 0 else "" + scopeInfo.name
                    if bprint: print(f"#### full_namespace: {full_namespace}")
                    #if namespace and namespace.startswith(full_namespace):
                    current_namespaces.extend(namespaces)
                    block_index += 1
                    ex_texts.append(ContextText(f"namespace {scopeInfo.name}", None, scopeInfo.range.start, block_index))
                    ex_texts.append(ContextText(f"end {scopeInfo.name}", None, scopeInfo.range.stop, block_index))
                    if file: print(f"add texts: namespace {namespace}, {scopeInfo}", file=file)


        last_stop_pos = fileRange.stop if last_stop_pos and last_stop_pos < fileRange.stop else fileRange.stop
        exclude_ranges.append(LeanFileRange(last_stop_pos, LeanFilePos(sys.maxsize, sys.maxsize)))
        context_dict = {}
        blocks = []
        for entry in self.module.getContextEntries(): 
            if entry.range.start > last_stop_pos:  
                continue
            invalid_entry = self.inRange(exclude_ranges, entry.range)
            if invalid_entry:
                if file: print(f"exclude variable: {entry.content}, variable.fileRange: {entry.range}, exclude_section_range: {exclude_ranges}", file=file)
                continue
            if entry.kind in ["notation", "notation3", "variable","open", "universe", "set_option", "noncomputable", "include", "custom_macro", "attribute", "in", "mixfix", "alias", "grindPattern", "macro", "macro_rules", "syntax", "prefix"]:
                if entry.kind == "set_option":
                    if "linter.indexVariables" in entry.content or "linter.listVariables" in entry.content: # Lean Internal variable
                        continue
                 
                self.append_ex_texts(ex_texts, blocks, texts, context_dict, entry.range.start, file)

                hasStatement = False
                for range in reserveFileRanges:
                    if entry.range.inRange(range):
                        hasStatement = True

                if entry.kind == "in" and not hasStatement:
                    continue
                context = entry.content.rstrip()
                nz_context = self.normalize(context)
                if entry.kind in ["notation", "notation3", "mixfix", "attribute", "macro", "macro_rules", "syntax", "prefix", "alias", "grindPattern", "custom_macro"]:
                    if not self.isLocalContext(entry):
                        continue

                if nz_context in context_dict:
                    previous_content = context_dict[nz_context]
                    del previous_content

                context_dict[nz_context] = context
                if file: print(f"add entry: {context}, entry.range: {entry.range}", file=file)
                raw_kind = entry.raw_kind if entry.raw_kind else ""
                comment = None #f"context kind: {entry.kind} {raw_kind}"
                texts.append(ContextText(context, comment, entry.range.start))

        self.append_ex_texts(ex_texts, blocks, texts, context_dict, fileRange.start, file)

        post_texts = []
        ex_texts = [ex_text for ex_text in ex_texts if ex_text.blockIndex]
        ex_texts.sort(key=attrgetter("pos"))
        ex_texts.sort(key=attrgetter('blockIndex'), reverse=True) 
        for ex_text in ex_texts:
            if ex_text.pos < fileRange.stop or ex_text.blockIndex is None:
                continue            
            if ex_text.blockIndex in blocks:
                post_texts.append(ex_text)
        
        current_namespace = ".".join(current_namespaces) if len(current_namespaces) > 0 else None
        texts.sort(key=attrgetter("pos"))
        return current_namespace, post_texts
    
    def isLocalContext(self, entry):
        content = entry.content.rstrip()
        nz_content = self.normalize(content)
        if nz_content.startswith("@["):
            index = nz_content.find("]")
            if index > 0:
                nz_content = nz_content[index + 1:].strip()
        if nz_content.startswith("local") or nz_content.startswith("private"): #or nz_context.startswith("scoped") 
            return True
        args = entry.getArguments()
        if args and "local" in args:
            return True
        return False
    
    def inRange(self, ranges, check_range):
        for exclude_range in ranges:
            if exclude_range.inRange(check_range):
                return True
        return False
    
    def append_ex_texts(self, ex_texts, blocks, texts, context_dict, currentPos: LeanFilePos, file):
        i = 0
        for ex_text in ex_texts[:]:
            if ex_text.pos >= currentPos:
                continue
            if ex_text.blockIndex:
                if ex_text.text.startswith("end"):
                    blocks.remove(ex_text.blockIndex) 
                else:
                    blocks.append(ex_text.blockIndex)
            nz_context = self.normalize(ex_text.text)
            if nz_context in context_dict:
                previous_content = context_dict[nz_context]
                del previous_content
                
            context_dict[nz_context] = ex_text
            if file: print(f"add ex_text: {ex_text.text}, ex_text.rangepos: {ex_text.pos}", file=file)
            texts.append(ex_text)
            ex_texts.remove(ex_text)
        
    def create_statement_text(self, statement: Statement, statement_namespace, statement_name: str,file = None):
        statementSymbol = self.module.getStatementSymbol(statement)
        if file: print(f"statement internal_name: {statement.internal_name}, kind: {statement.kind}, theorem name: {statement_name}", file=file)
        signature_symbols, value_symbols, private_statements = self.get_replace_symbols(statementSymbol, statement_namespace, statement_name, statement.fileRange, file=file) 
        
        text = ""
        attrs = self.create_attrs_text(statement.modifiers.attrs)
        if attrs:
            text += attrs.strip() + "\n"
        if statement.modifiers.visibility:
            text += statement.modifiers.visibility.strip() + " "
        if statement.modifiers.compute_kind:
            text += statement.modifiers.compute_kind.strip() + " "
        if statement.modifiers.rec_kind:
            text += statement.modifiers.rec_kind.strip() + " "
        if statement.modifiers.is_unsafe:
            text += "unsafe "
        if statement.modifiers.rec_kind_left:
            text += statement.modifiers.rec_kind_left.strip() + " "
        text += statement.command.strip() + " "
        if statement.modifiers.rec_kind_right:
            text += statement.modifiers.rec_kind_right.strip() + " "
        if statement_name:
            if statement.modifiers is None or  statement.modifiers.visibility != "private":
                text += "LeanTest."
            text += statement_name + " "
        if hasattr(statement, "signature") and statement.signature and statement.signatureRange:
            signature = self.replaceContent("signature", statement.signatureRange, signature_symbols, statement_name, file) + " "
            text += signature
        if hasattr(statement, "value") and statement.value and statement.valueRange:         
            value = self.replaceContent("value", statement.valueRange, value_symbols, statement_name, file).rstrip()
            text += value
        return True, text.strip(), private_statements
    
    
    def replaceSymbolLine(self, line, range, symbol, src_name, replace_name, file):
        parts = symbol.src_name.rsplit(src_name, 1)
        replace_symbol = replace_name.join(parts)
        start_column = range.start.column if range.start.line == symbol.range.start.line else 1
        column_start = symbol.range.start.column - start_column                  
        column_stop = symbol.range.stop.column - start_column
        replace_line = line[:column_start] + replace_symbol + line[column_stop + 1:]
        if file: print(f"replaceContent: symbol {symbol}, range: {range}", file=file)
        return replace_line

    def replaceContent(self, symbolType: str, range: LeanFileRange, replace_symbols, statement_name, file):
        if range is None:
            return None
        leanFile = self.module.getLeanFile()
        content = leanFile.getTextFromLineModule(range)
        lines = content.split("\n")
        for symbol in replace_symbols:
            replace_name = symbol.name
            src_name = symbol.src_name
            if not symbol.prefix_safe:
                if file: print(f"{symbolType} replaceContent skip not prefix_safe, src_name: {src_name}, symbol: {symbol}", file=file)
                continue
            if symbol.range is None or not range.inRange(symbol.range):
                if file: print(f"{symbolType} replaceContent not in range, src_name: {src_name}: range: {range}, symbol: {symbol}", file=file)
                continue
            line_index = symbol.range.start.line - range.start.line
            if src_name is None:
                if file: print(f"{symbolType} replaceContent Fail src_name: {src_name}, replace_name: {replace_name}, symbol: {symbol}", file=file)
                continue
            if src_name == replace_name:
                if file: print(f"{symbolType} replaceContent skip symbol src_name: {src_name}: {symbol}", file=file)
                continue
            if symbol.range.start.line != symbol.range.stop.line:
                if file: print(f"{symbolType} replaceContent Fail line: {symbol.src_name} {symbol.range.start.line}, {symbol.range.stop.line}", file=file)
                continue
            if line_index < 0 or line_index >= len(lines):
                if file: print(f"r{symbolType} eplaceContent Fail line range: {symbol.src_name} {range.start.line}, {symbol.range.start.line}, {len(lines)}", file=file)
                continue
            if symbol.range.stop.column - symbol.range.start.column + 1 != len(symbol.src_name):
                if file: print(f"{symbolType} replaceContent Fail column range: {symbol.src_name} {symbol.range.start.column}, {symbol.range.stop.column}, {len(symbol.src_name)}", file=file)
                continue
            lines[line_index] = self.replaceSymbolLine(lines[line_index], range, symbol, src_name, replace_name, file)
        return leanFile.remove_comment("\n".join(lines))

    def create_attrs_text(self, attrs: list):
        if attrs is None or len(attrs) == 0:
            return None
        text = ""
        for attr in attrs:
            if attr.name == "typevec":
                continue
            if attr.name == "to_additive":
                nz_content = self.normalize(attr.content.replace("(", "( ").replace(":=", " := "))
                if nz_content.startswith("to_additive ( attr := "):
                    continue

                if nz_content == "to_additive":
                    continue

            if len(text) > 0:
                text += ", "
            if attr.kind and attr.kind != "global":
                text += attr.kind.strip() + " "
            text += attr.content.strip()
        if len(text) == 0:
            return None
        return f"@[{text}]"

    def normalize(self, str):
        str = str.replace("\t", " ").replace("\r", " ").replace("\n", " ")
        return " ".join(str.split())
