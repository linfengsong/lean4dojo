
def parse_lean_variable(text):
    text = text.strip()
    if not text.startswith("variable"): return []
    content = text[len("variable"):].strip()

    components = []
    stack = []
    start = 0
    brackets = {'{': '}', '[': ']', '(': ')'}
    
    for i, char in enumerate(content):
        if char in brackets:
            if not stack: start = i
            stack.append(char)
        elif char in brackets.values():
            #if stack and brackets[stack[-1]] == char: # 修正語法小錯誤
            #    pass 
            if stack and brackets[stack[-1]] == char:
                stack.pop()
                if not stack:
                    components.append(content[start:i+1])

    results = set()
    for comp in components:
        inner = comp[1:-1].strip()
        if ':' in inner:
            name_part = inner.split(':')[0].strip()
            names = [n for n in name_part.split() if n]
            for name in names:
                if not name in results:
                    results.add(name)
        else:
            continue
            #names = [inner.split()[-1]]
            #for name in names:
            #    if not name in results:
            #        results.add(name)
            
    return results

def parse_var_decl(info_str):
    content = info_str.replace("variables:", "").strip()
    parts = [p.strip() for p in content.split(',')]
    results = set()
    for part in parts:
        if part not in results:
            results.add(part)
    return results
    #if len(parts) == 1:
    #    print("len")
    #    return [parts[0]]
    #elif len(parts) >= 2:
    #    print(f"len >= 2: {parts}")
    #    return [parts[-1]]
    #else:
    #    return parts

def safe_parse_lean_variable(line):
    # 1. 移除註解與多餘空白
    line = line.split('--')[0].strip()
    if not line.startswith("variable"): return []
    content = line[len("variable"):].strip()

    # 2. 使用堆疊拆分組件 (處理嵌套)
    components = []
    stack = []
    start = 0
    brackets = {'{': '}', '[': ']', '(': ')'}
    
    for i, char in enumerate(content):
        if char in brackets:
            if not stack: start = i
            stack.append(char)
        elif char in brackets.values():
            if stack and brackets[stack[-1]] == char:
                stack.pop()
                if not stack:
                    components.append(content[start:i+1])

    # 3. 從組件中提取變數名
    results = []
    for comp in components:
        inner = comp[1:-1].strip() # 移除最外層括號
        
        # 情況 A: 帶冒號的宣告，如 {α β : Type*} 或 (n : Nat)
        if ':' in inner:
            name_part = inner.split(':')[0].strip()
            # 處理多變數情況，如 α β -> ['α', 'β']
            names = [n for n in name_part.split() if n]
            results.append({"names": names, "full": comp, "type": "var"})
        
        # 情況 B: 匿名實例，如 [LinearOrder α] 或 [Monad m]
        else:
            # 實例通常作用於最後一個識別字
            names = [inner.split()[-1]] 
            results.append({"names": names, "full": comp, "type": "inst"})
            
    return results

def parse_scope_variable2(info_str):
    # 移除前綴 "variables: "
    content = info_str.replace("variables:", "").strip()
    
    # 拆分逗號
    parts = [p.strip() for p in content.split(',')]
    
    # 情況 A: 只有一個元素，如 "α"
    if len(parts) == 1:
        return {"names": [parts[0]], "type": "var"}
    
    # 情況 B: 多個元素，如 "LinearOrder, α"
    # 在 Lean 的實例表示中，最後一個通常是受作用的變數名
    # 而第一個通常是 Typeclass 名稱
    if len(parts) >= 2:
        # 檢查第一個字是否為常見的 Typeclass (Monad, LinearOrder, BEq 等)
        # 或是根據你的需求，將所有 parts 都視為相關變數
        return {
            "names": [parts[-1]],  # 主變數
            "instance": parts[0],  # 實例名稱
            "all_parts": parts,
            "type": "inst" if len(parts) == 2 else "multi-var"
        }
    
    return {"names": parts, "type": "unknown"}

if __name__ == "__main__":

    test_line = "variable {α β : Type*} [LinearOrder α] (f : α → (β ⊕ γ)) [Monad m]"
    parsed = parse_lean_variable(test_line)
    print(f"變數名: {parsed}")
    #for p in parsed:
    #    print(f"變數名: {p['names']}, 完整語法: {p['full']}")

    print("variables: α, β")
    print(parse_var_decl("variables: α, β"))         # {'names': ['β'], ...}
    print("variables: LinearOrder, α")
    print(parse_var_decl("variables: LinearOrder, α")) # {'names': ['α'], 'instance': 'LinearOrder', ...}
