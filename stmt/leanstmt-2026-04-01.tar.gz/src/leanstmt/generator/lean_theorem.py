import logging
from dataclasses import dataclass
from dataclasses_json import dataclass_json
from .lean_file import LeanFileRange
from .lean_statement import Statement
from .lean_elab import TacticProof, find_tactricProof, find_term_node_name

@dataclass_json
@dataclass(frozen=True, eq=False)
class Theorem(Statement):
    name: str

    signature: str
    signatureRange: LeanFileRange

    value: str
    valueRange: LeanFileRange

    proofOperator: str
    proofType: str
    
    tacticProof: TacticProof
    refTacticProofs: list[TacticProof]

    term_before: list

    is_lemma: bool = False

    @property
    def command(self):
        if self.is_lemma:
            return "lemma"
        else:
            return "theorem"
    
    def __post_init__(self):
        header_content = self.get_header_content()
        if " lemma " in " " + header_content:
            object.__setattr__(self, 'is_lemma', True)
        self.setup_visibility(header_content)

    @staticmethod
    def _getToken(line: str, index: int):
        tokens = line.strip().replace("\n", " ").replace("\r", " ").replace("\t", " ").split()
        if index < 0:
            index = len(tokens) + index
        if index >= len(tokens):
            return None
        return tokens[index]

    @classmethod
    def create(cls, decl, content, fileRange, scope_info, modifiers, name, signature, signatureRange, 
                    value, valueRange, tacticProofs, terms):
        proofOperator = Theorem._getToken(value, 0)
        if proofOperator and proofOperator.startswith(":="):
            proofOperator = ":="
        assert(proofOperator == ":=" or proofOperator == "|" or proofOperator == "where")

        proof = value[len(proofOperator):]
        startBy = True
        byToken = Theorem._getToken(proof, 0)
        if byToken is None or byToken != "by":
            startBy = False
    
        tacticProofs = find_tactricProof(valueRange, tacticProofs) if valueRange else None
        term_before = None
        tacticProof = None
        proofType = "Term"
        refTacticProofs =None
        if startBy:
            proofType = "Tactic"
            if len(tacticProofs) > 0:
                tacticProof = tacticProofs.pop(0)
            else:
                # when proof content is only MACRO, it does not have tactic generated in Lean
                # it needs fix
                pure_proof = " ".join(proof.replace("\n"," ").replace("\t"," ").split(" "))
                if " " in pure_proof:
                    logging.info(f"ERROR cannot find tacticProof: {name} theorem_proof: {value}")

        if len(tacticProofs) > 0:
            refTacticProofs = tacticProofs
        if tacticProof is None:
            term = find_term_node_name(fileRange, name, terms)
            if term is not None:
                term_before = term.type
            elif startBy:
                logging.info(f"ERROR tactic_before is none on Tactic: {name}")

        return Theorem(decl, content, fileRange, scope_info, modifiers, name, signature, signatureRange, 
                   value, valueRange, proofOperator,  proofType, tacticProof, refTacticProofs, term_before)

