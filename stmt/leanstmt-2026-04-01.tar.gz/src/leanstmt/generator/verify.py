import subprocess

def verify_lean(root_path, lean_file: str):
    try:
        args = ["lake", "env", "lean", lean_file]
        result = subprocess.run(args, cwd=root_path, text=True, capture_output=True)
        msg = result.stdout
        if result.stderr:
            msg += result.stderr
        return result.returncode, msg
    except Exception as e:
        return 1, f"Exception: Fail to run lean fie: {lean_file}, error: {e}"
