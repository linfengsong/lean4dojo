
class LeanPerfectPrint():
    module_name: str
    imprts: list[str] = None
    opens: list[str] = None
    variables: list[str] = None
    type_kind: str
    name: str
    attrs: list
    signature: str
    value: str

    def __init__(self, 
                 module_name: str,
                 type_kind: str,
                 attrs: list,
                 name: str, 
                 signature: str,
                 value: str = None, 
                 imprts: list[str] = None,
                 opens: list[str] = None,
                 variables: list[str] = None):
        self.module_name = module_name
        self.name = name
        self.type_kind = type_kind
        self.attrs = attrs
        self.signature = signature
        self.value = value
        self.imprts = imprts
        self.opens = opens
        self.variables = variables

    def create_statement_text(self):
        text = ""
        if self.imprts:
            for imprt in self.imprts:
                text += "import " + ".".join(imprt).strip() + "\n"
            text += "import " + self.module_name + "\n"
        if self.opens:
            for open in self.opens:
                text += "open " + open.strip() + "\n"
        if self.variables:
            for variable in self.variables:
                text += variable.strip() + "\n"
        if self.attrs:
            for attr in self.attrs:
                text += attr.strip() + " "
        decl = f"{self.type_kind.strip()} {self.name.strip()} "
        if self.signature:
            decl += f"{self.signature}"
        text += decl
        if self.value:
            text += self.value
        return text
    