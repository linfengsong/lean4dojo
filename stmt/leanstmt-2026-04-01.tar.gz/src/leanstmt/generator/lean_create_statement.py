import sys
from leanstmt.generator.lean_module import LeanModule
from .lean_statement import Statement, Variable
from .lean_file import LeanFileRange, LeanFilePos
from .lean_variable import parse_var_decl, parse_lean_variable

class LeanCreateStatement:
    def __init__(self, module_name: str, module: LeanModule, 
                 variables: list[Variable]):
        self.module_name = module_name
        self.module = module
        self.variables = variables

    def create_lean_text(self, statement: Statement):
        text = ""

        bprint = False #"MeasureTheory.piPremeasure_pi" == statement.name
        if bprint:
            print(f"statement.name: |{statement.name}| {bprint}")

        fileRange = statement.fileRange
        include_scopes =[]
        exclude_namespaces =[]
        exclude_sections =[]
        if bprint:
            print(f"scopeInfo check fileRange: {fileRange}") 
        for scopeInfo in self.module.getScopeRangeInfos():
            if scopeInfo.range.inRange(fileRange):
                include_scopes.append(scopeInfo)
                if bprint:
                    print(f"include scopeInfo: {scopeInfo}")   
            else:
                if scopeInfo.kind == "section":
                    exclude_sections.append(scopeInfo)
                    if bprint:
                        print(f"exclude section scopeInfo: {scopeInfo}")
                else:
                    exclude_namespaces.append(scopeInfo)
                    if bprint:
                        print(f"exclude namespace scopeInfo: {scopeInfo}")
                     
        imprts = self.module.getImports()
        if imprts:
            for imprt in imprts:
                imprt_name = ".".join(imprt).strip() 
                if imprt_name != "Init":
                    text += "import " + imprt_name + "\n"
        # Only need to create own module file for testing
        text += "import " + self.module_name + "\n"

        #for scoped_info in exclude_namespaces:
        #    text += "open " + scoped_info.name.strip() + "\n"

        if statement.scope_info.open_decl:
            for open_decl in statement.scope_info.open_decl:
                text += "open " + open_decl.strip() + "\n"
        if statement.scope_info.scoped_open_decl:
            for scoped_open_decl in statement.scope_info.scoped_open_decl:
                text += "open scoped " + scoped_open_decl.strip() + "\n"

        namespace = statement.scope_info.namespace.strip() if statement.scope_info.namespace else None
        for scoped_info in include_scopes:
            name = scoped_info.name.strip()
            if scoped_info.kind == "namespace" and name != namespace:
                text += scoped_info.kind + " " + name + "\n"
            if bprint:
                print(f"scoped_info.name: {scoped_info}")
        
        if namespace:
            text += "namespace " + namespace + "\n"
            if bprint:
                print(f"statement.scope_info.namespace: {statement.scope_info.namespace}")
    
        if statement.scope_info and statement.scope_info.var_decls:
            text += self.create_variable_text(exclude_sections, 
                    statement.fileRange, statement.scope_info.var_decls) + "\n"
    
        text += self.create_statement_text(statement, namespace).strip() + "\n"
        return text
        
    def create_statement_text(self, statement: Statement, namespace: str,
                              prefix_name: str = "test_"):
        text = ""

        attrs = self.create_attrs_text(statement.modifiers.attrs)
        if attrs:
            text += attrs.strip() + "\n"
        if statement.modifiers.visibility:
            text += statement.modifiers.visibility.strip() + " "
        if statement.modifiers.compute_kind:
            text += statement.modifiers.compute_kind.strip() + " "
        if statement.modifiers.rec_kind:
            text += statement.modifiers.rec_kind.strip() + " "
        if statement.modifiers.is_unsafe:
            text += "unsafe "
        if statement.modifiers.rec_kind_left:
            text += statement.modifiers.rec_kind_left.strip() + " "
        text += statement.command.strip() + " "
        if statement.modifiers.rec_kind_right:
            text += statement.modifiers.rec_kind_right.strip() + " "
        name = statement.name if hasattr(statement, "name") and statement.name else None
        if name:
            if namespace and name.startswith(namespace + "."):
                name = name[len(namespace) + 1:]
            text += prefix_name + name + " "
        if hasattr(statement, "signature") and statement.signature:
            text += statement.signature + " "
        if hasattr(statement, "value") and statement.value:
            text += statement.value.rstrip()
        return text.strip()

    def create_attrs_text(self, attrs: list):
        if attrs is None or len(attrs) == 0:
            return None
        text = ""
        for attr in attrs:
            if len(text) > 0:
                text += ", "
            if attr.kind and attr.kind != "global":
                text += attr.kind.strip() + " "
            text += attr.content.strip()
        return f"@[{text}]"
    
    def create_variable_text(self, include_scopes, fileRange, var_decls: list, bprint=False):    
        text = ""
        #bprint = False
        if bprint:
            print(f"create_variable_text fileRange: {fileRange}")
        exclude_ranges = [ scope.range for scope in include_scopes ]
        exclude_ranges.append(LeanFileRange(fileRange.stop, LeanFilePos(sys.maxsize, sys.maxsize)))
        for variable in self.module.getContextEntries():
            if not variable.kind in ["notation", "variable"]:
                continue
            valid_var = True
            for exclude_range in exclude_ranges:
                if exclude_range.inRange(variable.range):
                    if bprint:
                        print(f"exclude variable: {variable.content}, variable.fileRange: {variable.range}, exclude_section_range: {exclude_range.range}")
                    valid_var = False
                    break
            if valid_var:
                if bprint:
                    print(f"add variable: {variable.content}, variable.fileRange: {variable.range}, exclude_section_range: {exclude_range.range}")
                text += variable.content.rstrip() + "\n"
        return text
    
    def create_variable_text2(self, fileRange, var_decls: list):
        text = ""
        variables = []
        for variable in self.variables:
            if variable.fileRange.stop <= fileRange.start:
                content_vars = parse_lean_variable(variable.content)
                variables.append((variable.content.rstrip(), content_vars))
        for var_decl in var_decls:
            decl_vars, original_text = var_decl.split(" ||| ")
            vars = parse_var_decl(decl_vars)
            breaked = False
            for content, content_vars in reversed(variables):
                if vars == content_vars:
                    text += content + "\n"
                    breaked = True
                    break
            #if not breaked:
            #    for content, content_vars in reversed(variables):
            #        if original_text in content:
            #            text += content + "\n"
            #            breaked = True
            #            break
            if not breaked:
                print(f"NOT find: var_decl: |{var_decl}|, vars: |{vars}|, variables: |{variables}|")
        return text

        #for var_decl in var_decls:
        #     assert var_decl.startswith("variables:")
             #vars = " ".join(var_decl[len("variables:"):].replace(",", "").strip().split())
             #vars = "{ " + vars + " }"
        #     vars = parse_var_decl(var_decl)
        #     print(f"vars: |{vars}|, var_decl: |{var_decl}|")
        #     for variable in reversed(self.variables):
             #   variable_check = variable.content.replace("}", " } ").replace("{", " { ").replace("(", " { ").replace("[", " { ")
             #   variable_check = variable_check.replace(":", " } ").replace(")", " } ").replace("]", " } ").replace("\n", " ").replace("\t", " ")
             #   variable_check = " ".join(variable_check.split())
        #        variable_check = parse_lean_variable(variable.content)
        #        print(f"variable_check: |{variable_check}|, variable_content: |{variable.content}|")
        #        diff = vars - variable_check
        #        if len(diff) > 0:
        #            text += variable.content.strip() + "\n"
        #            vars = vars - diff
        #return text