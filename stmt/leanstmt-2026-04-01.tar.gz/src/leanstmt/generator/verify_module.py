import re
import io

def printStatement(module_name, statement, printID, file):
    
    print(f"name: {module_name} {printID} {statement.command}", file=file)
    print(f"content: {statement.content}", file=file)
    print(f"fileRange: {statement.fileRange} {statement.coreDeclaration.ref.range}", file=file)
    if hasattr(statement, "signature"):
        print(f"signature: {statement.signature}", file=file)
        print(f"signatureRange: {statement.signatureRange} {statement.coreDeclaration.signature.range if statement.coreDeclaration.signature and statement.coreDeclaration.signature.range else None}", file=file)
    if hasattr(statement, "value"):
        print(f"value: {statement.value}", file=file)
        print(f"valueRange: {statement.valueRange} {statement.coreDeclaration.value.range if statement.coreDeclaration.value and statement.coreDeclaration.value.range else None}", file=file)
    
    print(f"scope_info {statement.coreDeclaration.scope_info}", file=file)
    print(f"modifiers {statement.coreDeclaration.modifiers}", file=file)
    if hasattr(statement, "attrs"):
        print(f"attrs: {statement.attrs}", file=file)

def is_invalid_lean_name(name: str) -> bool:
    if not name:
        return False
    if name.startswith('«') and name.endswith('»'):
        return len(name) > 2
    pattern = r"[()\[\]{}⟨⟩,;:+\-*/^%<>≤≥¬∧∨→↔\\\"#@$`~|\s]"
    return bool(re.search(pattern, name))

def validStatement(statement):
    content = statement.content.strip()
    if hasattr(statement, "value") and statement.value:
        value = statement.value.rstrip()
        if content.endswith(value):
            content = content[:-len(value)].rstrip()
        else:
            return f"Value difference: {value}"

    if hasattr(statement, "signature") and statement.signature:
        if content.endswith(statement.signature.strip()):
            content = content[:-len(statement.signature.strip())].rstrip()
        else:
            return f"Signature difference: {statement.signature.strip()}"
    
    if statement.modifiers.attrs and len(statement.modifiers.attrs) > 0:
        attr_match= True
        index_set_start = content.find("@[")
        if index_set_start >= 0:
            content = ", " + content[index_set_start + 2 : ].strip()
            for attr in statement.modifiers.attrs:
                if content.startswith(","):
                    content = content[len(","):].lstrip()
                else:
                    attr_match= False
                    break
                if attr.kind and attr.kind != "global":
                    if content.startswith(attr.kind):
                        content = content[len(attr.kind):].lstrip()
                    else:
                        attr_match= False
                        break
                if content.startswith(attr.content):
                    content = content[len(attr.content):].lstrip()
                else:
                    attr_match= False
                    break
            if content.startswith("]"):
                content = content[len("]"):].lstrip()
            else:
                attr_match= False
            if not attr_match:
                return f"Attrs difference: {statement.modifiers.attrs}, content: {content}"

    if statement.modifiers.visibility:
        if content.startswith(statement.modifiers.visibility):
            content = content[len(statement.modifiers.visibility):].lstrip()

    if statement.modifiers.compute_kind:
        if content.startswith(statement.modifiers.compute_kind):
            content = content[len(statement.modifiers.compute_kind):].lstrip()

    if statement.modifiers.rec_kind:
        if content.startswith(statement.modifiers.rec_kind):
            content = content[len(statement.modifiers.rec_kind):].lstrip()

    if statement.modifiers.is_unsafe and content.startswith("unsafe"):
        content = content[len("unsafe"):].lstrip()

    if statement.modifiers.rec_kind_left:
        if content.startswith(statement.modifiers.rec_kind_left):
            content = content[len(statement.modifiers.rec_kind_left):].lstrip()

    if content.startswith(statement.command):
        content = content[len(statement.command):].lstrip()
    else:
        return f"Command difference: {statement.command}, content: {content}"
    
    if statement.modifiers.rec_kind_right:
        if content.startswith(statement.modifiers.rec_kind_right):
            content = content[len(statement.modifiers.rec_kind_right):].lstrip()
    
    if hasattr(statement, "name") and statement.name:
        name_array = statement.name.split(".")
        namespace = None
        if statement.scope_info.namespace:
            first_name_item = name_array[0]
            namespace = statement.scope_info.namespace
            for item in namespace.split("."):
                if item.startswith("«") and item.endswith("»"):
                    item = item[1:-1]
                if item == first_name_item:
                    break
                else:
                    name_array.insert(0, item)
        name = ".".join(name_array)
        name_content = content.replace("\n", " ").replace("\t", " ")
        name_content = name_content.strip().split(" ")[0]
        if name_content.startswith("_root_."):
            name_content = name_content[len("_root_."):]
        name_content_array = []
        for item in name_content.split("."):
            if item.startswith("«") and item.endswith("»"):
                item = item[1:-1]
            name_content_array.append(item)
        if is_invalid_lean_name(name_content_array[-1]):
            name_content_array = name_content_array[:-1]
        name_content = ".".join(name_content_array)
        if not name.endswith(name_content) :
            return f"Statement name difference, name: {name}, content: {name_content}, statement.name: {statement.name}, namespace: {namespace}, decl.name: {statement.coreDeclaration.name}"
    return None

def verifyModule(project, module_name):
    output = io.StringIO()
    module = project.get_module(module_name)
    if module is None:
        return f"Fail to load module: {module_name}", 1, 1
    count = 0
    diff_count = 0
    for statement in module.getStatements():
        #if statement.kind == "definition": #"classInductive": #"axiom": #"abbrev": #"theorem": #"variable": #"example": #"inductive": #"opaque": #"definition": #"instance": #"structure": 
            count += 1
            diff = validStatement(statement)
            if diff:
                diff_count += 1
                print("====================================================", file=output)
                printID = statement.content
                if hasattr(statement, "name"):
                    printID = statement.name
                print(f"Difference module_name: {module_name}, {printID} {statement.fileRange}", file=output)
                print(diff, file=output)
                printStatement(module_name, statement, printID, file=output)

    return_str = output.getvalue()
    return return_str, count, diff_count