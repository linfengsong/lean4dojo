#!/usr/bin/env python3
"""
将 Lean 内核导出文件 (.export) 转换为 JSON Lines 格式。

用法:
    python export2jsonl.py mathlib.export output.jsonl

依赖:
    - 已安装 Lean 4 (v4.18.0 或兼容版本) 且 `lean` 命令在 PATH 中
    - 导出文件必须与当前 Lean 版本匹配
"""

import subprocess
import sys
import os
import tempfile
import json

def main():
    if len(sys.argv) != 3:
        print("用法: python export2jsonl.py <export_file> <output_jsonl>")
        sys.exit(1)

    export_file = sys.argv[1]
    output_file = sys.argv[2]

    # 检查 lean 是否可用
    try:
        subprocess.run(["lean", "--version"], check=True, capture_output=True)
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("错误: 未找到 lean 命令，请确保 Lean 4 已安装并在 PATH 中。")
        sys.exit(1)

    # 创建临时目录，用于存放提取器源码
    with tempfile.TemporaryDirectory() as tmpdir:
        extractor_path = os.path.join(tmpdir, "Extractor.lean")
        with open(extractor_path, "w") as f:
            f.write("""
import Lean
import Lean.Data.Json

open Lean

def getConstantJson (env : Environment) (name : Name) (decl : ConstantInfo) : Json :=
  let type := toString (← inferType (mkConst name))
  let kind :=
    if decl.isTheorem then "theorem"
    else if decl.isDef then "definition"
    else if decl.isInductive then "inductive"
    else if decl.isStructure then "structure"
    else if decl.isClass then "class"
    else "other"
  let value? := match decl with
    | ConstantInfo.thmInfo info => info.value?.map toString
    | ConstantInfo.defnInfo info => info.value?.map toString
    | _ => none
  Json.mkObj [
    ("name", Json.str name.toString),
    ("type", Json.str type),
    ("kind", Json.str kind),
    ("value", match value? with | some v => Json.str v | none => Json.null)
  ]

def main : IO Unit := do
  let args ← IO.getArgs
  if args.size < 1 then
    IO.println "Usage: extractor <exportFile>"
    return
  let exportFile := args[0]!
  let env ← Lean.Environment.fromExport exportFile
  for (name, decl) in env.constants.toList do
    let json := getConstantJson env name decl
    IO.println (Json.compress json)

#eval main
""")

        # 编译并运行提取器
        try:
            # 编译 extractor.lean
            subprocess.run(
                ["lean", extractor_path, "-o", os.path.join(tmpdir, "extractor")],
                check=True,
                capture_output=True,
                text=True
            )
            # 运行 extractor，传入导出文件路径
            result = subprocess.run(
                [os.path.join(tmpdir, "extractor"), export_file],
                check=True,
                capture_output=True,
                text=True
            )
        except subprocess.CalledProcessError as e:
            print("提取器运行失败:")
            print(e.stderr)
            sys.exit(1)

        # 将结果写入输出文件
        with open(output_file, "w") as f:
            f.write(result.stdout)

    print(f"成功导出 {output_file}")

if __name__ == "__main__":
    main()