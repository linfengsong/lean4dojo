from typing import Optional
from pathlib import Path
import concurrent.futures
from concurrent.futures.thread import ThreadPoolExecutor
import subprocess
from tqdm import tqdm
import logging
from .abstruct_project import AbstructProject

class AbstructExtract(AbstructProject):
    root_path: Path
    common_args: list
    max_workers: Optional[int]

    def __init__(self, 
                 root_dir: str,
                 common_args: list, 
                 max_workers: int = None,
                 all_lean_src_paths = None):
        super().__init__(root_dir, all_lean_src_paths)
        self.root_path = Path(root_dir).resolve()
        self.common_args = common_args
        self.max_workers = max_workers

    def execute_tasks(self, search_list):
        pass
    
    def execute_args(self, module_name: str, args):
        return args

    def run_build(self,
            file: str,
            module_name: str,
            args,
        ) -> Optional[subprocess.CompletedProcess]:
        lake_args = ["lake", "env"]
        lake_args.extend(self.common_args)
        args = self.execute_args(module_name, args)
        if args is None:
            return
        if len(args) > 0:
            lake_args.extend(args)
        lake_args.append(str(Path(file).resolve()))
        logging.debug(f"Running args: {lake_args}")
        return subprocess.run(lake_args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=self.root_path, text=True)

    def batch_build(self,
            search_list: Optional[list],
            args: list) -> list:
        tasks = self.execute_tasks(search_list)
        ret = []
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {
                executor.submit(
                    self.run_build,
                    file=self._path_of_module(m_name, b_dir),
                    module_name=m_name,
                    args=args,
                ): m_name
                for m_name, b_dir in tasks
            }

            with tqdm(total=len(futures), desc=f"Extract {','.join(search_list[:2])}", unit="file") as pbar:
                for f in concurrent.futures.as_completed(futures):
                    m = futures[f]
                    try:
                        r = f.result()
                        if r is not None:
                            msg = r.stdout.strip()
                            if len(msg) > 0:
                                logging.debug(msg)
                            if r.returncode != 0:
                                pbar.write(f"Error in {m}: {r.stderr.strip()}")
                                ret.append((m, r))
                                logging.error(r.stderr.strip())
                    except Exception as e:
                        pbar.write(f"Exception in {m}: {e}")
                        er = subprocess.CompletedProcess(f"Request file: {f}", -1, "", f"Exception in {m}: {e}")
                        ret.append((m, er))
                        logging.error(f"Request file: {f}, Exception in {m}: {e}")
                    pbar.update(1)
        return ret


