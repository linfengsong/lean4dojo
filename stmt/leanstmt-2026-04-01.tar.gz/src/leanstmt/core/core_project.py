import logging
from dataclasses import dataclass
import msgspec
from pathlib import Path
from .core_datasets import CoreModuleInfo,CoreLocalContextInfo,CoreSymbol,CoreDeclaration,CoreLineModel,CoreInfoTree
from .abstruct_project import AbstructProject

@dataclass
class CoreModule:
    lean_file: str
    moduleInfo: CoreModuleInfo
    localContext: CoreLocalContextInfo
    symbols: list[CoreSymbol]
    decls: list[CoreDeclaration]
    lines: list[CoreLineModel]
    infoTrees: list[CoreInfoTree] 

@dataclass
class CoreProject(AbstructProject):
    json_dir: str = None

    def __init__(self, root_dir: str, json_dir: str):
        super().__init__(root_dir)
        self.json_dir = json_dir

    def fetch_module(self, module_name):
        module = self._load_info(module_name, "mod", CoreModuleInfo)
        if module is None:
            return None
        symbols = self._load_info(module_name, "sym", list[CoreSymbol])
        decls = self._load_info(module_name, "decl", list[CoreDeclaration])
        localContext = self._load_info(module_name, "ctx", CoreLocalContextInfo)
        lines = self._load_info(module_name, "line", list[CoreLineModel])
        infoTrees = self._load_info(module_name, "elab", list[CoreInfoTree])
        lean_path = self.get_module_lean_path(module_name)
        if lean_path is None:
            logging.info(f"Fail to fetch module: {module_name} from file: {lean_path}")
            return None
        if symbols is None or decls is None or lines is None or infoTrees is None:
            return None
        return CoreModule(str(lean_path), module, localContext, symbols, decls, lines, infoTrees)

    def _load_info(self, module_name, type, objType):
        filename = f"{module_name}.{type}.json"
        file_path = Path(self.root_dir) / Path(self.json_dir) / Path(filename)
        if not file_path.exists():
            logging.info(f"Fail to fetch module: {module_name} from file: {file_path}")
            return None
        with file_path.open(encoding='utf-8') as fp:
            raw_json = fp.read()
            return msgspec.json.decode(raw_json, type=objType)
