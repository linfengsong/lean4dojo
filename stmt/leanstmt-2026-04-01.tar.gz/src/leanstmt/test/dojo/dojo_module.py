import os
import json

from .datasets import FilePos, FileRange, Tactic, TacticProof, Theorem, Module

def create_file_range(start_line, start_column, stop_line, stop_colum):
    start = FilePos(int(start_line), int(start_column)) if start_line and start_column else None
    stop = FilePos(int(stop_line), int(stop_colum)) if stop_line and stop_colum else None
    return FileRange(start, stop) if start and stop else None

def create_tactic(tacticData, output):
    tactic = tacticData.get("tactic")
    tactic_before = tacticData.get("tactic_before")
    tactic_after = tacticData.get("tactic_after")
    startData = tacticData.get("tactic_start")
    if startData:
        start_line = startData.get("line")
        start_column = startData.get("column")
    stopData = tacticData.get("tactic_stop")
    if stopData:
        stop_line = stopData.get("line")
        stop_column = stopData.get("column")

    fileRange = create_file_range(start_line, start_column, stop_line, stop_column)
    return Tactic(
        fileRange=fileRange,
        pp=tactic,
        before=[tactic_before],
        after=[tactic_after] if tactic_after != "no goals" else []
    )

def create_theorem(name, data, output):
    if data.get("module") != name:
        print(f"Module {name} jsonl line does not have module name: {data}", file=output)
        return
    theorem = data.get("theorem")
    theorem_proof = data.get("theorem_proof")
    startData = data.get("start")
    if startData:
        start_line = startData.get("line")
        start_column = startData.get("column")
    stopData = data.get("stop")
    if stopData:
        stop_line = stopData.get("line")
        stop_column = stopData.get("column")
    tacticsData = data.get("tactics")
    fileRange = create_file_range(start_line, start_column, stop_line, stop_column)
    tacticProof = TacticProof()
    if tacticsData:
        for tacticData in tacticsData:
           tactic = create_tactic(tacticData, output)
           if tactic:
               tacticProof.append_tactic(tactic)
    if len(tacticProof.tactics) == 0:
        tacticProof = None
    return Theorem(
        fileRange=fileRange,
        name=theorem,
        signature=None,
        signatureFileRange=None,
        proofOperator=":=",
        proof=theorem_proof,
        proofType="Tactic",
        proofFileRange=None,
        tacticProof=tacticProof,
        refTacticProofs=None,
        term_before=None)


def create_dojo_module(working_dir, jsonl_dir, module_name, output):
    theorems = []
    file_path = os.path.join(working_dir, jsonl_dir, module_name + ".jsonl")
    if not os.path.exists(file_path):
        print(f"Module {module_name} jsonl file does not exist at: {file_path}", file=output)
        return None
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line != "":
                data = json.loads(line)
                theorem = create_theorem(module_name, data, output)
                if theorem:
                    theorems.append(theorem)

    return Module(module_name, theorems)
