import sys
from typing import Self
from dataclasses import dataclass, field
from dataclasses_json import dataclass_json
from ...core.core_datasets import CoreStringRange, CoreLineModel

@dataclass_json
@dataclass(frozen=True, order=True)
class FilePos:
    line: int
    column: int

@dataclass_json
@dataclass(frozen=True)
class FileRange:
    start: FilePos
    stop: FilePos

    @classmethod
    def fromStringRange(cls, lines: list[CoreLineModel], stringRange: CoreStringRange):
        start = FilePos(1, 1)
        stop = FilePos(len(lines) + 1, 1)
        if stringRange is not None:
            if stringRange.start is not None:
                start = cls.createFilePos(lines, int(stringRange.start))
            if stringRange.stop is not None:
                stop  = cls.createFilePos(lines, int(stringRange.stop))
        return FileRange(start, stop)
    
    @classmethod
    def createFilePos(cls, lines: list[CoreLineModel], bytePos: int):
        if len(lines) == 0:
            return FilePos(1, 1)
        start = 0
        lineNum = 1
        for index, line in enumerate(lines):
            if line.start > bytePos:
                break
            start = line.start
            lineNum = index + 1
        if lineNum > len(lines):
            lineNum = len(lines)
            bytePos = sys.maxsize
        
        textline = lines[lineNum - 1].line
        if textline is None:
            lineNum = lineNum -1
            bytePos = sys.maxsize
            textline = lines[lineNum - 1].line
        encoded_bytes = textline.encode("utf-8")[:bytePos - start]
        text = encoded_bytes.decode("utf-8")
        column = len(text) + 1
        return FilePos(lineNum, column)
    
    def __lt__(self, other):
        return self.start < other.start or self.start == other.start and self.stop >= other.stop
    
    def inRange(self, fileRange):
        return self.start <= fileRange.start and fileRange.stop <= self.stop

@dataclass_json
@dataclass(frozen=True, eq=False)
class Term:
    fileRange: FileRange
    ident: str
    type: str  


@dataclass_json
@dataclass(frozen=True, eq=False)
class Tactic:
    fileRange: FileRange
    pp: str   
    before: list[str]
    after: list[str]
    children: list[str] = field(default_factory=list)
    kind: list[str] = None

    def __eq__(self, other):
        return self.fileRange == other.fileRange and \
               self.pp == other.pp and \
               self.before == other.before and \
               self.after == other.after
    
    def append_child(self, tactic: Self):
        if tactic is None:
            return
        for item in self.children:
            if item.fileRange.inRange(tactic.fileRange):
                item.append_child(tactic)
                return
        #self.children.append(tactic)

@dataclass_json
@dataclass(frozen=True, eq=False)
class TacticProof:

    tactics: list[Tactic] = field(default_factory=list)

    def fileRange(self):
        assert len(self.tactics) > 0
        return FileRange(self.tactics[0].fileRange.start, self.tactics[-1].fileRange.stop)

    def __str__(self):
        children_len = None
        if self.tactics is not None:
            children_len = len(self.tactics)
        return f"children={children_len}"
    
    def __eq__(self, other):
        assert len(self.tactics) > 0
        if self.tactics is not None and other.tactics is not None and \
           self.len(self.tactics) == self.len(other.fileRange):
            return self.tactics[0].before == other.tactics[0].before and \
                   self.tactics[-1].after == other.tactics[-1].after
        elif self.tactics is None and other.tactics is None:
            return True
        else:
            return False
        
    def __lt__(self, other):
        return self.fileRange() < other.fileRange()
    
    def append_tactic(self, tactic: Tactic):
        if tactic is None:
            return
        for item in self.tactics:
            if item.fileRange.inRange(tactic.fileRange):
                item.append_child(tactic)
                return
        self.tactics.append(tactic)


@dataclass_json
@dataclass(frozen=True, eq=False)
class Theorem:
    fileRange: FileRange
    name: str
    
    signature: str
    signatureFileRange: FileRange

    proofOperator: str

    proof: str
    proofFileRange: FileRange
    proofType: str
    
    tacticProof: TacticProof
    refTacticProofs: list[TacticProof]

    term_before: list

    def __str__(self):
        return f"range={self.fileRange}, name={self.name}, type={self.proofType}, proofTactic: {self.tacticProof}"
    
    def __eq__(self, other):
        return self.name == self.name and \
               self.fileRange == other.fileRange and \
               self.proofOperator == other.proofOperator and \
               self.tacticProof == other.tacticProof

@dataclass_json
@dataclass(frozen=True, eq=False)
class Module:
    name: str
    theorems: list[Theorem]

    def __eq__(self, other):
        return self.module == other.module and self.theorems == other.theorems 
