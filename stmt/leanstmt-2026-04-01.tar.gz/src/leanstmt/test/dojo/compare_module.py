import io
import os
import logging
import difflib
from datetime import datetime
from typing import Any
from dataclasses import dataclass
from dataclasses_json import dataclass_json
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm
from ...core.core_project import CoreProject
from .lean_module import create_core_module
from .dojo_module import create_dojo_module


@dataclass_json
@dataclass
class Diff:
    module: str = None
    theorem: str = None
    tactic: int = None
    name: str = None
    old: str = None
    new: str = None
    detail_old: str = None
    detail_new: str = None

def normalize_string(val: str):
    val = " ".join(val.strip().split())
    val = val.replace("{ ", "{").replace(" }", "}").replace("(", "").replace(")", "") #.replace("( ", "(").replace(" )", ")")
    val = val.replace("\n", " ").replace("\r", " ").replace("\t", " ")
    val = val.replace("¬", "¬ ").replace("«", " ").replace("≫", " ").replace("·", "· ").strip()
    val = " ".join(val.split())
    if val.endswith(";"):
        val = val[:-1]
    return val

def normalize_list(list: list[str]):
    if list is None:
        return None
    return [normalize_string(item) for item in list]

def alter_tactics(proofFileRange, tactics1, tactics2):
    # kind is exact, Dojo remove exact tactic in some case. How to do does not clear
    if len(tactics1) <=1 and len(tactics2) <= 1:
        return (tactics1, tactics2)
    last_tactic2 = tactics2[-1]
    if last_tactic2.kind == "Lean.Parser.Tactic.exact":
        #below logic does not work and it looks bug in DOJO
        #previous_tactic2 = tactics2[-2]
        #tactics2 = tactics2[:len(tactics2) - 2]
        #fileRange = FileRange(previous_tactic2.fileRange.start, last_tactic2.fileRange.stop)
        #tactic = Tactic(fileRange, 
        #                previous_tactic2.pp, 
        #                previous_tactic2.before,
        #                last_tactic2.after,
        #                kind=previous_tactic2.kind)
        tactics1 = tactics2

    # Dojo has bug to put some signature tactic data. remove those wrong tactic first
    alter_tactics1 = []
    for tactic in tactics1:
        if proofFileRange.inRange(tactic.fileRange):
            alter_tactics1.append(tactic)
    tactics1 = alter_tactics1

    if len(tactics2) > len(tactics1):
        # Dojo has issue to remove start tactic line with "rw[" automatically according how it
        # load elab and get tactic. this is fundamental problem in Dojo
        diff = len(tactics2) - len(tactics1)
        removeNum = 0
        for tactic in tactics2[:diff]:
            pp = normalize_string(tactic.pp)
            if pp.startswith("rw [") or pp.startswith("rw["):
                removeNum += 1
                break
        if removeNum > 0:
            tactics2 = tactics2[removeNum:]

    if len(tactics2) > len(tactics1):
        # Dojo has issue to remove first tactic like: simp only [Nat.sub_zero]
        # try to compare rest of them same to treat ok
        diff = len(tactics2) - len(tactics1)
        tactics2 = tactics2[diff:]

    if len(tactics1) > len(tactics2):
        # Dojo will make excutor step as tactic and it might have multiple "no goal".
        # Remove no goal which duplicate.
        after2 = tactics2[-1].after
        if len(after2) == 0:
            tactics1 = tactics1[:len(tactics2) - len(tactics1)]
    return (tactics1, tactics2)

def get_string_diff(s1, s2):
    s = difflib.SequenceMatcher(None, s1, s2)
    diffs = []
    for tag, i1, i2, j1, j2 in s.get_opcodes():
        if tag == 'insert':
            diffs.append(s2[j1:j2])
        elif tag == 'replace':
            diffs.append(s2[j1:j2])
    return diffs
    
def compare_tactic_before(before1, before2):
    str_before1 = "\n\n".join(before1) if before1 and len(before1) > 0 else ""
    str_before2 = "\n\n".join(before2) if before2 and len(before2) > 0 else ""

    str_before1 = normalize_string(str_before1)
    str_before2 = normalize_string(str_before2)
    if str_before1 == str_before2:
        return False

    # DOJO add Eq.mp automatically in statement and that does not right since no enough information to describe
    if not " Eq.mp" in str_before1:
        return False

    #Dojo will add additional type in statement to give entire types when some statement type is hidden
    diff_list = get_string_diff(str_before2, str_before1)
    if len(diff_list) > 0:
        if not str_before2.startswith(diff_list[0]) and not str_before2.endswith(diff_list[-1]):
            return False
        return True
    return False

def compare_tactic_after(after1, after2):
    str_after1 = "\n\n".join(after1) if after1 and len(after1) > 0 else "no goals"
    str_after2 = "\n\n".join(after2) if after2 and len(after2) > 0 else "no goals"
    str_after1 = normalize_string(str_after1)
    str_after2 = normalize_string(str_after2)
    if str_after2 == str_after2:
        return False
    
    #Dojo will add additional type in statement to give entire types when some statement type is hidden
    diff_list = get_string_diff(str_after2, str_after1)
    if len(diff_list) > 0:
        if not str_after2.startswith(diff_list[0]) and not str_after2.endswith(diff_list[-1]):
            return False
        return True
    return False

def compare_tactic(index, tactic1, tactic2):
    if tactic1.fileRange != tactic2.fileRange:
        return Diff(tactic=index, name="tactic.fileRange",old=tactic1.fileRange, new=tactic2.fileRange, detail_old=tactic1, detail_new=tactic2)
    if normalize_string(tactic1.pp) != normalize_string(tactic2.pp):
        return Diff(tactic=index, name="tactic.pp", old=tactic1.pp, new=tactic2.pp, detail_old=tactic1, detail_new=tactic2)
    if compare_tactic_before(tactic1.before, tactic2.before):
        return Diff(tactic=index, name="tactic.before", old=tactic1.before, new=tactic2.before, detail_old=tactic1, detail_new=tactic2)
    if compare_tactic_after(tactic1.after, tactic2.after):
        return Diff(tactic=index, name="tactic.after", old=tactic1.after, new=tactic2.after, detail_old=tactic1, detail_new=tactic2)
    return None

def check_proof_tactics(tactics):
    after = None
    pp = ""
    for tactic in tactics:
        if after:
            if tactic.before:
                for goal in tactic.before:
                    if goal in after:
                        after.remove(goal)
                    else:
                        return False
        else:
            after = []
        for goal in tactic.after:
            after.append(goal)
        if tactic.pp:
            pp = tactic.pp

    pp = normalize_string(pp)
    kind = tactics[-1].kind if tactics[-1].kind else None
    # when last step do MACRO apply, it might not have [] at after
    return len(after) == 0 or \
        kind == "Lean.Parser.Tactic.apply" or \
        kind == "Lean.Parser.Tactic.tacticHaveI__" or \
        kind == "Lean.Parser.Tactic.tacticLet__" or \
        kind == "Lean.Parser.Tactic.tacticLetI__"or \
        pp.startswith("refine") and pp.endswith(" ?_")

def compare_theorem(theorem1, theorem2, compare_level, detail_level):
    if theorem1.name != theorem2.name:
        return Diff(theorem=theorem1.name, name="theorem.name", old=theorem1.name, new=theorem2.name, detail_old=theorem1, detail_new=theorem2)
    # Dojo only give theorem range from theorem name without other prefix portion
    if theorem1.fileRange.start < theorem2.fileRange.start or theorem1.fileRange.stop != theorem2.fileRange.stop:
        return Diff(theorem=theorem1.name, name="theorem.fileRange", old=theorem1.fileRange.start, new=theorem2.fileRange.start, detail_old=theorem1, detail_new=theorem2)
    if theorem1.proofOperator != theorem2.proofOperator:
        return Diff(theorem=theorem1.name, name="proofOperator", old=theorem1.proofOperator, new=theorem2.proofOperator, detail_old=theorem1, detail_new=theorem2)
    if theorem1.proof == "None":
        return None # bug in Dojo 
    if get_string_diff(normalize_string(theorem2.proof), normalize_string(theorem1.proof)):
        return Diff(theorem=theorem1.name, name="proof", old=theorem1.proof, new=theorem2.proof, detail_old=theorem1, detail_new=theorem2)
    if compare_level == 1:
        return None
    if theorem1.tacticProof is None and theorem2.tacticProof is None:
        return None
    diff = None
    if theorem1.tacticProof is None:
        return None
    if theorem2.tacticProof is None:
        diff = Diff(theorem=theorem1.name, name="tacticProof", old= theorem1.tacticProof, new=theorem2.tacticProof, detail_old=theorem1.tacticProof, detail_new=theorem2.tacticProof)
    if diff is None:
        tactics1, tactics2 = alter_tactics(theorem2.proofFileRange, theorem1.tacticProof.tactics, theorem2.tacticProof.tactics)
        if len(tactics1) != len(tactics2):
            diff = Diff(theorem=theorem1.name, name="tacticProof.tactics", old=len(tactics1), new=len(tactics2), detail_old=tactics1, detail_new=tactics2)
        if diff is None:
            for i, tactic1 in enumerate(tactics1):
                tactic2 = tactics2[i]
                diff = compare_tactic(i, tactic1, tactic2)
                if diff:
                    break
        if diff:
            # When lean tactics is invalid and ignore difference
            if check_proof_tactics(theorem2.tacticProof.tactics):
                diff = None
    if diff:
        diff.theorem = theorem1.name
        if detail_level == 2:
            diff.detail_old = theorem1
            diff.detail_new = theorem2
        return diff
        
def compare_module(module1, module2, compare_level, detail_level):
    if module1.name != module2.name:
        return Diff(module=module1.name, name="module.name",old=module1.name, new=module2.name, detail_old=module1, detail_new=module2)
    if compare_level == 0:
        return None

    #MACRO will add and rename theorem in Declaration.lean. It need fix before enable below codes
    #if len(module1.theorems) != len(module2.theorems):
    #    dojo_theorems = [ theorem.name for theorem in module1.theorems]
    #    lean_theorems = [ f"{theorem.name},{theorem.proofType}" for theorem in module2.theorems]
    #    return Diff(module=module1.name, name="theorems", old=len(module1.theorems), new=len(module2.theorems), detail_old=dojo_theorems, detail_new=lean_theorems)

    theorem2_dict = {}
    for theorem in module2.theorems:
        theorem2_dict[theorem.name] = theorem
    count = 0
    for theorem1 in module1.theorems:
        theorem2 = theorem2_dict.get(theorem1.name)
        if theorem2 is None:
            # MACRO in Declaration.lean will change theorem name. Ignore for now until fix load Declaration
            continue
            #return Diff(module=module1.name, name="theorem.name",  old=theorem1.name, detail_old=theorem1)
        count = count + 1
        diff = compare_theorem(theorem1, theorem2, compare_level, detail_level)
        if diff:
            diff.module=module1.name
            if detail_level == 3:
                diff.detail_old = module1
                diff.detail_new = module2
            return diff, count
    return None, count
    
def compare_module_worker(coreProject, module_name, compare_level, detail_level):
    output = io.StringIO()
    logging.info(f"module name: {module_name}", file=output)
    try:
        coreModule = create_core_module(coreProject, module_name, output)
    except Exception as e:
        return f"EXCEPTION: Fail to load core module: {module_name} - {e}\n", 1, 1
    try:
        dojoModule = create_dojo_module(coreProject.root_dir, ".dojo", module_name, output)
    except Exception as e:
        return f"EXCEPTION: Fail to load dojo module: {module_name} - {e}\n", 1, 1
    
    count = 0
    try:
        logging.debug(f"load module data: {module_name}")
        count += 1
        diff_count = 0
        if coreModule is None and dojoModule is None:
            logging.info(f"No diff both Module is none {module_name}")
            return f"No diff both Module is none {module_name}", count, 1
        if coreModule is None and dojoModule or coreModule and dojoModule is None:
            diff = Diff(module=module_name, name="module.name", old=dojoModule, new=coreModule)
        else:
            diff, c_count = compare_module(dojoModule, coreModule, compare_level, detail_level)
            count += c_count - 1
            if diff and detail_level == 0:
                diff.detail_old=None
                diff.detail_new=None
        if diff is not None:
            if prefect:        
                str = diff.to_json(indent=2, ensure_ascii=False)
            else:
                str = f"{diff.to_json(ensure_ascii=False)}"
            diff_count = 1
            print(f"diff: {str}", file=output)
        return_str = output.getvalue()
        logging.debug(f"finish module data: {module_name} {len(return_str)}")
        return return_str, count, diff_count
    except Exception as e:
        logging.info(f"EXCEPTION: Fail to compare module: {module_name} - {e}")
        return f"EXCEPTION: Fail to compare module: {module_name} - {e}\n", count, 1

def main(working_dir: str, search_list: list, exclude_list: list = None, compare_level: int = 2, detail_level: int = 0, prefect: bool = False):

    coreProject = CoreProject(working_dir, ".jixia")

    module_locations = coreProject.find_module_locations(search_list)

    max_workers = os.cpu_count()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_name = f"diff_dojo_{timestamp}.log"
    log_path = os.path.join(working_dir, ".logs", file_name)

    with open(log_path, "w", encoding="utf-8") as f:
        f.write(f"\n{'='*80}\nComparing start: working_dir: {working_dir}, compare_level: {compare_level}, detail_level: {detail_level}, search_list: {search_list}\n")
        f.flush()

        total_count = 0
        total_diffs = 0
        with ProcessPoolExecutor(max_workers=max_workers) as executor:
            futures = {
                executor.submit(compare_module_worker, coreProject, module_name, compare_level, detail_level): module_name
                for module_name in module_locations.keys() if not module_name in exclude_list
            }
            for future in tqdm(as_completed(futures), total=len(futures), desc="Comparing Modules"):
                try:
                    result_str, count, diff_count = future.result()
                except Exception as e:
                    print(f"子進程出錯: {e}")
                if result_str and len(result_str) > 0:
                    f.write(result_str)
                    f.flush()
                total_count += count
                total_diffs += diff_count
        f.write(f"\n{'='*80}\nTotal Differences Found: {total_diffs} on {total_count}\n")
        
        print(f"Task finished. Total Difference: {total_diffs} on {total_count}, Detail logs at: {log_path}")

if __name__ == "__main__":
    working_dir = "/home/linfe/math/lean_test"
    compare_level = 2
    prefect=False
    detail_level=0

    exclude_list = ["Init.WF", "Mathlib.Data.Prod.Basic"]
    
    search_list = [
            "Init.Try",
            "Init.Data.Cast",
            "Mathlib.MeasureTheory.SetAlgebra",
            "Mathlib.MeasureTheory.PiSystem",
            "Mathlib.MeasureTheory.Constructions.SubmoduleQuotient",
            "Mathlib.MeasureTheory.Constructions.Projective",
            "Mathlib.MeasureTheory.OuterMeasure.Basic",
            "Mathlib.MeasureTheory.Function.AEEqFun",
            "Mathlib.MeasureTheory.Constructions.BorelSpace.Basic",
            "Mathlib.MeasureTheory.Function.AEEqFun.DomAct",
            "Mathlib.Tactic.Hint",
            "Mathlib.GroupTheory.GroupAction.Primitive",
            "Mathlib.Order.DirectedInverseSystem",
            "Mathlib.CategoryTheory.Limits.HasLimits",
            "Mathlib.Util.Export",
            "Mathlib.Util.MemoFix",
            "Mathlib.Algebra.Category.CommAlgCat.Monoidal",
            "Mathlib.CategoryTheory.Limits.HasLimits",
            "Mathlib.Topology.ContinuousMap.Bounded.Normed"
            "Mathlib.Tactic.Widget.LibraryRewrite",
            "Mathlib.Tactic.Widget.Calc",
            "Mathlib.Data.Nat.Init",
        ]
    
    search_list = ["Init","Mathlib","LeanTest"]
    #compare_level = 1
    #search_list = ["Init"]
    #search_list = ["Mathlib.MeasureTheory"]
    #search_list = ["Mathlib.Data"]
    #search_list = ["Mathlib.Analysis"]
    #prefect=True
    #detail_level=2
    #search_list = ["Mathlib.Data.Nat.Init"]
    #search_list = ["Mathlib.MeasureTheory.Constructions.BorelSpace.Basic"]
    #search_list = ["Mathlib.MeasureTheory.PiSystem"]
    #search_list = ["Mathlib.MeasureTheory.OuterMeasure.Basic"]
    #search_list = ["Mathlib.MeasureTheory.Constructions.Pi"]
    #search_list = ["Mathlib.MeasureTheory.Constructions.Polish.Basic"]
    #search_list = ["Init.Data.RArray"]
    #search_list = ["Init.GetElem"]
    #search_list = ["Init.Data.Option.Array"]
    #search_list = ["Init.Data.Vector.Extract"]
    #search_list = ["Init.Data.Nat.Power2"]
    #search_list = ["Init.Data.Array.Lemmas"]
    # search_list = ["Mathlib.MeasureTheory.Constructions.HaarToSphere"] 
    #search_list = ["Mathlib.MeasureTheory.Function.SpecialFunctions.Inner"]
    #search_list = ["Mathlib.MeasureTheory.Measure.GiryMonad"]
    #search_list = ["Mathlib.MeasureTheory.Measure.Dirac"]
    #search_list = ["Mathlib.Analysis.Calculus.ContDiff.FTaylorSeries"]
    #search_list = ["Mathlib.Analysis.NormedSpace.Alternating.Uncurry.Fin"]
    #search_list = ["Mathlib.RingTheory.TensorProduct.Basic"]
    #search_list = ["Mathlib.Topology.Order.LeftRightNhds"]
    #search_list = ["Mathlib.RingTheory.RingHom.Locally"]
    #search_list = ["Mathlib.LinearAlgebra.Dimension.Localization"]
    #search_list = ["Mathlib.LinearAlgebra.CliffordAlgebra.Even"]

    # MeasureTheory.Measure.pi_def is not theorem with tactic or missing from Dojo
   

    main(working_dir, search_list, exclude_list, compare_level, detail_level, prefect)

    # python -m leanstmt.test.dojo.compare_module