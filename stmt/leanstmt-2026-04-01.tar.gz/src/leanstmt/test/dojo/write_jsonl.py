import json
import os
import io
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from tqdm import tqdm
from ...core.core_project import CoreProject
from ..jixia.util import collect_match_modules
from .datasets import Module
from .lean_module import create_core_module

def get_pos_dict(pos):
    return {"line": pos.line, "column": pos.column}

def create_tacitic_data(tactic):
    state_before = "\n\n".join(tactic.before)
    tactic_str = tactic.pp
    if len(tactic.after) == 0:
        state_after = "no goals"
    else:
        state_after = "\n\n".join(tactic.after)
    tactic_start = tactic.fileRange.start
    tactic_end = tactic.fileRange.stop

    tactic_data = {
        "tactic": tactic_str,
        "tactic_before": state_before,
        "tactic_after": state_after,
        "tactic_start": get_pos_dict(tactic_start),
        "tactic_stop": get_pos_dict(tactic_end)
    }
    return tactic_data

def create_rootTacitic_data(rootTactic):
    children = []
    for tactic in rootTactic.children:
        tactic_data = create_tacitic_data(tactic)
        children.append(tactic_data)
    root_tactic_data = create_tacitic_data(rootTactic)
    root_tactic_data["tactics"] = children
    return root_tactic_data

def write_module_jsonl_file(module: Module, operatorSet):
    lines = []
    name = module.name
    for theorem in module.theorems:
        theorem_name = theorem.name
        theorem_signature = theorem.signature
        theorem_operator = theorem.proofOperator
        theorem_proof = theorem.proof
        theorem_proofFileRange = theorem.proofFileRange
        theorem_proofType = theorem.proofType
        tactic_before = theorem.tactic_before
        tactic_after = theorem.tactic_after
        start = theorem_proofFileRange.start
        end = theorem_proofFileRange.stop

        rootTactic_list = []
        for rootTactic in theorem.tactics:
            rootTactic_data = create_rootTacitic_data(rootTactic)
            rootTactic_list.append(rootTactic_data)

        if tactic_after is None or len(tactic_after) == 0:
            tactic_after = "no goals"

        data = {
            "module": name,
            "theorem": theorem_name,
            "teorem_signature:": theorem_signature,
            "theorem_operator": theorem_operator,
            "theorem_proof": theorem_proof,
            "theorem_proofType": theorem_proofType,
            "tactic_before:": tactic_before,
            "tactic_after": tactic_after,
            "start": get_pos_dict(start),
            "stop": get_pos_dict(end)
        }

        if theorem.proofTactic is not None:
            data["tactics"] = create_rootTacitic_data(theorem.proofTactic)
        if len(rootTactic_list) > 0:
            data["ref_tactics"] = rootTactic_list
        lines.append(json.dumps(data, ensure_ascii=False))
        if theorem_operator in operatorSet:
            count =  operatorSet[theorem_operator] + 1
        else:
            count = 1
        operatorSet[theorem_operator] = count
    return lines

def process_single_file(file_info):
    output = io.StringIO()
    operatorSet = {":=": 0}
    path, project, module_name = file_info
    try:
        module = create_core_module(project, module_name, output)
        lines = write_module_jsonl_file(module, operatorSet)
        with open(path, 'w', encoding='utf-8') as fd:
            fd.write('\n'.join(lines) + '\n')
            fd.flush
        return (output.getvalue(), operatorSet)
    except Exception as e:
        print(f"Exception: module: {module_name}, message: {str(e)}", file=output)
        return (output.getvalue(), operatorSet)
    
def run_parallel_extraction(tasks, f, max_workers: int =os.cpu_count()):
    results = []
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(process_single_file, task): task for task in tasks
        }
        for future in tqdm(as_completed(futures), total=len(futures), desc="Build proof of Modules"):
            result_str, operatorSet = future.result()
            if result_str:
                f.write(result_str)
                f.flush()
            results.append(operatorSet)
    return results

def process_searches(working_dir: str, search_list: list[str], exclude_list: list[str]):
    output_dir = working_dir + "/.jixiaw"
    log_path = working_dir + "/jixiaw.log"
    json_dir = ".jixia"
    os.makedirs(output_dir, exist_ok=True)
    project = CoreProject(working_dir, json_dir)
    modules = []
    for search in search_list:
        modules.extend(collect_match_modules(project, search, exclude_list))

    tasks = []
    for module_name in modules:
        module_str = ".".join(module_name)
        path = f"{output_dir}/{module_str}.jsonl"
        tasks.append((path, project, module_name))

    with open(log_path, "w", encoding="utf-8") as f:
        operatorSet = {":=": 0}
        operatorSets = run_parallel_extraction(tasks, f)
        for relOprSet in operatorSets:
            for key in relOprSet.keys():
                value = operatorSet[key] if key in operatorSet.keys() else 0
                value += relOprSet[key]
                operatorSet[key] = value

        print(f"Theorem Operator Set: {operatorSet}", file=f)
        print(f"Theorem Operator Set: {operatorSet}")

def main():
    parser = argparse.ArgumentParser(description="Python Code Implementation Helper for Project Comparison")
    parser.add_argument("--working_dir", type=str, default="/home/linfe/math/lean_test", help="Target working directory")
    parser.add_argument("--search_list", type=str, default="", help="Comma separated modules to search (e.g. 'Init,Mathlib')")
    parser.add_argument("--exclude_list", type=str, default="", help="Comma separated modules to exclude")

    args = parser.parse_args()

    search_list = [s.strip() for s in args.search_list.split(",") if s.strip()]
    if len(search_list) == 0:
        search_list = [
            "Init",
            "Mathlib",
            "LeanTest" # need replace by lean project configuration
        ]
    elif len(search_list) == 1 and search_list[0] == "TEST":
        search_list = [
            "Mathlib.Analysis.CStarAlgebra.ContinuousFunctionalCalculus.Unitary"
            "Mathlib.Topology.Algebra.Order.LiminfLimsup",
            "Init.Grind.Ordered.Field",
            "Mathlib.MeasureTheory.Measure.Real",
            "Mathlib.Data.List.InsertIdx",
            "Mathlib.Analysis.Analytic.IteratedFDeriv"
            "Mathlib.MeasureTheory.PiSystem",
            "Mathlib.Analysis.Calculus.ContDiff.FTaylorSeries",
            "Mathlib.MeasureTheory.Measure.Support",
            "Mathlib.RingTheory.Kaehler.Polynomial",
            "Mathlib.Algebra.Category.CommAlgCat.Monoidal",
            "Mathlib.MeasureTheory.Constructions.BorelSpace.Order",
            "Mathlib.Tactic.CC.Addition",
            "Mathlib.LinearAlgebra.Dual.Lemmas",
            "Mathlib.LinearAlgebra.QuadraticForm",
            "Mathlib.LinearAlgebra.Basis.Submodule"
            "Mathlib.GroupTheory.GroupAction.MultipleTransitivity"
            "Mathlib.RingTheory.TensorProduct.Basic"
        ]

    exclude_list = [e.strip() for e in args.exclude_list.split(",") if e.strip()]

    process_searches(args.working_dir, search_list, exclude_list)

if __name__ == "__main__":
    main()

    # python -m leanstmt.test.dojo.write_jsonl --search_list TEST
