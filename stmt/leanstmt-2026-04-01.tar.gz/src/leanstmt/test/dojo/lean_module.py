import re
import logging
from ...core.core_datasets import CoreLineModel, CoreDeclaration, CoreStringRange, CoreInfoTree, CoreLineModel
from ..jixia.util import getLeanSourceDirOrFile
from .datasets import FileRange, Term, Tactic, TacticProof, Theorem, Module

class LineModel():
    start: int
    line: str

    def __init__(self, start: int, line: str):
        self.start = start
        self.line = line

def remove_comment(text: str):
    if text is None:
        return text
    text = re.sub(r"/-.*?-/", "", text, flags=re.DOTALL)
    return re.sub(r'--[^\n]*', '', text)
    #lines = []
    #for line in text.split("\n"):
    #    parts = line.split("--")
    #    lines.append(parts[0])
    #return "\n".join(lines)
    #text = re.sub(r"/-[\s\S]*", "", text)
    ##lines = []
    ##for line in text.split("\n"):
    ##    parts = line.split("/-")
    ##    lines.append(parts[0])
    ##text = "\n".join(lines)
    #return re.sub(r"^\s*$\n?", "", text, flags=re.M)

def createTactic(ref, tactic, strkind, lines, parentRange, fileRangeset):
    range = ref.range if ref.range else parentRange
    fileRange = FileRange.fromStringRange(lines, range)
    if fileRange in fileRangeset:
        return None
    fileRangeset.add(fileRange)
    beforeGoals = []
    for goal in tactic.before:
        beforeGoals.append(goal.pp)
    afterGoals = []
    for goal in tactic.after:
        afterGoals.append(goal.pp)
    #pp = remove_comment(ref.pp)
    pp = remove_comment(getTextFromLineModule(lines, fileRange))
    return Tactic(fileRange, pp, beforeGoals, afterGoals, kind=strkind)

def collect_tactcis(nodes, lines: list, tacticProof: TacticProof, parentRange, includeSeq, fileRangeset, bPrint, level):
    for node in nodes:
        strkind = ".".join([str(v) for v in node.ref.kind]) if node.ref and node.ref.kind else ""
        if bPrint:
            print(f"strkind: {level} {strkind} {includeSeq} {node.ref.pp}")
        if strkind == "Lean.Parser.Term.byTactic":
            #before = node.info.tactic.before if node.info and node.info.tactic else ""
            #if before == "":
            #    before = node.info.term.before if node.info and node.info.term else ""
            #after = node.info.tactic.after if node.info and node.info.tactic else ""
            #if after == "":
            #    after = node.info.term.after if node.info and node.info.term else ""
            #print(f"byTactic: pp: {node.ref.pp}, before: {before}, after: {after}")
            return
        elif "Lean.cdot" in strkind:
            tactic = createTactic(node.ref, node.info.tactic, strkind, lines, parentRange, fileRangeset)
            if tactic:         
                tacticProof.append_tactic(tactic)
        elif "Congr!.congr!" in strkind:
            tactic = createTactic(node.ref, node.info.tactic, strkind, lines, parentRange, fileRangeset)
            if tactic:         
                tacticProof.append_tactic(tactic)
        elif node.info and node.info.tactic and node.ref.kind:
            if strkind != "by" \
               and strkind != ";" \
               and "tactic" in strkind.lower() \
               and (not "Lean.Parser.Tactic.tacticSeq" in strkind or includeSeq)\
               and strkind != "Lean.Parser.Tactic.tactic_<;>_" \
               and strkind != "Lean.Parser.Tactic.skip" \
               or strkind.startswith("Mathlib.Meta."):
                #and strkind != "Lean.Parser.Tactic.allGoals":
                #and strkind != "Lean.Parser.Tactic.withAnnotateState" \
                #and strkind != "Lean.Parser.Tactic.focus" \
                tactic = createTactic(node.ref, node.info.tactic, strkind, lines, parentRange, fileRangeset)
                if tactic:         
                    tacticProof.append_tactic(tactic)
                    if bPrint:
                        print(f"strkind: {level}, {includeSeq}, {strkind} {tactic.pp} {parentRange} {node.ref.range}")
            #if strkind == "Lean.Parser.Tactic.Conv.conv":
            #    return
        if node.children:
            childIncludeSeq = False if "Lean.Parser.Tactic.tacticSeq" in strkind else includeSeq
            if strkind != "Lean.Parser.Tactic.tactic_<;>_":
                childIncludeSeq = False
            childFileRange = node.ref.range if node.ref.range else parentRange
            collect_tactcis(node.children, lines, tacticProof, childFileRange, childIncludeSeq, fileRangeset, bPrint, level+1)

def collect_all_tacticProofs(nodes: list, lines: list):
    tacticProofs = []
    for node in nodes:
        strkind = ".".join([str(v) for v in node.ref.kind]) if node.ref and node.ref.kind else ""
        if node.info and node.info.tactic:
            if strkind == "Lean.Parser.Term.byTactic":
                tacticProof = TacticProof()
                bPrint = False
                # from .datasets import FilePos
                #proofFileRange = FileRange(FilePos(209, 68),FilePos(222, 38))
                #if node.ref and node.ref.range:
                #    fileRange = FileRange.fromStringRange(lines, node.ref.range)
                #    if proofFileRange.inRange(fileRange) and node.info.tactic:
                #        bPrint = True

                collect_tactcis(node.children, lines, tacticProof, node.ref.range, False, set(), bPrint, 0)
                if bPrint:
                    print(f"tacticProof: {tacticProof}, {len(tacticProof.tactics)}")
                if len(tacticProof.tactics) > 0:
                    tacticProofs.append(tacticProof)
                return tacticProofs
        elif node.children:
            tacticProofs.extend(collect_all_tacticProofs(node.children, lines))
        
    return tacticProofs

def find_tactricProof(fileRange: FileRange, tacticProofs: list[TacticProof]):
    inRangeTacticProofs = []
    for tacticProof in tacticProofs:
        proofFileRange = tacticProof.fileRange()
        if proofFileRange and fileRange.inRange(proofFileRange):
            inRangeTacticProofs.append(tacticProof)
    return inRangeTacticProofs

def collect_all_terms(nodes: list, lines: list, module_name):
    terms = []
    for node in nodes:
        if node.info and node.info.term and node.ref.kind == ["ident"] and node.info.term.expected_type is None:
            fileRange = FileRange.fromStringRange(lines, node.ref.range)
            term = Term(fileRange, node.info.term.value, node.info.term.type)
            terms.append(term)
        elif node.children:
            terms.extend(collect_all_terms(node.children, lines, module_name))
    return terms

def find_term(fileRange: FileRange, ident: str, terms: list[Term]):
    if fileRange is None:
        return None
    for term in terms:
        if term and term.fileRange and fileRange.inRange(term.fileRange) and term.ident == ident:
            return term
    return None

def find_all_terms(nodes: list, pp: str):
    founds = []
    for node in nodes:
        if node.ref and pp in node.ref.pp:
            item = {
                "node": node, 
                "children": []
            }
            founds.append(item)
        if node.children:
            sub_founds = find_all_terms(node.children, pp)
            if len(sub_founds) > 0:
                item = {
                    "node": node, 
                    "children": sub_founds
                }
                founds.append(item)
    return founds

def extractLine(line: str, start: int, stop: int = -1):
    buf = bytes(line, encoding='utf-8')
    if stop == -1:
        stop = len(buf)
    buf = buf[start : stop]
    return buf.decode('utf-8')

def getTextFromLineModule(lines: list[CoreLineModel], fileRange: FileRange):
    start_line = fileRange.start.line - 1
    stop_line = fileRange.stop.line - 1
    start_col = fileRange.start.column - 1
    stop_col = fileRange.stop.column
    if start_line < 0 or stop_line >= len(lines):
        return ""
    if start_line == stop_line:
        content = lines[start_line].line or ""
        return content[start_col:stop_col]
    result = []
    first_line = lines[start_line].line or ""
    result.append(first_line[start_col:])
    for i in range(start_line + 1, stop_line):
        result.append(lines[i].line or "")
    last_line = lines[stop_line].line or ""
    result.append(last_line[:stop_col])
    return "".join(result)
    
    #textLines = lines[fileRange.start.line - 1].line[fileRange.start.column - 1:]
    #if fileRange.start.line < fileRange.stop.line - 1:
    #    for i in range(fileRange.start.line, fileRange.stop.line - 1):
    #        if lines[i].line:
    #            textLines = textLines + lines[i].line 
    #if fileRange.start.line < fileRange.stop.line and fileRange.stop.line - 1 < len(lines):
    #    if lines[fileRange.stop.line - 1].line:
    #        textLines = textLines + lines[fileRange.stop.line - 1].line[:fileRange.stop.column]
    #return textLines

def getLeanSourceCode(project, module_name: list[str], fileRange: FileRange):
    file_path = getLeanSourceDirOrFile(project, module_name, True)
    if file_path is None:
        raise "Cannot find module_name: {module_name}"

    with open(file_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        target_lines = lines[fileRange.start.line - 1 : fileRange.stop.line]
        if not target_lines:
            return ""
        if len(target_lines) == 1:
            return extractLine(target_lines[0], fileRange.start.column -1, fileRange.stop.column)
        else:
            target_lines[0] = extractLine(target_lines[0], fileRange.start.column - 1)
            target_lines[-1] = extractLine(target_lines[-1], 0, fileRange.stop.column)
            return "".join(target_lines)

def getToken(line: str, index: int):
    tokens = line.strip().replace("\n", " ").replace("\r", " ").replace("\t", " ").split()
    if index < 0:
        index = len(tokens) + index
    if index >= len(tokens):
        return None
    return tokens[index]

def getTheoremName(module_name: list[str], decl: CoreDeclaration):
    #first item is "_private" if it's a private declaration, we need to remove the prefix and get the real name
    # for example, if the declaration name is ["_private", "Init", "Nat", "add"], and the module name is ["Init", "Nat"], we need to remove the prefix and get the real name "add"  
    if decl.name is None or len(decl.name) == 0:
        return None
    if decl.name[0] != '_private':
        return ".".join(decl.name)
    module_name_array = module_name.split(".")
    private_name = decl.name[len(module_name_array) + 2:]
    return ".".join(private_name)

# =============================
# Extract Theorems
# =============================
def extract_theorem_signature_proof(project, module_name, lines, signature_start, theorem_stop):
    fileRange = FileRange.fromStringRange(lines, CoreStringRange(signature_start, theorem_stop))
    text = getLeanSourceCode(project, module_name, fileRange)
    text = text.replace("\t", " ").replace("\n", " ").replace("\r", " ")
    buf = bytes(text, encoding='utf-8')
    match = re.search(bytes(" := ", encoding='utf-8'), buf)
    if match is None:
        return None, None
    match_start = signature_start + match.start()
    signature_range = CoreStringRange(signature_start, match_start)
    proof_range = CoreStringRange(match_start + 1, theorem_stop)
    signature_fileRange = FileRange.fromStringRange(lines, signature_range)
    proof_fileRange = FileRange.fromStringRange(lines, proof_range)
    return signature_fileRange, proof_fileRange

def extract_theorems(project, module_name, output):
    module = project.fetch_module(module_name)
    if module is None:
        return []
    declarations:list[CoreDeclaration] = module.decls
    infoTrees: list[CoreInfoTree] = module.infoTrees
    corelines: list[CoreLineModel] = module.lines
    lines = []
    length = len(corelines)
    with open(module.lean_file, 'r', encoding='utf-8') as file:
        for i, content in enumerate(file, start=0):
            if i < length:
                lines.append(LineModel(corelines[i].start, content))
    assert(len(lines) > 0)
    tacticProofs = collect_all_tacticProofs(infoTrees, lines)
    terms = collect_all_terms(infoTrees, lines, module_name)
    theorems = []
    for _, decl in enumerate(declarations):
        if decl.kind == "theorem":
            if len(decl.name) == 0:
                continue
            theorem = extract_theorem(module_name, decl, lines, tacticProofs, terms, output)
            if theorem is not None and theorem.proofOperator == ":=" and theorem.proofType == "Tactic":
                theorems.append(theorem)
    return theorems

def extract_theorem(module_name, decl, lines, tacticProofs, terms, output):
    theorem_name = getTheoremName(module_name, decl)
    theorem_range = FileRange.fromStringRange(lines, decl.ref.range)
    signatureRange = FileRange.fromStringRange(lines, decl.signature.range)
    theorem_proofRange = FileRange.fromStringRange(lines, decl.value.range)
    if theorem_range == theorem_proofRange:
        # when statement has MACRO, Declarration.lean already process STX by MACRO produced statement
        statement = remove_comment(decl.value.pp)
        signature = remove_comment(decl.signature.pp)
        theorem = remove_comment(getTextFromLineModule(lines, theorem_range))
        #if "irreducible_def" in theorem:
            #DOJO does not extract irreducible_def as Theorem
        #    return None
        return None
    else:
        statement = remove_comment(getTextFromLineModule(lines, theorem_proofRange))
        signature = remove_comment(getTextFromLineModule(lines, signatureRange))
    tacticProofs = find_tactricProof(theorem_proofRange, tacticProofs)

    proofOperator = getToken(statement, 0)
    if proofOperator.startswith(":="):
        proofOperator = ":="
    if proofOperator != ":=" and proofOperator != "|" and proofOperator != "where":
        print(f"proofOperator {proofOperator}  is not valid, remove: {theorem_name} {module_name}", file=output)
        return None

    if statement is None:
        print(f"no proof, remove: {theorem_name} {module_name}", file=output)
        return None
    if proofOperator is None:
        print(f"no proofOperator, remove: {theorem_name} {module_name}", file=output)
        return None
    
    statement = statement.rstrip()[len(proofOperator) + 1:].lstrip()
    startBy = True
    byToken = getToken(statement, 0)
    if byToken is None or byToken != "by":
        startBy = False

    theorem_proof = statement
    term_before = None
    tacticProof = None
    proofType = "Term"
    refTacticProofs =None
    if startBy:
        proofType = "Tactic"
        if len(tacticProofs) > 0:
            tacticProof = tacticProofs.pop(0)
        else:
            # when proof content is only MACRO, it does not have tactic generated in Lean
            # it needs fix
            pure_proof = " ".join(theorem_proof.replace("\n"," ").replace("\t"," ").split(" "))
            if " " in pure_proof:
                logging.info(f"ERROR cannot find tacticProof: {theorem_name} {module_name}, theorem_proof: {theorem_proof}")
                return None
    if len(tacticProofs) > 0:
        refTacticProofs = tacticProofs
    if tacticProof is None:
        name_array = theorem_name.split(".")
        term = None
        while term is None and len(name_array) > 0:
            search_name = ".".join(name_array)
            term = find_term(theorem_range, search_name, terms)
            if term is None and not search_name.startswith("@"):
                search_name = "@" + search_name
                term = find_term(theorem_range, search_name, terms)
            name_array.pop(0)
        if term is None:
            search_name = "_root_." + theorem_name
            term = find_term(theorem_range, search_name, terms)
            if term is None:
                search_name = "@" + search_name
                term = find_term(theorem_range, search_name, terms)
        if term is None:
            search_name = "«" + theorem_name.split('.')[-1] + "»"
            term = find_term(theorem_range, search_name, terms)
            if term is None:
                search_name = "@" + search_name
                term = find_term(theorem_range, search_name, terms)

        if term is not None:
            term_before = term.type
        elif startBy:
            logging.info(f"ERROR tactic_before is none on Tactic: {theorem_name} {module_name}")
        else:
            if decl.name[0] != '_private':
                logging.info(f"tactic_before is none, remove: {theorem_name} {module_name}")
            return None

    return Theorem(theorem_range, theorem_name, signature, signatureRange, proofOperator, theorem_proof, theorem_proofRange, proofType, tacticProof, refTacticProofs, term_before)

def create_core_module(project, module_name, output):
    theorems = extract_theorems(project, module_name, output)
    return Module(module_name, theorems)
