from dataclasses import dataclass
import logging
from ...core.core_project import CoreProject
from .datasets import ModuleData,SymbolData,DeclarationData,InfoTreeData,ModuleTreeData,ProjectData,to_lean_ident

@dataclass
class LeanProjectData(ProjectData):
    working_dir: str
    json_dir: str = ".jixia"

    def loadModuleTree(self, module_name, raise_exception: bool = True):
        project = CoreProject(self.working_dir, self.json_dir)
        module = project.fetch_module(module_name)
        if module is None:
            return None
        moduleInfo = module.moduleInfo
        symbols = module.symbols
        decls = module.decls
        infoTrees = module.infoTrees

        try:
            no_macor_decls = []
            for decl in decls:
                if "_aux_" in to_lean_ident(decl.name) and "___macroRules_" in to_lean_ident(decl.name):
                    pass #print(f"Jixia remove macro decl: {decl.name}")
                elif "_aux_" in to_lean_ident(decl.name) and "___elabRules_" in to_lean_ident(decl.name):
                    pass
                elif "_aux_" in to_lean_ident(decl.name) and "__delab_" in to_lean_ident(decl.name):
                    pass
                elif "_aux_" in to_lean_ident(decl.name) and "___unexpand_" in to_lean_ident(decl.name):
                    pass #print(f"Lean remove macro decl: {decl.name}")
                elif "._@." in to_lean_ident(decl.name) and "._hyg." in to_lean_ident(decl.name):
                    pass
                elif "inst" in to_lean_ident(decl.name) and decl.ref is not None and decl.ref.original == False:
                    pass
                else:
                    no_macor_decls.append(decl)

            mooduleTreeData = ModuleTreeData(
                ModuleData.create(moduleInfo),
                [SymbolData.create(symbol) for symbol in symbols],
                [DeclarationData.create(decl) for decl in no_macor_decls],
                [InfoTreeData.create(infoTree) for infoTree in infoTrees]
            )

            return mooduleTreeData
        except Exception as e:
            if raise_exception:
                raise Exception(f"Lean Fail to load json for {module_name}: {e}")
            else:
                logging.info(f"Lean Fail to load json for {module_name}: {e}")
                return None
