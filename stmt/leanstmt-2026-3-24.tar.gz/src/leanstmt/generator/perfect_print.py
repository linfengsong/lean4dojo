
class LeanPerfectPrint():
    imprts: list[str] = None
    opens: list[str] = None
    variables: list[str] = None
    type_kind: str
    name: str
    attrs: list
    signature: str
    operator: str
    value: str

    def __init__(self, 
                 type_kind: str,
                 attrs: list,
                 name: str, 
                 signature: str,
                 operator: str = None,
                 value: str = None, 
                 imprts: list[str] = None,
                 opens: list[str] = None,
                 variables: list[str] = None):
        self.name = name
        self.type_kind = type_kind
        self.attrs = attrs
        self.signature = signature
        self.operator = operator
        self.value = value
        self.imprts = imprts
        self.opens = opens
        self.variables = variables

    def printLines(self):
        lines = []
        if self.imprts:
            for imprt in self.imprts:
                lines.append("import " + ".".join(imprt).strip())
        if self.opens:
            for open in self.opens:
                lines.append("open " + open.strip())
        if self.variables:
            for variable in self.variables:
                lines.append(variable.strip())
        if self.attrs:
            for attr in self.attrs:
                lines.append(attr.strip())
        decl = f"{self.type_kind.strip()} {self.name.strip()} {self.signature.rstrip()}"
        if self.operator:
            decl += " " + self.operator
        lines.append(decl)
        if self.value:
            valueLines = self.value.split("\n")
            for valueLine in valueLines:
                if valueLine:
                    valueLine = valueLine.rstrip()
                    lines.append(f"  {valueLine}")
        return lines
    