import sys
import re
from typing import Optional
from dataclasses import dataclass, field
from dataclasses_json import dataclass_json
from ..core.core_datasets import CoreStringRange, CoreLineModel

@dataclass_json
@dataclass(frozen=True, order=True)
class LeanFilePos:
    line: int
    column: int

    @classmethod
    def createFilePos(cls, lines: list[CoreLineModel], bytePos: int):
        if len(lines) == 0:
            return cls(1, 1)
        start = 0
        lineNum = 1
        for index, line in enumerate(lines):
            if line.start > bytePos:
                break
            start = line.start
            lineNum = index + 1
        if lineNum > len(lines):
            lineNum = len(lines)
            bytePos = sys.maxsize
        textline = lines[lineNum - 1].line
        if textline is None:
            lineNum = lineNum -1
            bytePos = sys.maxsize
            textline = lines[lineNum - 1].line
        encoded_bytes = textline.encode("utf-8")[:bytePos - start]
        text = encoded_bytes.decode("utf-8")
        column = len(text) + 1
        return cls(lineNum, column)

@dataclass_json
@dataclass(frozen=True)
class LeanFileRange:
    start: LeanFilePos
    stop: LeanFilePos
    
    def __lt__(self, other):
        return self.start < other.start or self.start == other.start and self.stop >= other.stop
    
    def inRange(self, fileRange):
        return self.start <= fileRange.start and fileRange.stop <= self.stop


class LeanLineModel():
    """An Line node with line information"""
    start: int
    line: str

    def __init__(self, start: int, line: str):
        self.start = start
        self.line = line


class LeanFile():
    """An Lean node with lean file information"""
    file: str
    lines: list[LeanLineModel]

    def __init__(self, file: str, lineModels: list[CoreLineModel]):
        self.file = file
        lines = []
        length = len(lineModels)
        with open(file, 'r', encoding='utf-8') as file:
            for i, content in enumerate(file, start=0):
                if i < length:
                    lines.append(LeanLineModel(lineModels[i].start, content))
        assert(len(lines) > 0)
        self.lines = lines

    def createFileRange(self, stringRange: CoreStringRange):
        lines = self.lines
        start = LeanFilePos(1, 1)
        stop = LeanFilePos(len(lines) + 1, 1)
        if stringRange is not None:
            if stringRange.start is not None:
                start = LeanFilePos.createFilePos(lines, int(stringRange.start))
            if stringRange.stop is not None:
                stop  = LeanFilePos.createFilePos(lines, int(stringRange.stop))
        return LeanFileRange(start, stop)
    

    def getTextFromLineModule(self, fileRange: LeanFileRange):
        start_line = fileRange.start.line - 1
        stop_line = fileRange.stop.line - 1
        start_col = fileRange.start.column - 1
        stop_col = fileRange.stop.column
        if start_line < 0 or stop_line >= len(self.lines):
            return ""
        if start_line == stop_line:
            content = self.lines[start_line].line or ""
            return content[start_col:stop_col]
        result = []
        first_line = self.lines[start_line].line or ""
        result.append(first_line[start_col:])
        for i in range(start_line + 1, stop_line):
            result.append(self.lines[i].line or "")
        last_line = self.lines[stop_line].line or ""
        result.append(last_line[:stop_col])
        return "".join(result)

    def remove_comment(self, text: str):
        if text is None:
            return text
        text = re.sub(r"/-.*?-/", "", text, flags=re.DOTALL)
        return re.sub(r'--[^\n]*', '', text)
