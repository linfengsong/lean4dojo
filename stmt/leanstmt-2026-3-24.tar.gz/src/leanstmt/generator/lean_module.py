from ..core.core_project import CoreModule
from ..core.core_datasets import CoreDeclaration, CoreInfoTree
from .lean_theorem import extract_theorem
from .lean_file import LeanFile, LeanFileRange
from .lean_elab import collect_all_terms, collect_all_tacticProofs

class Variable:
    coreDeclaration: CoreDeclaration

    content: str
    fileRange: LeanFileRange

    def __init__(self, coreDeclaration: CoreDeclaration, content: str, fileRange: LeanFileRange):
        self.coreDeclaration = coreDeclaration
        self.content = content
        self.fileRange = fileRange

class LeanModule:
    name: str
    coreModule: CoreModule

    def __init__(self, name: str, coreModule: CoreModule):
        self.name = name
        self.coreModule = coreModule

    def getImports(self):
        return self.coreModule.moduleInfo.imports
    
    def getDocuments(self):
        return self.coreModule.moduleInfo.docstring
    
    def getTheorems(self):
        leanFile = LeanFile(self.coreModule.lean_file, self.coreModule.lines)

        declarations:list[CoreDeclaration] = self.coreModule.decls
        infoTrees: list[CoreInfoTree] = self.coreModule.infoTrees
        tacticProofs = collect_all_tacticProofs(leanFile, infoTrees)
        terms = collect_all_terms(leanFile, infoTrees, self.name)
        theorems = []
        for _, decl in enumerate(declarations):
            if decl.kind == "theorem":
                if len(decl.name) == 0:
                    continue
                theorem = extract_theorem(leanFile, self.name, decl, tacticProofs, terms)
                if theorem is not None: # and theorem.proofOperator == ":=" and theorem.proofType == "Tactic":
                    theorems.append(theorem)
        return theorems
    
    def getVariables(self):
        leanFile = LeanFile(self.coreModule.lean_file, self.coreModule.lines)
        declarations:list[CoreDeclaration] = self.coreModule.decls
        variables = []
        for _, decl in enumerate(declarations):
            if decl.kind == "variable":
                fileRange = leanFile.createFileRange(decl.ref.range)
                content = leanFile.remove_comment(leanFile.getTextFromLineModule(fileRange))
                variables.append(Variable(decl, content, fileRange))
        return variables

