import logging
from typing import Self
from dataclasses import dataclass, field
from dataclasses_json import dataclass_json
from .lean_file import LeanFile, LeanFileRange


@dataclass_json
@dataclass(frozen=True, eq=False)
class Term:
    fileRange: LeanFileRange
    ident: str
    type: str  


@dataclass_json
@dataclass(frozen=True, eq=False)
class Tactic:
    fileRange: LeanFileRange
    pp: str   
    before: list[str]
    after: list[str]
    children: list[str] = field(default_factory=list)
    kind: list[str] = None

    def __eq__(self, other):
        return self.fileRange == other.fileRange and \
               self.pp == other.pp and \
               self.before == other.before and \
               self.after == other.after
    
    def append_child(self, tactic: Self):
        if tactic is None:
            return
        for item in self.children:
            if item.fileRange.inRange(tactic.fileRange):
                item.append_child(tactic)
                return
        #self.children.append(tactic)

@dataclass_json
@dataclass(frozen=True, eq=False)
class TacticProof:

    tactics: list[Tactic] = field(default_factory=list)

    def fileRange(self):
        assert len(self.tactics) > 0
        return LeanFileRange(self.tactics[0].fileRange.start, self.tactics[-1].fileRange.stop)

    def __str__(self):
        children_len = None
        if self.tactics is not None:
            children_len = len(self.tactics)
        return f"children={children_len}"
    
    def __eq__(self, other):
        assert len(self.tactics) > 0
        if self.tactics is not None and other.tactics is not None and \
           self.len(self.tactics) == self.len(other.fileRange):
            return self.tactics[0].before == other.tactics[0].before and \
                   self.tactics[-1].after == other.tactics[-1].after
        elif self.tactics is None and other.tactics is None:
            return True
        else:
            return False
        
    def __lt__(self, other):
        return self.fileRange() < other.fileRange()
    
    def append_tactic(self, tactic: Tactic):
        if tactic is None:
            return
        for item in self.tactics:
            if item.fileRange.inRange(tactic.fileRange):
                item.append_child(tactic)
                return
        self.tactics.append(tactic)

def find_term(fileRange: LeanFileRange, ident: str, terms: list[Term]):
    if fileRange is None:
        return None
    for term in terms:
        if term and term.fileRange and fileRange.inRange(term.fileRange) and term.ident == ident:
            return term
    return None

def find_tactricProof(fileRange: LeanFileRange, tacticProofs: list[TacticProof]):
    inRangeTacticProofs = []
    for tacticProof in tacticProofs:
        proofFileRange = tacticProof.fileRange()
        if proofFileRange and fileRange.inRange(proofFileRange):
            inRangeTacticProofs.append(tacticProof)
    return inRangeTacticProofs

def createTactic(leanFile: LeanFile, ref, tactic, strkind, parentRange, fileRangeset):
    range = ref.range if ref.range else parentRange
    fileRange = leanFile.createFileRange(range)
    if fileRange in fileRangeset:
        return None
    fileRangeset.add(fileRange)
    beforeGoals = []
    for goal in tactic.before:
        beforeGoals.append(goal.pp)
    afterGoals = []
    for goal in tactic.after:
        afterGoals.append(goal.pp)
    pp = leanFile.remove_comment(leanFile.getTextFromLineModule(fileRange))
    return Tactic(fileRange, pp, beforeGoals, afterGoals, kind=strkind)

def collect_tactcis(leanFile: LeanFile, nodes, tacticProof: TacticProof, parentRange, includeSeq, fileRangeset, bPrint, level):
    for node in nodes:
        strkind = ".".join([str(v) for v in node.ref.kind]) if node.ref and node.ref.kind else ""
        if bPrint:
            print(f"strkind: {level} {strkind} {includeSeq} {node.ref.pp}")
        if strkind == "Lean.Parser.Term.byTactic":
            #before = node.info.tactic.before if node.info and node.info.tactic else ""
            #if before == "":
            #    before = node.info.term.before if node.info and node.info.term else ""
            #after = node.info.tactic.after if node.info and node.info.tactic else ""
            #if after == "":
            #    after = node.info.term.after if node.info and node.info.term else ""
            #print(f"byTactic: pp: {node.ref.pp}, before: {before}, after: {after}")
            return
        elif "Lean.cdot" in strkind:
            tactic = createTactic(leanFile, node.ref, node.info.tactic, strkind, parentRange, fileRangeset)
            if tactic:         
                tacticProof.append_tactic(tactic)
        elif "Congr!.congr!" in strkind:
            tactic = createTactic(leanFile, node.ref, node.info.tactic, strkind, parentRange, fileRangeset)
            if tactic:         
                tacticProof.append_tactic(tactic)
        elif node.info and node.info.tactic and node.ref.kind:
            if strkind != "by" \
               and strkind != ";" \
               and "tactic" in strkind.lower() \
               and (not "Lean.Parser.Tactic.tacticSeq" in strkind or includeSeq)\
               and strkind != "Lean.Parser.Tactic.tactic_<;>_" \
               and strkind != "Lean.Parser.Tactic.skip" \
               or strkind.startswith("Mathlib.Meta."):
                #and strkind != "Lean.Parser.Tactic.allGoals":
                #and strkind != "Lean.Parser.Tactic.withAnnotateState" \
                #and strkind != "Lean.Parser.Tactic.focus" \
                tactic = createTactic(leanFile, node.ref, node.info.tactic, strkind, parentRange, fileRangeset)
                if tactic:         
                    tacticProof.append_tactic(tactic)
                    if bPrint:
                        print(f"strkind: {level}, {includeSeq}, {strkind} {tactic.pp} {parentRange} {node.ref.range}")
            #if strkind == "Lean.Parser.Tactic.Conv.conv":
            #    return
        if node.children:
            childIncludeSeq = False if "Lean.Parser.Tactic.tacticSeq" in strkind else includeSeq
            if strkind != "Lean.Parser.Tactic.tactic_<;>_":
                childIncludeSeq = False
            childFileRange = node.ref.range if node.ref.range else parentRange
            collect_tactcis(leanFile, node.children, tacticProof, childFileRange, childIncludeSeq, fileRangeset, bPrint, level+1)

def collect_all_tacticProofs(leanFile: LeanFile, nodes: list):
    tacticProofs = []
    for node in nodes:
        strkind = ".".join([str(v) for v in node.ref.kind]) if node.ref and node.ref.kind else ""
        if node.info and node.info.tactic:
            if strkind == "Lean.Parser.Term.byTactic":
                tacticProof = TacticProof()
                bPrint = False
                #from .lean_datasets import FilePos
                #proofFileRange = LeanFileRange(FilePos(209, 68),FilePos(222, 38))
                #if node.ref and node.ref.range:
                #    fileRange = LeanFileRange.fromStringRange(lines, node.ref.range)
                #    if proofFileRange.inRange(fileRange) and node.info.tactic:
                #        bPrint = True

                collect_tactcis(leanFile, node.children, tacticProof, node.ref.range, False, set(), bPrint, 0)
                if bPrint:
                    print(f"tacticProof: {tacticProof}, {len(tacticProof.tactics)}")
                if len(tacticProof.tactics) > 0:
                    tacticProofs.append(tacticProof)
                return tacticProofs
        elif node.children:
            tacticProofs.extend(collect_all_tacticProofs(leanFile, node.children))
        
    return tacticProofs

def collect_all_terms(leanFile: LeanFile, nodes: list, module_name):
    terms = []
    for node in nodes:
        if node.info and node.info.term and node.ref.kind == ["ident"] and node.info.term.expected_type is None:
            fileRange = leanFile.createFileRange(node.ref.range)
            term = Term(fileRange, node.info.term.value, node.info.term.type)
            terms.append(term)
        elif node.children:
            terms.extend(collect_all_terms(leanFile, node.children, module_name))
    return terms

def find_all_terms(nodes: list, pp: str):
    founds = []
    for node in nodes:
        if node.ref and pp in node.ref.pp:
            item = {
                "node": node, 
                "children": []
            }
            founds.append(item)
        if node.children:
            sub_founds = find_all_terms(node.children, pp)
            if len(sub_founds) > 0:
                item = {
                    "node": node, 
                    "children": sub_founds
                }
                founds.append(item)
    return founds

