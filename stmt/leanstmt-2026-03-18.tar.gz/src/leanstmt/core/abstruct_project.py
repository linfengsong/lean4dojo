import re
from typing import Optional
from dataclasses import dataclass
from pathlib import Path

@dataclass
class AbstructProject:
    root_dir: str
    all_lean_src_paths: list[Path] = None

    def __post_init__(self):
        if self.all_lean_src_paths is None:
            self.all_lean_src_paths = self._all_lean_paths() 

    def _get_lean4_version_from_config(self) -> str:
        lean4_ver_regex = re.compile(r"leanprover/lean4:(?P<version>.+)")
        config_path = Path(self.root_dir) / 'lean-toolchain'
        with open(config_path, 'r') as file:
            content = file.read()
            m = lean4_ver_regex.search(content.strip())
            assert m is not None, f"Invalid config in {config_path}"
            v = m["version"]
            return v if v.startswith("v") or not v[0].isdigit() else "v" + v

    def _get_elan_toolchain_src_path(self) -> Path:
        version = self._get_lean4_version_from_config()
        lean_version = version[1:] if version.startswith("v") else version
        toolchain_name = f"leanprover--lean4---v{lean_version}"
        return Path.home() / ".elan/toolchains" / toolchain_name / "src/lean"

    def _all_lean_paths(self) -> list[Path]:
        root_path = Path(self.root_dir)
        paths = [root_path]
        packages_path = root_path.joinpath(".lake/packages")
        if packages_path.exists() and packages_path.is_dir:
            for item in packages_path.iterdir():
                if item.is_dir():
                    paths.append(item)
        paths.append(self._get_elan_toolchain_src_path())
        return paths

    def _path_of_module(self, module_name: str, base_dir: str) -> str:
        return str(Path(base_dir) / Path(*(module_name.split("."))).with_suffix(".lean"))
    
    def find_module_locations(self, search_list: Optional[list] = None) -> list[(str, str)]:
        locations = {}

        if search_list is not None:
            patterns = [f"{p.replace('.', '/')}/**/*.lean" for p in search_list]
            files = [f"{p.replace('.', '/')}.lean" for p in search_list]
        else:
            patterns = ["**/*.lean"]
            files = []
        for b_path in self.all_lean_src_paths:
            for file in files:
                if Path(b_path / file).exists():
                    rel_path = Path(file).with_suffix("")
                    m_name = ".".join(rel_path.parts)
                    if not m_name in locations:
                        locations[m_name] = b_path
            for p in patterns:
                for file_path in b_path.glob(p):
                    rel_path = file_path.relative_to(b_path).with_suffix("")
                    m_name = ".".join(rel_path.parts)
                    if not m_name in locations:
                        locations[m_name] = b_path
        return locations

