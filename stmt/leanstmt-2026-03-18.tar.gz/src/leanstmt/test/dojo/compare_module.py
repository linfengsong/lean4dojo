import json
import io
from typing import Any
from dataclasses import dataclass, asdict
from dataclasses_json import dataclass_json
from ...core.lean_project import LeanProject
from .lean_module import create_lean_module
from .dojo_module import create_dojo_module

@dataclass_json
@dataclass
class Diff:
    module: str = None
    theorem: str = None
    tactic: int = None
    name: str = None
    old: Any = None
    new: Any = None
    detail_old: Any = None
    detail_new: Any = None

def normalize_string(val: str):
    val = " ".join(val.strip().split())
    val = val.replace("{ ", "{").replace(" }", "}").replace("(", "").replace(")", "") #.replace("( ", "(").replace(" )", ")")
    val = val.replace("\n", " ").replace("\r", " ").replace("\t", " ")
    val = val.replace("¬", "¬ ").replace("«", " ").replace("≫", " ").strip()
    val = " ".join(val.split())
    return val

def compare_tactic(index, tactic1, tactic2):
    if tactic1.fileRange != tactic2.fileRange:
        return Diff(tactic=index, name="tactic.fileRange",old=tactic1.fileRange, new=tactic2.fileRange, detail_old=tactic1, detail_new=tactic2)
    if tactic1.pp != tactic2.pp:
        return Diff(tactic=index, name="tactic.pp", old=tactic1.pp, new=tactic2.pp, detail_old=tactic1, detail_new=tactic2)
    if tactic1.before != tactic2.before:
        return Diff(tactic=index, name="tactic.before", old=tactic1.before, new=tactic2.before, detail_old=tactic1, detail_new=tactic2)
    if tactic1.after != tactic2.after:
        return Diff(tactic=index, name="tactic.after", old=tactic1.after, new=tactic2.after, detail_old=tactic1, detail_new=tactic2)
    return None

def compare_theorem(theorem1, theorem2):
    if theorem1.name != theorem2.name:
        return Diff(theorem=theorem1.name, name="theorem.name", old=theorem1.name, new=theorem2.name, detail_old=theorem1, detail_new=theorem2)
    if theorem1.fileRange.start != theorem2.fileRange.start:
        return Diff(theorem=theorem1.name, name="theorem.fileRange", old=theorem1.fileRange.start, new=theorem2.fileRange.start, detail_old=theorem1, detail_new=theorem2)
    if theorem1.proofOperator != theorem2.proofOperator:
        return Diff(theorem=theorem1.name, name="proofOperator", old=theorem1.proofOperator, new=theorem2.proofOperator, detail_old=theorem1, detail_new=theorem2)
    proof1 = normalize_string(theorem1.proof)
    if proof1.startswith("by "):
        proof1 = proof1[3:]
    if proof1 != normalize_string(theorem2.proof):
        return Diff(theorem=theorem1.name, name="proof", old=theorem1.proof, new=theorem2.proof, detail_old=theorem1, detail_new=theorem2)
    if len(theorem1.tactics) != len(theorem2.tactics):
        return Diff(theorem=theorem1.name, name="tactics", old=len(theorem1.tactics), new=len(theorem2.tactics), detail_old=theorem1, detail_new=theorem2)
    for i, tactic1 in enumerate(theorem1.tactics):
        tactic2 = theorem2.tactics[i]
        diff = compare_tactic(i, tactic1, tactic2)
        if diff:
            diff.theorem = theorem1.name
            return diff
        
def compare_module(module1, module2):
    if module1.name != module2.name:
        return Diff(module=module1.name, name="module.name",old=module1.name, new=module2.name, detail_old=module1, detail_new=module2)
    if len(module1.theorems) != len(module2.theorems):
        dojo_theorems = [ theorem.name for theorem in module1.theorems]
        lean_theorems = [ f"{theorem.name},{theorem.proofType}" for theorem in module2.theorems]
        return Diff(module=module1.name, name="theorems", old=len(module1.theorems), new=len(module2.theorems), detail_old=dojo_theorems, detail_new=lean_theorems)
    theorem2_dict = {}
    for theorem in module2.theorems:
        theorem2_dict[theorem.name] = theorem
    for theorem1 in module1.theorems:
        theorem2 = theorem2_dict.get(theorem1.name)
        if theorem2 is None:
            return Diff(module=module1.name, name="theorem.name",  old=theorem1.name, detail_old=theorem1)
        diff = compare_theorem(theorem1, theorem2)
        if diff:
            diff.module=module1.name
            return diff

def to_lean_ident(name: list[str]):
    return ".".join([str(v) for v in name])

def main(woring_dir: str, search_list: list, detail_level: int = 0, prefect: bool = False):

    leanProject = LeanProject(working_dir, ".jixia")

    output = io.StringIO()

    module_locations = leanProject.find_module_locations(search_list)
    for key in module_locations.keys():
        module_name = key.split(".")
        leanModule = create_lean_module(leanProject, module_name, output)
        dojoModule = create_dojo_module(working_dir, ".dojo", module_name, output)
        if leanModule is None and dojoModule is None:
            print(f"No diff both Module is none {module_name}")
            continue
        if leanModule is None and dojoModule or leanModule and dojoModule is None:
            diff = Diff(module=module_name, name="module.name", old=dojoModule, new=leanModule)
        else:
            diff = compare_module(dojoModule, leanModule)
            if detail_level == 0:
                diff.detail_old=None
                diff.detail_new=None
        if diff is not None:
            if prefect:        
                str = diff.to_json(indent=2, ensure_ascii=False)
            else:
                str = f"{diff.to_json(ensure_ascii=False)}"
            print(f"diff: {str}")
        else:
            print(f"No diff")

if __name__ == "__main__":
    working_dir = "/home/linfe/math/lean_test"
    prefect=False
    detail_level=0
    #module_name = ["LeanTest","Basic"]
    search_list = ["Mathlib.Data.Nat.Init"]
    main(working_dir, search_list, detail_level, prefect)

    # python -m leanstmt.test.dojo.compare_module