from dataclasses import dataclass
from dataclasses_json import dataclass_json
from ...core.structs import LeanStringRange, LeanLineModel

@dataclass_json
@dataclass(frozen=True, order=True)
class FilePos:
    line: int
    column: int

@dataclass_json
@dataclass(frozen=True)
class FileRange:
    start: FilePos
    stop: FilePos

    @classmethod
    def fromStringRange(cls, lines: list[LeanLineModel], stringRange: LeanStringRange):
        start = FilePos(1, 1)
        stop = FilePos(len(lines) + 1, 1)
        if stringRange is not None:
            if stringRange.start is not None:
                start = cls.createFilePos(lines, int(stringRange.start))
            if stringRange.stop is not None:
                stop  = cls.createFilePos(lines, int(stringRange.stop))
        return FileRange(start, stop)
    
    @classmethod
    def createFilePos(cls, lines: list[LeanLineModel], charPos: int):
        start = 0
        lineNum = 1
        for index, line in enumerate(lines):
            if line.start > charPos:
                break
            start = line.start
            lineNum = index + 1
        column = charPos - start + 1
        return FilePos(lineNum, column)
    
    def __lt__(self, other):
        return self.start < other.start or self.start == other.start and self.stop >= other.stop
    
    def inRange(self, fileRange):
        return self.start <= fileRange.start and fileRange.stop <= self.stop

@dataclass_json
@dataclass(frozen=True, eq=False)
class Term:
    fileRange: FileRange
    ident: str
    type: str  

@dataclass_json
@dataclass(frozen=True, eq=False)
class TacticBase:
    fileRange: FileRange
    pp: str   
    before: list[str]
    after: list[str]

@dataclass_json
@dataclass(frozen=True, eq=False)
class Tactic(TacticBase):
    pass

@dataclass_json
@dataclass(frozen=True, eq=False)
class RootTactic(TacticBase):
    fileRange: FileRange
    pp: str   
    before: list[str]
    after: list[str]
    children: list[Tactic]

    def __str__(self):
        children_len = None
        if self.children is not None:
            children_len = len(self.children)
        return f"tactic={self.fileRange}, {self.pp}, children={children_len}"
    
    def __eq__(self, other):
        return self.fileRange == other.fileRange and \
               self.pp == other.pp and \
               self.before == other.before and \
               self.after == other.after 

@dataclass_json
@dataclass(frozen=True, eq=False)
class Theorem:
    fileRange: FileRange
    name: str
    
    signature: str
    signatureFileRange: FileRange

    proofOperator: str

    proof: str
    proofFileRange: FileRange
    proofType: str
    
    proofTactic: RootTactic
    tactics: list[RootTactic]

    tactic_before: list
    tactic_after: list

    def __str__(self):
        return f"range={self.fileRange}, name={self.name}, type={self.type}, tactics: {len(self.tactics)}"
    
    def __eq__(self, other):
        return self.name == self.name and \
               self.fileRange == other.fileRange and \
               self.proofOperator == other.proofOperator and \
               self.tactics == other.tactics

@dataclass_json
@dataclass(frozen=True, eq=False)
class Module:
    name: str
    theorems: list[Theorem]

    def __eq__(self, other):
        return self.module == other.module and self.theorems == other.theorems 
