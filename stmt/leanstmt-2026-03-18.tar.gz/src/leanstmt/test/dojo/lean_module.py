import re
from ...core.structs import LeanDeclaration, LeanStringRange, LeanInfoTree, LeanLineModel
from ..util import getLeanSourceDirOrFile
from .datasets import FileRange, Term, Tactic, RootTactic, Theorem, Module

def createTactic(ref, tactic, lines, skipMultiples = False, previousFileRange = None):
    if skipMultiples and ("\n" in ref.pp or ";" in ref.pp):
        return None
    currentFileRange = FileRange.fromStringRange(lines, ref.range)
    if previousFileRange is not None:
        if previousFileRange.inRange(currentFileRange):
            return None
    if ref.pp == "by":
        return None
    beforeGoals = []
    for goal in tactic.before:
        beforeGoals.append(goal.pp)
    afterGoals = []
    for goal in tactic.after:
        afterGoals.append(goal.pp)
    return Tactic(currentFileRange, ref.pp, beforeGoals, afterGoals)

def collect_sub_tactics(nodes: list, lines, previousFileRange = None):
    sub_tactics = []
    for node in nodes:
        if node.info and node.info.tactic:
            tacticInfo = node.info.tactic
            tactic = createTactic(node.ref, tacticInfo, lines, True, previousFileRange)
            if tactic is not None:
                sub_tactics.append(tactic)
                previousFileRange = tactic.fileRange
        if node.children:
            sub_tactics.extend(collect_sub_tactics(node.children, lines, previousFileRange))
            
    return sub_tactics

def collect_all_terms(nodes: list, lines: list, module_name):
    terms = []
    for node in nodes:
        if node.info and node.info.term and node.ref.kind == ["ident"] and node.info.term.expected_type is None:
            fileRange = FileRange.fromStringRange(lines, node.ref.range)
            term = Term(fileRange, node.info.term.value, node.info.term.type)
            terms.append(term)
        elif node.children:
            terms.extend(collect_all_terms(node.children, lines, module_name))
    return terms

def find_term(fileRange: FileRange, ident: str, terms: list[Term]):
    for term in terms:
        if fileRange.inRange(term.fileRange) and term.ident == ident:
            return term
    return None

def collect_all_tactics(nodes: list, lines: list):
    tactics = []
    for node in nodes:
        if node.info and node.info.tactic:
            tactic = createTactic(node.ref, node.info.tactic, lines)
            sub_tactics = collect_sub_tactics(node.children, lines)
            rootTactic = RootTactic(tactic.fileRange, tactic.pp, tactic.before, tactic.after, sub_tactics)
            tactics.append(rootTactic)
            return tactics
        elif node.children:
            tactics.extend(collect_all_tactics(node.children, lines))
    return sorted(tactics, key=lambda x: x.fileRange, reverse=False)

def find_root_tactrics(fileRange: FileRange, rootTactics: list[RootTactic]):
    tactics = []
    for rootTactic in rootTactics:
        if fileRange.inRange(rootTactic.fileRange):
            tactics.append(rootTactic)
    return tactics

def find_all_terms(nodes: list, pp: str):
    founds = []
    for node in nodes:
        if node.ref and pp in node.ref.pp:
            item = {
                "node": node, 
                "children": []
            }
            founds.append(item)
        if node.children:
            sub_founds = find_all_terms(node.children, pp)
            if len(sub_founds) > 0:
                item = {
                    "node": node, 
                    "children": sub_founds
                }
                founds.append(item)
    return founds

def extractLine(line: str, start: int, stop: int = -1):
    buf = bytes(line, encoding='utf-8')
    if stop == -1:
        stop = len(buf)
    buf = buf[start : stop]
    return buf.decode('utf-8') 

def getLeanSourceCode(project, module_name: list[str], fileRange: FileRange):
    file_path = getLeanSourceDirOrFile(project, module_name, True)
    if file_path is None:
        raise "Cannot find module_name: {module_name}"

    with open(file_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        target_lines = lines[fileRange.start.line - 1 : fileRange.stop.line]
        if not target_lines:
            return ""
        if len(target_lines) == 1:
            return extractLine(target_lines[0], fileRange.start.column -1, fileRange.stop.column)
        else:
            target_lines[0] = extractLine(target_lines[0], fileRange.start.column - 1)
            target_lines[-1] = extractLine(target_lines[-1], 0, fileRange.stop.column)
            return "".join(target_lines)

def getToken(line: str, index: int):
    tokens = line.strip().replace("\n", " ").replace("\r", " ").replace("\t", " ").split()
    if index < 0:
        index = len(tokens) + index
    if index >= len(tokens):
        return None
    return tokens[index]

def getTheoremName(module_name: list[str], decl: LeanDeclaration):
    #first item is "_private" if it's a private declaration, we need to remove the prefix and get the real name
    # for example, if the declaration name is ["_private", "Init", "Nat", "add"], and the module name is ["Init", "Nat"], we need to remove the prefix and get the real name "add"  
    if decl.name is None or len(decl.name) == 0:
        return None
    if decl.name[0] != '_private':
        return ".".join(decl.name)
    private_name = decl.name[len(module_name) + 2:]
    return ".".join(private_name)

# =============================
# Extract Theorems
# =============================
def extract_theorem_signature_proof(project, module_name, lines, signature_start, theorem_stop):
    fileRange = FileRange.fromStringRange(lines, LeanStringRange(signature_start, theorem_stop))
    text = getLeanSourceCode(project, module_name, fileRange)
    text = text.replace("\t", " ").replace("\n", " ").replace("\r", " ")
    buf = bytes(text, encoding='utf-8')
    match = re.search(bytes(" := ", encoding='utf-8'), buf)
    if match is None:
        return None, None
    match_start = signature_start + match.start()
    signature_range = LeanStringRange(signature_start, match_start)
    proof_range = LeanStringRange(match_start + 1, theorem_stop)
    signature_fileRange = FileRange.fromStringRange(lines, signature_range)
    proof_fileRange = FileRange.fromStringRange(lines, proof_range)
    return signature_fileRange, proof_fileRange

def extract_theorems(project, module_name, output):
    module = project.fetch_module(module_name)
    if module is None:
        return []
    declarations:list[LeanDeclaration] = module.decls
    infoTrees: list[LeanInfoTree] = module.infoTrees
    lines: list[LeanLineModel] = module.lines
    rootTactics = collect_all_tactics(infoTrees, lines)
    terms = collect_all_terms(infoTrees, lines, module_name)
    theorems = []
    for _, decl in enumerate(declarations):
        if decl.kind == "theorem":
            if len(decl.name) == 0:
                continue
            theorem = extract_theorem(project, module_name, decl, lines, rootTactics, terms, output)
            if theorem is not None and theorem.proofOperator == ":=" and theorem.proofType == "Tactic":
                theorems.append(theorem)
    return theorems

def extract_theorem(project, module_name, decl, lines, rootTactics, terms, output):
    theorem_name = getTheoremName(module_name, decl)
    theorem_range = FileRange.fromStringRange(lines, decl.ref.range)
    tactics = find_root_tactrics(theorem_range, rootTactics)

    signature = decl.signature.pp
    signatureRange = FileRange.fromStringRange(lines, decl.signature.range)
            
    statement = decl.value.pp
    theorem_proofRange = FileRange.fromStringRange(lines, decl.value.range)

    if statement is None:
        statement = getLeanSourceCode(project, module_name, theorem_proofRange)

    proofOperator = getToken(statement, 0)
    if proofOperator.startswith(":="):
        proofOperator = ":="
    if proofOperator != ":=" and proofOperator != "|" and proofOperator != "where":
        print(f"proofOperator {proofOperator}  is not valid, remove: {theorem_name} {module_name}", file=output)
        return None

    if statement is None:
        print(f"no proof, remove: {theorem_name} {module_name}", file=output)
        return None
    if proofOperator is None:
        print(f"no proofOperator, remove: {theorem_name} {module_name}", file=output)
        return None
    
    statement = statement.rstrip()[len(proofOperator) + 1:].lstrip()
    startBy = True
    byToken = getToken(statement, 0)
    if byToken is None or byToken != "by":
        startBy = False

    theorem_proof = statement[len(proofOperator):].lstrip()
    tactic_before = None
    tactic_after = None
    proofTactic = None
    proofType = "Term"
    if startBy:
        proofType = "Tactic"
        if len(tactics) > 0:
            proofTactic = tactics.pop(0)
            tactic_before = proofTactic.before
            tactic_after = proofTactic.after

    if proofTactic is None:
        name_array = theorem_name.split(".")
        term = None
        while term is None and len(name_array) > 0:
            search_name = ".".join(name_array)
            term = find_term(theorem_range, search_name, terms)
            if term is None and not search_name.startswith("@"):
                search_name = "@" + search_name
                term = find_term(theorem_range, search_name, terms)
            name_array.pop(0)
        if term is None:
            search_name = "_root_." + theorem_name
            term = find_term(theorem_range, search_name, terms)
            if term is None:
                search_name = "@" + search_name
                term = find_term(theorem_range, search_name, terms)
        if term is None:
            search_name = "«" + theorem_name.split('.')[-1] + "»"
            term = find_term(theorem_range, search_name, terms)
            if term is None:
                search_name = "@" + search_name
                term = find_term(theorem_range, search_name, terms)

        if term is not None:
            tactic_before = term.type
        elif startBy:
            print(f"ERROR tactic_before is none on Tactic: {theorem_name} {module_name}", file=output)
        else:
            if decl.name[0] != '_private':
                print(f"tactic_before is none, remove: {theorem_name} {module_name}", file=output)
            return None

    return Theorem(theorem_range, theorem_name, signature, signatureRange, proofOperator, theorem_proof, theorem_proofRange, proofType, proofTactic, tactics, tactic_before, tactic_after)

def create_lean_module(project, module_name, output):
    name = ".".join(module_name)
    theorems = extract_theorems(project,module_name, output)
    return Module(name, theorems)
