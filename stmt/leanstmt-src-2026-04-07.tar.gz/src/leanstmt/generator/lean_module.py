import sys
import re
from typing import Optional
from dataclasses import dataclass
from dataclasses_json import dataclass_json
from ..core.core_project import CoreModule
from ..core.core_datasets import CoreDeclaration, CoreInfoTree
from .lean_statement import Attribute, ScopeInfo, Modifiers, Abbrev, Axiom, ClassInductive, Declaration, Example, Inductive, Instance, Opaque, Structure, Variable, ProofWanted, Theorem
from .lean_file import LeanFile, LeanFileRange, LeanFilePos
from .lean_elab import collect_all_terms, collect_all_tacticProofs

@dataclass_json
@dataclass(frozen=True)
class LeanScopeRangeInfo:
    kind : str
    name : str
    content: str
    range : LeanFileRange

    def __str__(self):
        return self.to_json()

@dataclass_json
@dataclass(frozen=True)
class LeanContextEntryInfo:
    kind : str
    raw_kind: str
    content : str
    range : LeanFileRange

    def __str__(self):
        return self.to_json()

@dataclass_json
@dataclass(frozen=True)
class LeanSymbolReference:
    name: str
    src_name: str
    range: LeanFileRange

    def __str__(self):
        return self.to_json()

@dataclass_json
@dataclass(frozen=True)
class LeanSymbol:
    kind: str
    name: str
    type_full: Optional[str]
    type_readable: Optional[str]
    type_fallback: str
    type_references: list[LeanSymbolReference]
    value_references: Optional[list[LeanSymbolReference]] = None
    is_prop: bool = False

    def __str__(self):
        return self.to_json()

@dataclass_json
@dataclass(frozen=True)
class LeanModule:
    name: str
    coreModule: CoreModule

    firsttime: bool = True

    def getImports(self):
        return self.coreModule.moduleInfo.imports
    
    def _appendSymbolReference(self, leanFile, reference, symbols_dict):
        if reference.name is None or reference.range is None:
            return
        name = ".".join([str(item) for item in reference.name])
        bprint = False #"getElem?_eq_some_iff" == name
        fileRange = LeanFileRange(LeanFilePos.createFilePos(leanFile.lines, reference.range[0]),
                         LeanFilePos.createFilePos(leanFile.lines, reference.range[1]))
        src_name_raw = leanFile.getTextFromLineModule(fileRange)
        src_name = leanFile.remove_comment(src_name_raw)
        # adjust correct range for name. InforTree does not setup right some cases
        if bprint: print(f"src_name_raw: |{src_name_raw}|, src_name: |{src_name}|, name |{name}|, fileRange: {fileRange}")
        adj_src_name = None
        if fileRange.start.line == fileRange.stop.line:
            for item in reversed(reference.name):
                check_src_name = str(item) + "." + adj_src_name if adj_src_name else str(item)
                if check_src_name in src_name:
                    adj_src_name = check_src_name
                else:
                    break
            if adj_src_name:
                if src_name != adj_src_name:
                    index = src_name.index(adj_src_name)
                    if bprint: print(f"adj_src_name: |{adj_src_name}|, src_name |{src_name}|")
                    if bprint: print(f"          index: {index}, fileRange {fileRange}")
                    src_name = adj_src_name
                    fileRange = LeanFileRange(LeanFilePos(fileRange.start.line, fileRange.start.column + index),
                                LeanFilePos(fileRange.start.line, fileRange.start.column + index + len(adj_src_name) - 1))
                    if bprint: print(f"      src_name |{src_name}|, adj fileRange {fileRange}")
            else:
                if bprint: print(f"adj_src_name is none, src_name |{src_name}|, , name |{name}|")
        str_fileRange = f"{fileRange}"
        if not str_fileRange in symbols_dict:
            symbols_dict[str_fileRange] = LeanSymbolReference(name, src_name, fileRange)

    def getSymbols(self, kind: str, name: str):
        if name is None:
            return None
        symbol = None
        for smbl in self.coreModule.symbols:
            if smbl.kind != kind:
                continue
            symbol_name = ".".join([str(item) for item in smbl.name ])
            if symbol_name == name:
                symbol = smbl
        if symbol is None:
            return None
        
        symbols_dict = {}
        leanFile = LeanFile(self.coreModule.lean_file, self.coreModule.lines)
        for reference in symbol.type_references:
            self._appendSymbolReference(leanFile, reference, symbols_dict)

        for reference in symbol.value_references:
            self._appendSymbolReference(leanFile, reference, symbols_dict)
        return symbols_dict.values()   
    
    def getScopeRangeInfos(self):
        def get_scope_name(kind, scope_range_name):
            if scope_range_name is None:
                return None
            if not scope_range_name.startswith(kind + " "):
                return None
            scope_range_name = " ".join(scope_range_name.split()) if scope_range_name else None
            parts = scope_range_name.split(" ")
            if len(parts) > 1:
                return parts[1]
            else:
                return None

        #print(f"xxxxx module name: {self.name}")
        #kind_set = set()
        #for scope_range in self.coreModule.moduleInfo.scope_range_infos:
        #    if not scope_range.kind in kind_set:
        #        kind_set.add(scope_range.kind)
        #    if scope_range.kind == "in_statement":
        #        print(f"xxxxxxx scope_info: {scope_range}")
        #print(f"xxxxx kind_set: {kind_set}")

        scopeRangeInfos = []
        #for scope_range in self.coreModule.moduleInfo.scope_range_infos:
        #    if scope_range.kind == "end" and scope_range.name:
        #        name = get_scope_name(scope_range.kind, scope_range.name)
        #        if name is not None:
        #            endMap[name] = scope_range.range.stop
        scope_name_dict = {}
        empty_sections = []
        leanFile = LeanFile(self.coreModule.lean_file, self.coreModule.lines)
        for scope_range in self.coreModule.moduleInfo.scope_range_infos:
            name = scope_range.name.strip() if scope_range.name and scope_range.name != "anonymous" else None
            if scope_range.kind in ["namespace", "section"]:
                #print(f"xxxxx scope_range: {scope_range}")
                contentRange = LeanFileRange(LeanFilePos.createFilePos(leanFile.lines, scope_range.range.start), 
                                     LeanFilePos.createFilePos(leanFile.lines, scope_range.range.stop))
                range = LeanFileRange(contentRange.start, 
                                     LeanFilePos.createFilePos(leanFile.lines, sys.maxsize))
                content = leanFile.remove_comment(leanFile.getTextFromLineModule(contentRange)).strip()
                scopeInfo = LeanScopeRangeInfo(scope_range.kind, name, content, range)
                #print(f"xxxx scopeInfo: {scopeInfo}")
                if scope_range.kind == "section" and name is None:
                    scopeRangeInfos.append(scopeInfo)
                    empty_sections.append(scopeInfo)
                    #print(f"xxxxx empty section: {scopeInfo}")
                elif name:
                    scopeRangeInfos.append(scopeInfo)
                    scope_name_dict[name] = scopeInfo
            elif scope_range.kind == "end":
                orgScopeInfo = None
                if name:
                    name = get_scope_name(scope_range.kind, scope_range.name)
                    if name is not None and name in scope_name_dict:
                        orgScopeInfo = scope_name_dict.pop(name)
                else:
                    orgScopeInfo = empty_sections.pop()
                    #print(f"xxxxx empty section pop: {orgScopeInfo}")
                if orgScopeInfo:
                    endPos = LeanFilePos.createFilePos(leanFile.lines, scope_range.range.stop)
                    object.__setattr__(orgScopeInfo.range, "stop", endPos)
        #print(f"xxxx scopeRangeInfos: {len(scopeRangeInfos)}")            
        return scopeRangeInfos

    def getContextEntries(self):
        contextEntries = []
        leanFile = LeanFile(self.coreModule.lean_file, self.coreModule.lines)
        inRangeEntry = None
        context_entries = sorted(self.coreModule.localContext.context_entries, key=lambda x: x.range) 
        for context_entry in context_entries:
            range = LeanFileRange(LeanFilePos.createFilePos(leanFile.lines, context_entry.range.start), 
                                LeanFilePos.createFilePos(leanFile.lines, context_entry.range.stop))
            content = leanFile.remove_comment(context_entry.content)
            kind = None
            raw_kind = None
            if context_entry.kind.startswith("Lean.Parser.Command."):
                kind = context_entry.kind[len("Lean.Parser.Command."):]

            elif context_entry.kind in \
                ["commandAssert_not_exists_", "commandLibrary_note2_"]:
                #"commandAssert_not_imported_"
                #"commandMk_iff_of_inductive_prop"
                kind = "custom_macro"
                raw_kind = context_entry.kind
            if kind:
                entry = LeanContextEntryInfo(kind, raw_kind, content, range)
                prev_entry = contextEntries.pop() if len(contextEntries) > 0 else None
                if prev_entry:
                    if not entry.range.inRange(prev_entry.range):
                        inRangeEntry = entry
                        contextEntries.append(prev_entry)
                elif inRangeEntry and inRangeEntry.range.inRange(entry.range):
                    entry = None
                    inRangeEntry = None 
                if entry:
                    contextEntries.append(entry)

        return contextEntries
    
    def getDocuments(self):
        return self.coreModule.moduleInfo.docstring
    
    def getStatements(self):
        leanFile = LeanFile(self.coreModule.lean_file, self.coreModule.lines)
        declarations:list[CoreDeclaration] = self.coreModule.decls
        infoTrees: list[CoreInfoTree] = self.coreModule.infoTrees
        tacticProofs = collect_all_tacticProofs(leanFile, infoTrees)
        terms = collect_all_terms(leanFile, infoTrees, self.name)
        statements = []
        fileRanges = []
        for _, decl in enumerate(declarations):
            name = self._getName(decl.name)
            fileRange = leanFile.createFileRange(decl.ref.range)
            content = leanFile.remove_comment(leanFile.getTextFromLineModule(fileRange))
            signature, signatureRange, value, valueRange = self._createSignatureAndValue(decl, leanFile, name, content, fileRange)
            scope_info = self._createScopeInfo(decl)
            modifiers = self._createModifiers(decl, leanFile)
    
            statement = None
            if decl.kind == "abbrev":
                statement = Abbrev(decl, content, fileRange, scope_info, modifiers, name, signature, signatureRange, value, valueRange)
            elif decl.kind == "axiom":
                statement = Axiom(decl, content, fileRange, scope_info, modifiers, name, signature, signatureRange)
            elif decl.kind == "classInductive":
                statement = ClassInductive(decl, content, fileRange, scope_info, modifiers, name, signature, signatureRange, value, valueRange)
            elif decl.kind == "definition":
                InExist = False
                for exist_fileRange in fileRanges:
                    if exist_fileRange.inRange(fileRange):
                        InExist = True
                if not "._@." in name and valueRange and not InExist: #remove MACRO declaration 
                    statement = Declaration(decl, content, fileRange, scope_info, modifiers, name, signature, signatureRange, value, valueRange)
            elif decl.kind == "example":
                statement = Example(decl, content, fileRange, scope_info, modifiers, name, signature, signatureRange, value, valueRange)
            elif decl.kind == "inductive":
                statement = Inductive(decl, content, fileRange, scope_info, modifiers, name, signature, signatureRange, value, valueRange)
            elif decl.kind == "instance":
                InExist = False
                for exist_fileRange in fileRanges:
                    if exist_fileRange.inRange(fileRange):
                        InExist = True
                if not (".inst" in name or name.startswith("inst")) and not ("_hyg" in name or InExist):
                    statement = Instance(decl, content, fileRange, scope_info, modifiers, name, signature, signatureRange, value, valueRange)
            elif decl.kind == "opaque":
                if signatureRange and fileRange != signatureRange: # other case is MACRO and need fix for MACRO
                    statement = Opaque(decl, content, fileRange, scope_info, modifiers, name, signature, signatureRange, value, valueRange)
            elif decl.kind == "structure":
                if not "._@." in name:
                    if signatureRange and signatureRange == fileRange:
                        signatureRange = None
                    if signatureRange is None:
                        name_index = content.find(name)
                        if name_index > 0:
                            end_index = content.find("where")
                            if end_index < 0:
                                end_index = content.find(":=")
                            if end_index > 0:
                                signature = content[name_index + len(name): end_index]
                                value = content[end_index:]
                            else:
                                signature = content[name_index + len(name):]
                                value = None
                            if len(signature.strip()) == 0:
                                signature = None                        
                    if value is None and valueRange is None:
                        index = content.find("where")
                        if index < 0:
                            index = content.find(":=")
                        if index > 0:
                            value = content[index:]
                    statement = Structure(decl, content, fileRange, scope_info, modifiers, name, signature, signatureRange, value, valueRange)       
            elif decl.kind == "theorem":
                if signature and value:
                    statement = Theorem.create(decl, content, fileRange, scope_info, modifiers, name, signature, signatureRange, value, valueRange, tacticProofs, terms)
            elif decl.kind == "variable":
                InExist = False
                for exist_fileRange in fileRanges:
                    if exist_fileRange.inRange(fileRange):
                        InExist = True # skip variable defined in the statement
                if not InExist:
                    statement = Variable(decl, content, fileRange, scope_info, modifiers)
            elif decl.kind == "proofWanted":
                statement = ProofWanted(decl, content, fileRange, scope_info, modifiers, name, signature, signatureRange, value, valueRange)
            else:
                print(f"ERROR decl.kind: {decl.kind} does not support at {self.name}")
                statement = None
            if statement is not None:
                fileRanges.append(statement.fileRange)
                statements.append(statement)
        return statements
    
    def _getName(self, name: str):
        #first item is "_private" if it's a private declaration, we need to remove the prefix and get the real name
        # for example, if the declaration name is ['_private', 'Mathlib', 'Data', 'EReal', 'Operations', 0, 'EReal', 'exists_lt_add_right'],
        # and the module name is ["Init", "Nat"], we need to remove the prefix and get the real name "add"  
        if name is None or len(name) == 0:
            return None
        
        if name[0] == '_private':
            p_name = name[1:]
            module_name_array = self.name.split(".")
            if len(p_name) + 1 > len(module_name_array):
                name_prefix_array = p_name[:len(module_name_array)]
                if name_prefix_array == module_name_array:
                    p_name = p_name[len(name_prefix_array):]
            if not isinstance(p_name[0], int):
                print(f"ERROR decl.name: {name} format is invalid for private {p_name}")
                print(f"         p_name: {p_name}, module: {self.name}")
            else:
                name = p_name[1:]
        return ".".join([str(item) for item in name ])
    
    def _createSignatureAndValue(self, decl: CoreDeclaration, leanFile: LeanFile, name: str, content: str, fileRange: LeanFileRange):
        signatureRange = leanFile.createFileRange(decl.signature.range) if decl.signature and decl.signature.range else None
        valueRange = leanFile.createFileRange(decl.value.range) if decl.value and decl.value.range else None
        adjustment = False
        signature = leanFile.getTextFromLineModule(signatureRange) if signatureRange else None
        if signatureRange:
            if valueRange is None:
                next_pos = leanFile.nextPos(signatureRange.stop)
                if next_pos < fileRange.stop:
                    valueRange = LeanFileRange(next_pos, fileRange.stop)
                    adjustment = True
            if valueRange and signatureRange == valueRange:
                valueRange = None
        if valueRange and valueRange.stop < fileRange.stop:
            valueRange = LeanFileRange(valueRange.start, fileRange.stop)
        value = leanFile.getTextFromLineModule(valueRange) if valueRange else None
        if valueRange and signatureRange and signatureRange.stop == valueRange.start:
            last_signature_char = signature[-1]
            if last_signature_char == ":" or last_signature_char == "-":
                signature, signatureRange, value, valueRange = \
                    self._move_one_position(signature, signatureRange, value, valueRange)
        elif adjustment: # bug in extract to have ":" when no space between ":=" or "--" 
            last_signature_char = signature[-1]
            if last_signature_char == ":" or last_signature_char == "-":
                signature, signatureRange, value, valueRange = \
                self._move_one_position(signature, signatureRange, value, valueRange)
        signature = leanFile.remove_comment(signature) if signature else None
        value = leanFile.remove_comment(value).rstrip() if value else None
        if value and value.strip().startswith("|") and not value.strip(" \t").startswith("\n"):
            signature, signatureRange, value, valueRange = \
                self._move_one_position(signature, signatureRange, value, valueRange)
        return signature, signatureRange, value, valueRange
    
    def _move_one_position(self, signature, signatureRange, value, valueRange):
        last_signature_char = signature[-1]
        signature = signature[:-1]
        value = last_signature_char + value
        valueRange = LeanFileRange(signatureRange.stop, valueRange.stop)
        signatureRange = LeanFileRange(signatureRange.start,
                                       LeanFilePos(signatureRange.stop.line, signatureRange.stop.column-1))          
        return signature, signatureRange, value, valueRange
    
    def _createScopeInfo(self, decl: CoreDeclaration):
        namespace = ".".join(decl.scope_info.curr_namespace) if decl.scope_info and decl.scope_info.curr_namespace else None
        omit_vars = decl.scope_info.omit_vars if decl.scope_info and decl.scope_info.omit_vars else None
        open_decl = None
        if decl.scope_info and decl.scope_info.open_decl:
            open_decl = []
            for open_dl in decl.scope_info.open_decl:
                if open_dl.simple:
                    open_ns = ".".join(open_dl.simple.namespace)
                    open_decl.append(open_ns)
        scoped_open_decl = None
        if decl.scope_info and decl.scope_info.scoped_open_decl:
            scoped_open_decl = []
            for open_dl in decl.scope_info.scoped_open_decl:
                open_ns = ".".join(open_dl)
                if open_decl and not open_ns in open_decl and open_ns != namespace:
                    scoped_open_decl.append(open_ns)
        #if decl.kind == "theorem" and self.name.startswith("Init") and len(decl.scope_info.var_decls) > 0:
        #if decl.kind == "theorem" and len(decl.scope_info.var_decls) > 0:
            #print(f"include_vars: {decl.scope_info.var_decls} in declaration {decl.name} in module {self.name}")
            #print(f"declaration {decl.name} in module {self.name} {decl.scope_info}")
        return ScopeInfo(decl.scope_info.var_decls, decl.scope_info.include_vars, omit_vars, namespace, open_decl, scoped_open_decl)
    
    def _createModifiers(self, decl: CoreDeclaration, leanFile: LeanFile):
        attrs = None
        for attr in decl.modifiers.visibility:
            attrs = []
            for attr in decl.modifiers.attrs:
                attrFileRange = leanFile.createFileRange(attr.stx)
                attrName = ".".join(attr.name)
                attrContent = leanFile.remove_comment(leanFile.getTextFromLineModule(attrFileRange)) if attrFileRange else None
                if attrContent and (attrContent.endswith("]") or attrContent.endswith(",")):
                    attrContent = attrContent.strip()[:-1].strip()
                else:
                    attrExFileRange = LeanFileRange(attrFileRange.stop, LeanFilePos(attrFileRange.stop.line, sys.maxsize))
                    attrEx = leanFile.getTextFromLineModule(attrExFileRange)[1:]
                    attrCommaIndex = attrEx.find(",")
                    attrEndIndex = attrEx.find("]")
                    if attrCommaIndex >= 0 and attrCommaIndex < attrEndIndex:
                        attrContent = attrContent + attrEx[:attrCommaIndex].strip()
                    elif attrEndIndex >= 0:
                        attrContent = attrContent + attrEx[:attrEndIndex].strip()
                attrs.append(Attribute(attr.kind, attrName, attrContent, attrFileRange))

        return Modifiers(
                decl.modifiers.visibility if decl.modifiers.visibility != "regular" else None,
                attrs,
                decl.modifiers.compute_kind if decl.modifiers.compute_kind != "regular" else None,
                decl.modifiers.rec_kind if decl.modifiers.rec_kind != "default" else None,
                decl.modifiers.is_unsafe
            )

def get_in_statement_prefix(full_source, decl_start_pos, scoped_open_names):
    """
    full_source: 移除註解後的原始碼字串
    decl_start_pos: 定理起始的 byte_offset
    scoped_open_names: Lean getScopeInfo 回傳的 ["Function", "MeasureTheory", ...]
    """
    # 1. 往回抓取一段文字（例如 200 字元，足以包含一個 open scoped 指令）
    lookback_fragment = full_source[max(0, decl_start_pos - 200):decl_start_pos].strip()
    
    # 2. 正則表達式：尋找以 'in' 結尾的指令
    # 模式說明：(指令類型) (內容) in (結尾可選空白)
    # 範例：open scoped Function in
    in_pattern = r"(open\s+scoped\s+([\w\.]+)\s+in)\s*$"
    match = re.search(in_pattern, lookback_fragment)
    
    if match:
        full_in_stmt = match.group(1) # "open scoped Function in"
        ns_name = match.group(2)      # "Function"
        
        # 3. 交叉驗證：檢查這個命名空間是否在 Lean 報出的 scopedOpenDecl 裡
        if ns_name in scoped_open_names:
            return full_in_stmt
            
    return ""