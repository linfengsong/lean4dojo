import sys
import re
from typing import Optional
from dataclasses import dataclass, field
from dataclasses_json import dataclass_json
from functools import total_ordering
from ..core.core_datasets import CoreStringRange, CoreLineModel

@total_ordering
@dataclass_json
@dataclass(frozen=True, order=False)
class LeanFilePos:
    line: int
    column: int

    def __str__(self):
        return self.to_json()
    
    def __eq__(self, other):
        return self.line == other.line and self.column == other.column
    
    def __lt__(self, other):
        return self.line < other.line or self.line == other.line and self.column < other.column

    @classmethod
    def createFilePos(cls, lines: list[CoreLineModel], bytePos: int):
        if len(lines) == 0:
            return cls(1, 1)
        start = 0
        lineNum = 1
        for index, line in enumerate(lines):
            if line.start > bytePos:
                break
            start = line.start
            lineNum = index + 1
        if lineNum > len(lines):
            lineNum = len(lines)
            bytePos = sys.maxsize
        textline = lines[lineNum - 1].line
        if textline is None:
            lineNum = lineNum -1
            bytePos = sys.maxsize
            textline = lines[lineNum - 1].line
        encoded_bytes = textline.encode("utf-8")[:bytePos - start]
        text = encoded_bytes.decode("utf-8")
        column = len(text) + 1
        return cls(lineNum, column)

@total_ordering
@dataclass_json
@dataclass(frozen=True, order=False)
class LeanFileRange:
    start: LeanFilePos
    stop: LeanFilePos

    def __str__(self):
        return self.to_json()
    
    def __eq__(self, other):
        return self.start == other.start and self.stop == other.stop
    
    def __lt__(self, other):
        return self.start < other.start or self.start == other.start and self.stop >= other.stop
    
    def inRange(self, fileRange):
        return self.start <= fileRange.start and fileRange.stop <= self.stop


class LeanLineModel():
    """An Line node with line information"""
    start: int
    line: str

    def __init__(self, start: int, line: str):
        self.start = start
        self.line = line

    def __str__(self):
        return self.to_json()

class LeanFile():
    """An Lean node with lean file information"""
    file: str
    lines: list[LeanLineModel]

    def __init__(self, file: str, lineModels: list[CoreLineModel]):
        self.file = file
        lines = []
        length = len(lineModels)
        with open(file, 'r', encoding='utf-8') as file:
            for i, content in enumerate(file, start=0):
                if i < length:
                    lines.append(LeanLineModel(lineModels[i].start, content))
        assert(len(lines) > 0)
        self.lines = lines

    def createFileRange(self, stringRange: CoreStringRange):
        lines = self.lines
        start = LeanFilePos(1, 1)
        stop = LeanFilePos(len(lines) + 1, 1)
        if stringRange is not None:
            if stringRange.start is not None:
                start = LeanFilePos.createFilePos(lines, int(stringRange.start))
            if stringRange.stop is not None:
                stop  = LeanFilePos.createFilePos(lines, int(stringRange.stop))
        return LeanFileRange(start, stop)
    
    def nextPos(self, pos: LeanFilePos):
        if pos is None:
            return None
        length = len(self.lines)
        if length == 0:
            return LeanFilePos(1, 1)
        line = self.lines[pos.line - 1]
        if pos.column < len(line.line):
            return LeanFilePos(pos.line, pos.column + 1)
        if pos.line == length:
            return pos
        return LeanFilePos(pos.line + 1, 1)

    def getTextFromLineModule(self, fileRange: LeanFileRange):
        start_line = fileRange.start.line - 1
        stop_line = fileRange.stop.line - 1
        start_col = fileRange.start.column - 1
        stop_col = fileRange.stop.column
        if start_line < 0 or stop_line >= len(self.lines):
            return ""
        content = self.lines[start_line].line or ""
        if start_line == stop_line:
            return content[start_col:stop_col]
        result = []
        first_line = content
        result.append(first_line[start_col:])
        for i in range(start_line + 1, stop_line):
            result.append(self.lines[i].line or "")
        last_line = self.lines[stop_line].line or ""
        result.append(last_line[:stop_col])
        return "".join(result)

    def remove_comment(self, text: str):
        if text is None:
            return text
        result = []
        i = 0
        depth = 0
        n = len(text)
        while i < n:
            if text[i:i+2] == "/-":
                depth += 1
                i += 2
            elif text[i:i+2] == "-/" and depth > 0:
                depth -= 1
                i += 2
                if depth == 0:
                    result.append(" ")
            else:
                if depth == 0:
                    result.append(text[i])
                i += 1
        text = "".join(result)

        lines = []
        for line in text.split("\n"):
            index = line.find("--")
            if index >= 0:
                line = line[:index]
            if len(line.split()) > 0:
                lines.append(line)
        text = "\n".join(lines)
        return text