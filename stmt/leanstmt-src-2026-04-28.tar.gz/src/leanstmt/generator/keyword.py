
import re
from typing import Optional

# -------------------------------------------------------------------
# 1) Fixed Lean keyword list (your original list had a few missing commas)
# -------------------------------------------------------------------
LEAN_KEYWORDS = [
    "def", "theorem", "lemma", "example",
    "inductive", "structure", "class", "instance",
    "constant", "axiom", "abbrev",
    "variable", "variables",

    "if", "then", "else",
    "match", "nomatch", "with",

    "do", "let", "mut",
    "for", "in", "at",
    "try", "catch", "finally",
    "return", "break", "continue",

    "forall", "exists",
    "fun", "λ",
    "have", "show", "suffices",
    "by", "from",

    "import", "prelude", "namespace", "section", "end",
    "open", "export", "hiding", "renaming",
    "private", "protected", "noncomputable", "unsafe", "partial",

    "infix", "infixl", "infixr",
    "postfix", "prefix",
    "notation",
    "macro",
    "syntax",
    "declare_syntax_cat",

    "intro", "intros",
    "apply", "exact", "refine",
    "cases", "induction",
    "rewrite", "rw",
    "simp", "dsimp", "aesop",
    "refl", "rfl",

    "opaque", "attribute",
    "elab", "elab_rules",
    "sorry",

    "true", "false",
    "cexp",
]

# -------------------------------------------------------------------
# 2) Noise filters for elaboration symbol names
# -------------------------------------------------------------------

# Exact segment names that are usually internal/recursor-ish noise
NOISE_SEGMENT_EXACT = {
    "mk",
    "rec", "recOn", "casesOn", "brecOn",
    "noConfusion", "noConfusionType",
    "below", "ibelow",
    "sizeOf",
    "injEq",
    "proj",
}

# Segment prefixes often used for instances/coercions/internal names
NOISE_SEGMENT_PREFIXES = (
    "inst",   # typeclass instances
    "to",     # coercion helpers like toPreorder, toLE
)

# Substrings often found in generated/internal names
NOISE_SUBSTRINGS = (
    "._proof_",
    ".match_",
    ".eq_",
)

# Optional: if you find these too aggressive, disable them
OPTIONAL_NOISE_SUBSTRINGS = (
    ".proof_",
    "._auxLemma",
)

def split_name_segments(full_name: str) -> list[str]:
    """Split Lean full name by '.' into segments."""
    return [seg for seg in full_name.split(".") if seg]

def is_noise_name(full_name: str, aggressive: bool = False) -> bool:
    """
    Heuristic filter for elaboration noise declarations.
    Returns True if this name is likely instance/coercion/internal noise.
    """
    if not full_name:
        return True

    # Substring checks on whole name
    for sub in NOISE_SUBSTRINGS:
        if sub in full_name:
            return True
    if aggressive:
        for sub in OPTIONAL_NOISE_SUBSTRINGS:
            if sub in full_name:
                return True

    segments = split_name_segments(full_name)
    for seg in segments:
        if seg in NOISE_SEGMENT_EXACT:
            return True

        # Prefix-based checks
        for pref in NOISE_SEGMENT_PREFIXES:
            if seg.startswith(pref) and len(seg) > len(pref):
                return True

    return False

# -------------------------------------------------------------------
# 3) Candidate scoring (recommended instead of hard drop only)
# -------------------------------------------------------------------

def score_symbol(
    full_name: str,
    src_name: Optional[str],
    has_range: bool,
    prefix_reason: Optional[str],
) -> int:
    """
    Higher score = more likely user-facing symbol for rewrite.
    """
    score = 0

    # Strong positive signals
    if prefix_reason == "prefix .":
        score += 5
    if src_name is not None:
        score += 3
    if has_range:
        score += 2

    # Penalize likely noise
    if is_noise_name(full_name, aggressive=False):
        score -= 6

    return score
