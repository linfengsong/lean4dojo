from dataclasses import dataclass
from leanstmt.generator.lean_module import LeanModule
from .lean_file import LeanFilePos, LeanFileRange

Lean_keywords = [
    "def", "theorem", "lemma", "example",
    "inductive", "structure", "class", "instance",
    "constant", "axiom", "abbrev",
    "variable", "variables",
    "if", "then", "else",
    "match", "nomatch", "with",
    "do", "let", "mut",
    "for", "in", "at",
    "try", "catch", "finally",
    "return", "break", "continue",
    "forall", "exists",
    "fun", "λ",
    "have", "show", "suffices",
    "by",
    "from",
    "import", "prelude", "namespace", "section", "end",
    "open", "export", "hiding", "renaming",
    "private", "protected", "noncomputable", "unsafe", "partial",

    "infix", "infixl", "infixr",
    "postfix", "prefix",
    "notation",
    "macro",
    "syntax",
    "declare_syntax_cat", 
    "intro", "intros",
    "apply", "exact", "refine",
    "cases", "induction",
    "rewrite", "rw",
    "simp", "dsimp", "aesop",
    "refl", "rfl",
    "abbrev",
    "opaque","axiom", "constant",
    "attribute",
    "elab", "elab_rules", 
    "sorry",
    "forall", "exists",
    "true", "false" 
    "cexp",
]

class ExclusiveConfig: 
    def __init__(self, data: dict[str, list[str]]):
        self.config: dict[str, list[str]] = data

    def getConfigList(self, name: str):
        if self.config is None:
            return None
        return self.config[name] if name in self.config.keys() else None

@dataclass(frozen=True)
class ContextText:
    text: str
    comment: str
    pos: LeanFilePos
    blockIndex: int = None

@dataclass(frozen=True)
class DependentStatement:
    fileRange: LeanFileRange
    dependentStatements: list

class LeanCreateModule:
    alter_namespace: str = "LeanTest"

    def __init__(self, exclusiveConfig: ExclusiveConfig, module_name: str, module: LeanModule):
        self.exclusiveConfig = exclusiveConfig
        self.module_name = module_name
        self.module = module

        statement_full_name_dict, irreducible_def_name_dict = self._get_statement_name_dict()
            
        self._statements = []
        module_persistant_symbol_name_dict = {}
        from .lean_create_statement import LeanCreateStatement
        for statement in module.statements:
            statementSymbol = self.module.getStatementSymbol(statement)
            dependent_statements = self._get_dependent_statements_from_symbols(statement_full_name_dict, statementSymbol)
            persistant_symbol_name_dict = self._get_persistant_symbol_name_dict(
                   self._get_private_symbol_names(statementSymbol), irreducible_def_name_dict)
            for name in persistant_symbol_name_dict.keys():
                if not name in module_persistant_symbol_name_dict.keys():
                    module_persistant_symbol_name_dict[name] = persistant_symbol_name_dict[name]
            stmt = LeanCreateStatement(self, statement, persistant_symbol_name_dict.keys(), dependent_statements)
            self._statements.append(stmt)

        if len(module_persistant_symbol_name_dict) > 0:
            self._dependent_statements_for_persistant_symbol(module_persistant_symbol_name_dict)
            self.persistant_symbol_name_dict = module_persistant_symbol_name_dict

    def getStatements(self):
        return self._statements
    
    def getStatement(self, id):
        iId = int(id)
        if iId >= 0  and iId < len(self._statements):
            return self._statements[iId]
        return None
    
    def getScopeRangeInfos(self):
        return self.module.getScopeRangeInfos()
    
    def getCreateStatements(self):
        statements = []
        for statement in self._statements:
            if statement.statement.kind != "theorem":
                continue
            if statement.statement.is_private():
                continue
            statements.append(statement)
        return statements
    
    def getStatementSymbol(self, statement):
        return self.module.getStatementSymbol(statement.statement)
    
    def getContextEntries(self):
        return self.module.getContextEntries()
    
    def getLeanFile(self):
        return self.module.getLeanFile()
    
    def getImports(self):
        return self.module.getImports()
    
    def getDependentStatements(self, statement, file):
        include_ids = set()
        include_ids.add(statement.id)
        required_ids = set()
        required_symbol_names = set()
        self._get_dependent_statements(statement, include_ids, required_ids, required_symbol_names, file)
        self._add_private_statements(statement, include_ids, set(), file)
        if file: print(f"dependent_statements for statement: {statement.name}, id: {statement.id}, include_ids: {include_ids}", file=file)
        return include_ids

    def _get_dependent_statements(self, statement, include_ids, required_ids, required_symbol_names, file):        
        request_start = statement.statement.fileRange.start
        request_id = statement.id
        if request_id in required_ids:
            return
        required_ids.add(request_id)
        if file: print(f"    processing statement: {statement.name}, {statement.get_full_name()} kind: {statement.kind}, id: {request_id}, dependent_statements: {statement.dependent_statements}, persistant_symbol_names: {statement.persistant_symbol_names}", file=file)
        for stmt_id in statement.dependent_statements:
            stmt = self.getStatement(stmt_id)
            if stmt.statement.fileRange.start < request_start:
                self._get_dependent_statements(stmt, include_ids, required_ids, required_symbol_names, file)
            if stmt_id in include_ids and not stmt.statement.is_private() and not request_id in include_ids:
                include_ids.add(request_id)
                if file: print(f"       dependent_statement add: {statement.name}, stmt_id: {stmt_id} in include_ids, request_id: {request_id}", file=file)

        for name in statement.persistant_symbol_names:
            if name in required_symbol_names:
                continue
            statements = self.persistant_symbol_name_dict[name].dependentStatements
            required_symbol_names.add(name)
            if len(statements) > 0:
                if file: print(f"        persistant_symbol_names add: {statement.name}, stmt_id: {request_id}", file=file)
                if not request_id in include_ids:
                    include_ids.add(request_id)
                    if request_id in required_ids:
                        required_ids.remove(request_id)
            for stmt_id in statements:
                if not stmt_id in include_ids:
                    if file: print(f"        persistant_symbol_names add: {statement.name}, stmt_id: {stmt_id}", file=file)
                    stmt = self.getStatement(stmt_id)
                    if stmt.statement.fileRange.start < request_start:
                        include_ids.add(stmt_id)
                        self._get_dependent_statements(stmt, include_ids, required_ids, required_symbol_names, file)
        if file: print(f"      finish processing statement: {statement.name}, request_id: {request_id}", file=file)

    def _add_private_statements(self, statement, include_ids, required_ids, file):
        request_id = statement.id
        needPrivate = request_id in include_ids
        for stmt_id in statement.dependent_statements:
            if request_id == stmt_id or stmt_id in required_ids:
                continue
            required_ids.add(stmt_id)
            stmt = self.getStatement(stmt_id)
            if needPrivate and stmt.statement.is_private() and not stmt_id in include_ids:
                include_ids.add(stmt_id)
                if file: print(f"    add private statement: {statement.name}, stmt_id: {stmt_id} from statement: {request_id}", file=file)
            self._add_private_statements(stmt, include_ids, required_ids,file)
        

    def _get_all_reference_ids(self, statement):
        all_ref_ids = set()
        for id in statement.reference_statements:
            if id == statement.id:
                continue
            if not id in all_ref_ids:
                all_ref_ids.add(id)
            stmt = self.getStatement(id)
            ref_ids = self._get_all_reference_ids(stmt)
            for ref_id in ref_ids:
                if not ref_id in all_ref_ids:
                    all_ref_ids.add(ref_id)
        return all_ref_ids
    
    def _get_statement_name_dict(self):
        statement_full_name_dict = {}
        irreducible_def_name_dict = {}
        
        for statement in self.module.statements:
            full_name = statement.get_full_name()
            if full_name:
                if full_name in statement_full_name_dict.keys():
                    dependentStatement = statement_full_name_dict[full_name]
                else:
                    dependentStatement = DependentStatement(statement.fileRange, [])
                    statement_full_name_dict[full_name] = dependentStatement
                dependentStatement.dependentStatements.append(statement.id)
            if statement.kind == "irreducible_def":
                dependentStatement = DependentStatement(statement.fileRange, [])
                irreducible_def_name_dict[full_name] = dependentStatement
                name = statement.name
                irreducible_def_name_dict[name] = dependentStatement
                if name in statement_full_name_dict.keys():
                    dependentStatement = statement_full_name_dict[name]
                else:
                    dependentStatement = DependentStatement(statement.fileRange, [])
                    statement_full_name_dict[name] = dependentStatement
                dependentStatement.dependentStatements.append(statement.id)
        return statement_full_name_dict, irreducible_def_name_dict

    def _get_dependent_statements_from_symbols(self, statement_full_name_dict, statement_symbol):
        dependent_statements = set()
        if statement_symbol is None:
            return dependent_statements
        statements = set()
        if statement_symbol.signature_symbols:
            for symbol in statement_symbol.signature_symbols:
                stmts = self._get_match_statements(statement_full_name_dict, symbol)
                for stmt in stmts:
                    if not stmt in statements:
                        statements.add(stmt)
        if statement_symbol.value_symbols:
            for symbol in statement_symbol.value_symbols:
                stmts = self._get_match_statements(statement_full_name_dict, symbol)
                for stmt in stmts:
                    if not stmt in statements:
                        statements.add(stmt)
        return statements
    
    def _get_match_statements(self, statement_full_name_dict, symbol):
        if symbol.src_name is None:
            return 
        match_full_name = None
        match_index = -1
        for stmt_full_name in statement_full_name_dict.keys():
            stmt_fileRange = statement_full_name_dict[stmt_full_name].fileRange
            if symbol.range.start < stmt_fileRange.start:
                continue
            stmt_name_parts = stmt_full_name.split(".")
            symbol_name_parts = symbol.src_name.split(".")
            for index, part in enumerate(reversed(stmt_name_parts)):
                if len(symbol_name_parts) <= index:
                    break
                if part == symbol_name_parts[index-1]:
                    if match_index < index:
                        match_full_name = stmt_full_name
                        match_index = index
                else:
                    break
        if match_full_name:
            return statement_full_name_dict[match_full_name].dependentStatements
        return set()
    
    def _get_private_symbol_names(self, statementSymbol):
        names = set()
        if statementSymbol == None:
            return names
        if statementSymbol.signature_symbols:
            for symbol in statementSymbol.signature_symbols:
                if symbol.is_private:
                    if not symbol.name in names:
                        names.add(symbol.name)
        if statementSymbol.value_symbols:
            for symbol in statementSymbol.value_symbols:
                if symbol.is_private:
                    if not symbol.name in names:
                        names.add(symbol.name)
        return names
        
    def _get_persistant_symbol_name_dict(self, symbol_names, share_name_dict):
        share_symbol_name_dict = {}
        if symbol_names is None or len(symbol_names) == 0:
            return share_symbol_name_dict
        for name in symbol_names:
            for share_name in share_name_dict.keys():   
                if name.endswith(share_name):
                    share_symbol_name_dict[name] = share_name_dict[share_name]
        return share_symbol_name_dict

    def _get_content_entry_name(self, kind, entry_content):
        entry_content = entry_content.replace("\n", " ").replace("\t", " ").replace("\r", " ").replace("()", " ").replace("[", " ")
        parts = entry_content.split(" " + kind + " ")
        if len(parts) < 2:
            return None
        if not (" private "  in " " + parts[0] + " "):
            return None
        parts = parts[1].split(" ")
        if len(parts) < 2:
            return None
        return parts[0].strip()
    
    def _dependent_statements_for_persistant_symbol(self, persistant_symbol_name_dict):
        for stmt in self._statements:
            statement_symbol = self.getStatementSymbol(stmt)
            symbol_names = set()
            if statement_symbol:
                for symbol in statement_symbol.signature_symbols:
                    if symbol.name in persistant_symbol_name_dict.keys() and not symbol.name in symbol_names:
                        symbol_names.add(symbol.name)
                for symbol in statement_symbol.value_symbols:
                    for persistant_symbol_name in persistant_symbol_name_dict.keys():
                        if symbol.name.endswith(persistant_symbol_name): 
                            if not persistant_symbol_name in symbol_names:
                                symbol_names.add(persistant_symbol_name)
            for name in symbol_names:
                dependentStatements = persistant_symbol_name_dict[name].dependentStatements

                if not stmt.id in dependentStatements:
                    dependentStatements.append(stmt.id)
