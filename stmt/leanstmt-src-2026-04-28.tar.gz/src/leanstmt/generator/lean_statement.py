import logging
from dataclasses import dataclass
from dataclasses_json import dataclass_json
from ..core.core_datasets import CoreDeclaration
from .lean_file import LeanFileRange
from .lean_elab import TacticProof, find_tactricProof, find_term_node_name

@dataclass_json
@dataclass(frozen=True)
class Attribute:
    kind: str
    name: str
    content: str
    fileRange: LeanFileRange

@dataclass_json
@dataclass(frozen=True)
class ScopeInfo:
    var_decls: list[str]
    include_vars: list[str]
    omit_vars: list[str]
    namespace: str
    open_decl: list[str]
    scoped_open_decl: list[str]

@dataclass_json
@dataclass(frozen=True)
class Modifiers:
    visibility: str
    attrs: list[Attribute]
    compute_kind: str
    rec_kind: str
    is_unsafe: bool
    docstring: str = None
    rec_kind_left: str = None
    rec_kind_right: str = None

@dataclass_json
@dataclass(frozen=True)
class BaseStatement:
    content: str
    fileRange: LeanFileRange

    id: str
    name: str

    internal_name: list[str]
    internal_namespace: str

    scope_info: ScopeInfo
    modifiers: Modifiers

    signature: str
    signatureRange: LeanFileRange

    def is_private(self):
        return self.modifiers and self.modifiers.visibility == "private"
    

@dataclass_json
@dataclass(frozen=True)
class IrreducibleDef(BaseStatement):

    @property
    def kind(self):
        return "irreducible_def"
    
    @property
    def command(self):
        return "irreducible_def"
    
    def __post_init__(self):
        pass
    
    def get_full_name(self):
        print(f"contest: {self.content}, name: {self.name}, internal_name: {self.internal_name}, internal_namespace: {self.internal_namespace}")
        return self.name + "_def"
    
@dataclass_json
@dataclass(frozen=True)
class Statement(BaseStatement):

    coreDeclaration: CoreDeclaration

    @property
    def kind(self):
        return self.coreDeclaration.kind
    
    @property
    def command(self):
        pass

    def __post_init__(self):
        pass

    def get_full_name(self):
        if self.name is None:
            return None
        name_parts = self.name.split(".")
        namespace_parts = self.internal_namespace.split(".") if self.internal_namespace else []
        for i, name_part in enumerate(name_parts):
            if i < len(namespace_parts):
                if name_part == namespace_parts[-i -1]:
                    namespace_parts = namespace_parts[:-i]
                else:
                    break
            else:
                break
        full_name = ".".join(name_parts)
        if len(namespace_parts) > 0:
            full_name = ".".join(namespace_parts) + "." + full_name
        return full_name
    


    def get_header_content(self):
        length = 0
        if hasattr(self, "signature") and self.signature:
            length = len(self.signature)
        if hasattr(self, "value") and self.value:
            length += len(self.value)
        content = self.content[:-length].replace("\t", " ").replace("\r", "").replace("\n", " ")
        if "@[" in content:
            index = content.rfind("]")
            if index >=0:
                content = content[index + 1:]
        return content
    
    def setup_rec_kind(self, header_content: str, rec_kinds: list, command_left: bool = True):
        command_str = f" {self.command} "
        start_index = header_content.find(command_str)
        if start_index > 0:
            if command_left:
                portion = " " + header_content[:start_index + 1]
            else:
                portion = " " + header_content[start_index + len(command_str):]
            if len(portion.strip()) > 0:
                for rec_kind in rec_kinds:
                    if f" {rec_kind} " in portion:
                        if command_left:
                            object.__setattr__(self.modifiers, "rec_kind_left", rec_kind)
                        else:
                            object.__setattr__(self.modifiers, "rec_kind_right", rec_kind)

    def setup_visibility(self, header_content: str):
        header_content = " " + header_content
        visibility = None
        if " private " in header_content:
            visibility = "private"
        elif " protected " in header_content:
            visibility = "protected"
        elif " public " in header_content:
            visibility = "public"
        if visibility and self.modifiers.visibility is None:
            object.__setattr__(self.modifiers, "visibility", visibility)
                        
@dataclass_json
@dataclass(frozen=True)
class Abbrev(Statement):    
    value: str
    valueRange: LeanFileRange

    @property
    def command(self):
        return "abbrev"

    def __post_init__(self):
        header_content = self.get_header_content()
        self.setup_visibility(header_content)
    
@dataclass_json
@dataclass(frozen=True)
class Axiom(Statement):

    @property
    def command(self):
        return "axiom"
    
@dataclass_json
@dataclass(frozen=True)
class ClassInductive(Statement):
    value: str
    valueRange: LeanFileRange

    @property
    def command(self):
        return "class inductive"
    
    def __post_init__(self):
        header_content = self.get_header_content()
        self.setup_rec_kind(header_content, ["local", "scoped"])
        self.setup_visibility(header_content)
    
@dataclass_json
@dataclass(frozen=True)
class Declaration(Statement):
    value: str
    valueRange: LeanFileRange

    is_irreducible: bool = False

    def __post_init__(self):
        header_content = " " + self.get_header_content()
        if " irreducible_def " in header_content:
            object.__setattr__(self, 'is_irreducible', True)
        self.setup_visibility(header_content)

    @property
    def command(self):
        if self.is_irreducible:
            return "irreducible_def"
        else:
            return "def"

@dataclass_json
@dataclass(frozen=True)
class Example(Statement):
    value: str
    valueRange: LeanFileRange

    @property
    def command(self):
        return "example"

@dataclass_json
@dataclass(frozen=True)
class Inductive(Statement):
    value: str
    valueRange: LeanFileRange

    @property
    def command(self):
        return "inductive"
    
    def __post_init__(self):
        header_content = self.get_header_content()
        self.setup_visibility(header_content)

@dataclass_json
@dataclass(frozen=True)
class Instance(Statement):
    value: str
    valueRange: LeanFileRange

    @property
    def command(self):
        return "instance"

    def __post_init__(self):
        header_content = self.get_header_content()
        command_str = f" {self.command} "
        start_index = header_content.find(command_str)
        if header_content:
            right_portion = header_content[start_index + len(command_str):].strip()
            if right_portion.startswith("("):
                object.__setattr__(self, 'name', None)

        self.setup_rec_kind(header_content, ["local", "scoped"])
        self.setup_visibility(header_content)

@dataclass_json
@dataclass(frozen=True)
class Opaque(Statement):
    value: str
    valueRange: LeanFileRange

    @property
    def command(self):
        return "opaque"
    
    def __post_init__(self):
        header_content = self.get_header_content()
        self.setup_visibility(header_content)

@dataclass_json
@dataclass(frozen=True)
class Structure(Statement):
    value: str
    valueRange: LeanFileRange

    is_class: str = False

    def __post_init__(self):
        header_content = " " + self.get_header_content()
        if " class " in header_content:
            object.__setattr__(self, 'is_class', True)
        self.setup_visibility(header_content)
        self.setup_rec_kind(header_content, ["abbrev"], False)

    @property
    def command(self):
        if self.is_class:
            return "class"
        else:
            return "structure"

@dataclass_json
@dataclass(frozen=True)
class Variable(Statement):

    @property
    def command(self):
        return "variable"

@dataclass_json
@dataclass(frozen=True)
class ProofWanted(Statement):
    value: str
    valueRange: LeanFileRange

    is_lemma: bool = False

    @property
    def command(self):
        return "proof_wanted"

    def __post_init__(self):
        header_content = self.get_header_content()
        if " lemma " in " " + header_content:
            object.__setattr__(self, 'is_lemma', True)
        self.setup_visibility(header_content)

@dataclass_json
@dataclass(frozen=True, eq=False)
class Theorem(Statement):
    value: str
    valueRange: LeanFileRange

    proofOperator: str
    proofType: str
    
    tacticProof: TacticProof
    refTacticProofs: list[TacticProof]

    term_before: list

    is_lemma: bool = False

    @property
    def command(self):
        if self.is_lemma:
            return "lemma"
        else:
            return "theorem"
    
    def __post_init__(self):
        header_content = self.get_header_content()
        if " lemma " in " " + header_content:
            object.__setattr__(self, 'is_lemma', True)
        self.setup_visibility(header_content)

    @staticmethod
    def _getToken(line: str, index: int):
        tokens = line.strip().replace("\n", " ").replace("\r", " ").replace("\t", " ").split()
        if index < 0:
            index = len(tokens) + index
        if index >= len(tokens):
            return None
        return tokens[index]

    @classmethod
    def create(cls, content, fileRange, id, name, internal_name, internal_namespace, scope_info, modifiers, signature, signatureRange, decl, 
                    value, valueRange, tacticProofs, terms):
        proofOperator = Theorem._getToken(value, 0)
        if proofOperator and proofOperator.startswith(":="):
            proofOperator = ":="
        assert(proofOperator == ":=" or proofOperator == "|" or proofOperator == "where"), f"proofOperator: {proofOperator}, signature: |{signature}|, value: |{value}|, signatureRange: {signatureRange}, valueRange: {valueRange},"

        proof = value[len(proofOperator):]
        startBy = True
        byToken = Theorem._getToken(proof, 0)
        if byToken is None or byToken != "by":
            startBy = False
    
        tacticProofs = find_tactricProof(valueRange, tacticProofs) if valueRange else None
        term_before = None
        tacticProof = None
        proofType = "Term"
        refTacticProofs =None
        if startBy:
            proofType = "Tactic"
            if len(tacticProofs) > 0:
                tacticProof = tacticProofs.pop(0)
            else:
                # when proof content is only MACRO, it does not have tactic generated in Lean
                # it needs fix
                pure_proof = " ".join(proof.replace("\n"," ").replace("\t"," ").split(" "))
                if " " in pure_proof:
                    logging.info(f"ERROR cannot find tacticProof: {name} theorem_proof: {value}")

        if len(tacticProofs) > 0:
            refTacticProofs = tacticProofs
        if tacticProof is None:
            term = find_term_node_name(fileRange, name, terms)
            if term is not None:
                term_before = term.type
            elif startBy:
                logging.info(f"ERROR tactic_before is none on Tactic: {name}")

        return Theorem(content, fileRange, id, name, internal_name, internal_namespace, scope_info, modifiers, signature, signatureRange, decl, 
                   value, valueRange, proofOperator,  proofType, tacticProof, refTacticProofs, term_before)

