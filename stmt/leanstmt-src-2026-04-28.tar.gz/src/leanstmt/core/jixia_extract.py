import os
import json
from enum import StrEnum
from typing import Optional, Iterable
from pathlib import Path
from argparse import ArgumentParser
import logging
from .abstruct_extract import AbstructExtract

class Plugin(StrEnum):
    MOD = "mod"
    DECL = "decl"
    SYM = "sym"
    ELAB = "elab"
    LINE = "line"
    AST = "ast"
    CONTEXT = "ctx"

class BuildProject(AbstructExtract):
    output_path: Path
    overwrite: bool
    run_initializers: bool

    def __init__(self, root_dir: str, jixia_path=".jixia", output_path: str = ".jixia", overwrite: bool = False,
                 max_workers: int = os.cpu_count(), run_initializers: bool = True):
        super().__init__(root_dir, [jixia_path], max_workers)
        self.root_path = Path(root_dir).resolve()
        out_p = Path(output_path)
        self.output_path = out_p.resolve() if out_p.is_absolute() else (self.root_path / out_p).resolve()
        self.output_path.mkdir(exist_ok=True, parents=True)
        self.overwrite = overwrite
        self.run_initializers = run_initializers

    def execute_tasks(self, search_list):
        module_locations = self.find_module_locations(search_list)
        return [(key, value) for key, value in module_locations.items()]

    def execute_args(self, module_name: str, args):
        exec_args = []
        if self.run_initializers:
            exec_args.append("-i")
        need_run = False
        for arg in args:
            str_arg = f"{arg}"
            output_file = self.output_path / Path(f"{module_name}.{str_arg}.json")
            if self.overwrite or not output_file.exists():
                exec_args.extend(["-" + str_arg[0], str(output_file)])
                need_run = True
        return exec_args if need_run else None
    
    def jixia_build(self,
                    search_list: Optional[list] = None,
                    plugins: Iterable[Plugin] = list(Plugin)) -> list:

        return self.batch_build(search_list, plugins)

def main():
    parser = ArgumentParser()
    parser.add_argument("project_root", default=None, help="Project to be indexed")
    parser.add_argument("--jixia_path", default="jixia", help="e.g., jixia")
    parser.add_argument("--search_list", default="", help="e.g., Init,Mathlib")
    parser.add_argument("--overwrite", default=True, help="overwrite when json file existing. e.g., True")
    parser.add_argument("--log_file", default="build.log", help="e.g., build.log")
    parser.add_argument("--log_mode", type=str, choices=["Info", "Debug"], default="Info", help="Log detail mode")
    args = parser.parse_args()

    log_level = logging.DEBUG if args.log_mode == "Debug" else logging.INFO
    log_format = '%(asctime)s - %(levelname)s - %(message)s'
    logging.basicConfig(
        level=log_level,
        format=log_format,
        handlers=[
            logging.FileHandler("build.log"),
            logging.StreamHandler()
        ]
    )

    logging.info(f"project_root: {args.project_root}")
    logging.info(f"jixia_path: {args.jixia_path}")
    logging.info(f"search_list: {args.search_list}")
    logging.info(f"overwrite: {args.overwrite}")
    logging.info(f"log_file: {args.log_file}")

    log_path = Path(args.project_root) / Path("jixia_json.log")
    Path(log_path).unlink(missing_ok=True)

    project = BuildProject(args.project_root, jixia_path=args.jixia_path, overwrite=args.overwrite)
    plugins=[Plugin.MOD, Plugin.DECL, Plugin.SYM, Plugin.LINE, Plugin.AST, Plugin.ELAB, Plugin.CONTEXT]

    search_list = [p.strip() for p in args.search_list.split(",")]
    if len(search_list) == 0:
        search_list = ["Init,Mathlib,LeanTest",
                       "Mathlib.Data.Prod.Basic"]
    elif len(search_list) == 1 and search_list[0] == "TEST":
        search_list = [
            "Init.Try",
            "Init.Data.Array.Lemmas",
            "Init.Data.Cast",
            "Init.Data.Nat.Div.Basic",
            "Init.Data.Nat.Power2",
            "Init.Data.Option.Array",
            "Init.Data.RArray",
            "Init.Data.Sum.Lemmas",
            "Init.Data.Vector.Extract",
            "Init.GetElem",
            "Init.Grind.Ordered.Module",
            "Init.Meta.Defs",
            "Init.Prelude",
            "Init.Omega.LinearCombo",
            "Mathlib.CategoryTheory.Monoidal.Cartesian.CommGrp_",
            "Mathlib.Data.EReal.Operations",
            "Mathlib.Data.List.Chain",
            "Mathlib.Data.Nat.Init",
            "Mathlib.Data.Finset.NAry",
            "Mathlib.Data.Finsupp.Interval",
            "Mathlib.Data.Set.Basic",
            "Mathlib.Data.Sym.Basic",
            "Mathlib.MeasureTheory.SetAlgebra",
            "Mathlib.MeasureTheory.PiSystem",
            "Mathlib.MeasureTheory.Constructions.BorelSpace.Basic",
            "Mathlib.MeasureTheory.Constructions.HaarToSphere",
            "Mathlib.MeasureTheory.Constructions.Pi",
            "Mathlib.MeasureTheory.Constructions.Polish.Basic",
            "Mathlib.MeasureTheory.Constructions.SubmoduleQuotient",
            "Mathlib.MeasureTheory.Constructions.Projective",
            "Mathlib.MeasureTheory.Function.AEEqFun",
            "Mathlib.MeasureTheory.Function.AEEqFun.DomAct",
            "Mathlib.MeasureTheory.Function.SpecialFunctions.Inner",
            "Mathlib.MeasureTheory.Measure.GiryMonad",
            "Mathlib.MeasureTheory.Measure.Dirac",
            "Mathlib.MeasureTheory.OuterMeasure.Basic",
            "Mathlib.Algebra.Algebra.Subalgebra.Basic",
            "Mathlib.Algebra.Category.CommAlgCat.Monoidal",
            "Mathlib.Algebra.Category.MonCat.Colimits",
            "Mathlib.Analysis.Calculus.ContDiff.FTaylorSeries",
            "Mathlib.Analysis.NormedSpace.Alternating.Uncurry.Fin",
            "Mathlib.Analysis.SpecialFunctions.Log.Basic"
            "Mathlib.CategoryTheory.Limits.HasLimits",
            "Mathlib.GroupTheory.GroupAction.Primitive",
            "Mathlib.LinearAlgebra.Dimension.Localization",
            "Mathlib.LinearAlgebra.CliffordAlgebra.Even",
            "Mathlib.Order.DirectedInverseSystem",
            "Mathlib.RingTheory.TensorProduct.Basic", 
            "Mathlib.RingTheory.RingHom.Locally",
            "Mathlib.Tactic.MoveAdd",
            "Mathlib.Tactic.Hint",
            "Mathlib.Tactic.Widget.LibraryRewrite",
            "Mathlib.Tactic.Widget.Calc",
            "Mathlib.Topology.ContinuousMap.Bounded.Normed",
            "Mathlib.Topology.Order.LeftRightNhds",
            "Mathlib.Util.Export",
            "Mathlib.Util.MemoFix",
        ]

    elif len(search_list) == 1 and search_list[0] == "TEST2":
        search_list = ["Mathlib.MeasureTheory",
                       "Mathlib.Data",
                       "Mathlib.Analysis"]
        
    search_list2 = [
        "Mathlib.MeasureTheory.Constructions.BorelSpace.Metric",
        "Mathlib.MeasureTheory.Function.ConditionalExpectation.AEMeasurable",
        "Mathlib.MeasureTheory.Function.SimpleFuncDenseLp",
        "Mathlib.MeasureTheory.MeasurableSpace.Embedding",  # test need add _root_.
        "Mathlib.MeasureTheory.Function.ConvergenceInMeasure",
        "Mathlib.MeasureTheory.Constructions.BorelSpace.Metric",
        "Mathlib.MeasureTheory.Function.L1Space.Integrable",
        "Mathlib.MeasureTheory.Integrable",
        "Mathlib.MeasureTheory.Integral.TorusIntegral",
        "Mathlib.MeasureTheory.Integral.Marginal",
        "Mathlib.MeasureTheory.Constructions.Polish.Basic",
        "Mathlib.GroupTheory.GroupAction.Hom",
        "Mathlib.Data.Quot",
        "Mathlib.Data.Finmap",
        "Mathlib.Data.Finsupp.Defs", #irreducible_def
        "Mathlib.Data.Finsupp.SMul",
        "Mathlib.Data.Rel",  #missing @[inherit_doc] scoped infixl:62 " ○ " => comp. fix to remove scopd notation
        "Mathlib.Data.Complex.Basic", #extra: @[inherit_doc] notation "ℂ" => Complex. fixed but other issue break
        "Mathlib.Data.Set.Card", #extra: macro_rules, fixed but other issue break. need replace simpl with rw
        "Mathlib.GroupTheory.Torsion", #extra: attribute [deprecated IsMulTorsionFree 
                                       #       @[to_additive (attr := deprecated Pi.instIsMulTorsionFree fixed but other break
        "Mathlib.GroupTheory.Sylow", # when call theoren self. it use @<current method name> @exists_subgroup_card_pow_prime_le _ _ n (m - 1) _ to @test_exists_subgroup_card_pow_prime_le _ _ n (m - 1) _#
        "Mathlib.GroupTheory.Coxeter.Length",   #local prefix:100 "ℓ" => cs.length
        "Mathlib.Algebra.Group.Even", #@[to_additive (attr := aesop safe) Even.two_nsmul]
        "Mathlib.Algebra.Group.Center", ##@[to_additive]
        "Mathlib.Algebra.Order.Group.DenselyOrdered", # private theorem using in theorem body
        "Mathlib.Algebra.Group.Submonoid.Operations", # when namespace end, it should not add open that namespace
        "Mathlib.Algebra.Order.Monoid.Units", # extra: rfl
        "Mathlib.Algebra.Star.RingQuot", #private irreducible_def
        "Mathlib.NumberTheory.NumberField.FinitePlaces",
        "Mathlib.MeasureTheory.MeasurableSpace.Defs",
        "Mathlib.NumberTheory.Cyclotomic.Three",
        "Mathlib.AlgebraicGeometry.Spec",
        "Mathlib.MeasureTheory.Constructions.BorelSpace.Metric",
        "Mathlib.MeasureTheory.Function.AEEqFun",
        "Mathlib.Topology.Order.DenselyOrdered",
        "Mathlib.MeasureTheory.Function.L1Space.HasFiniteIntegral", # missing namespace: MeasureTheory.HasFiniteIntegral HasFiniteIntegral.enorm, test self call as well
        "Mathlib.MeasureTheory.OuterMeasure.Caratheodory", #Need call self: isCaratheodory_iUnion_lt to test_isCaratheodory_iUnion_lt, problem cannot find range for this case to fix
        "Mathlib.NumberTheory.JacobiSum.Basic", # section only for variable and not for others. so private should be in lean file scope
        "Mathlib.Data.ENNReal.Inv",
        "Mathlib.Algebra.Star.SelfAdjoint", # fix marco with <name>(n) syntax error
        "Mathlib.Analysis.Asymptotics.LinearGrowth", #namespace before open issue, it could test marco with <name>(n) fix as well

        "Mathlib.MeasureTheory.Measure.Lebesgue.EqHaar", # need root on parallelepiped 
        "Mathlib.MeasureTheory.Covering.Differentiation",  # #adaptation_note /-- .-/
        "Mathlib.Data.TypeVec", #@[typevec] does not allow
        "Mathlib.Data.Finset.Card", #grind issue
        "Mathlib.Topology.MetricSpace.Polish", # open namespace fail. there is no such namespace
        "Mathlib.Topology.Algebra.StarSubalgebra", # multiple in statement
        "Mathlib.Topology.Algebra.Order.Floor", # ceil symbol not match
        "Mathlib.Topology.Compactness.Compact", # fail to add symbol namespace, Function.compl ∘ t
        "Mathlib.Order.CompleteBooleanAlgebra", # two namespace conflict
        "Mathlib.RepresentationTheory.Basic", # two namespace conflict, namespace issue fix, it still has simp problem
        "Mathlib.RepresentationTheory.Homological.GroupCohomology.Functoriality", #elementwise (attr := simp)]
        "Mathlib.Algebra.Lie.UniversalEnveloping", # replace sign symbo

        "Mathlib.Algebra.BigOperators.Group.Finset.Defs", #private inductive
        "Mathlib.MeasureTheory.Measure.LevyProkhorovMetric",# remove module import work, problem is symbol and need add: lean_notation = f'local notation:25 {src_template}:25 => {name} α β' to and it can handle "→ᵇ"
        "Mathlib.Algebra.Order.BigOperators.Ring.Finset", # private alias, fix but different error
        "Mathlib.CategoryTheory.Sites.Coherent.SequentialLimit", #structure
        "Mathlib.Algebra.Group.UniqueProds.Basic", # abbrev, other problem class member cannot access UniqueProds at structure, it need add symbol replacement to check if name start with strucure name
        "Mathlib.Util.Export", #opaque, works but no theorem
        "Mathlib.Data.Fintype.Fin", # need restrict: open <namespace> (something)
        "Mathlib.Data.Fintype.Sum", # not allow add namepsace on introduction. error: replace symbol with open conflict:
        "Mathlib.Data.Fintype.EquivFin", # replace private def symbole
        "Mathlib.Data.Sign.Defs",
        "Mathlib.Data.Finsupp.BigOperators",
        "Mathlib.Data.TypeVec", #@[typevec, remove
        "Mathlib.Data.Fintype.BigOperators", #rfl not replace
        "Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic", # symbol add _root_
        "Mathlib.MeasureTheory.Integral.Bochner.L1", # symbol include after current statement to match
        "Mathlib.MeasureTheory.VectorMeasure.Decomposition.Lebesgue", #private symbol load

        "Mathlib.Data.Finset.Card" #grind
        "Mathlib.Data.Nat.Squarefree",
        "Mathlib.Data.Nat.Factorization.PrimePow", # test @ of symbol
        "Mathlib.Data.Nat.Factorial.Basic", # statement name has "." to allow access same "." pattern resource
        "Mathlib.Data.Real.Basic", # multiple statement using same private local declarations
        "Mathlib.Data.Option.NAry", # attribute local test
        "Mathlib.MeasureTheory.Measure.WithDensityFinite", # Attribute local as private statement
        "Mathlib.MeasureTheory.Integral.Lebesgue.Countable", # | @abc not replace
        "Mathlib.MeasureTheory.Measure.Haar.NormedSpace",
    ]
    search_list.extend(search_list2)

    print(f"Start building project at {project.root_path} with plugins: {plugins} and search_list: {len(search_list)}")
    results = project.jixia_build(
        search_list=search_list,
        plugins=plugins,
    )
    logging.debug(f"Results for {project.root_path} with plugins: {plugins}:")
    try:
        logging.debug(json.dumps(results, indent=2))
    except:
        logging.debug(results)

if __name__ == "__main__":
    main()
    # python -m leanstmt.core.jixia_extract "/home/linfe/math/lean_test" --search_list TEST
    #  python -m leanstmt.core.jixia_extract "/home/linfe/math/lean_test" --search_list Mathlib.Util.MemoFix --log_mode Debug