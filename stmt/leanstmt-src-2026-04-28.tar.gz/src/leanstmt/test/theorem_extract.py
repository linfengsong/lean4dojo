import os
import io
import glob
from datetime import datetime
from ..generator.lean_project import LeanProject
from .jixia.jixia_project_data import JixiaProjectData
from .dojo.dojo_module import create_dojo_module

def get_process_file(search_dir: str):
    files = glob.glob(search_dir + "/.logs/execute_lean_*.log")
    latest_file = max(files, key=os.path.getmtime)
    return latest_file

def extract_status(line):
    if not line.startswith("module"):
        return None, None, None
    parts = line.split(" ")
    if len(parts) < 5:
        return None, None, None
    if parts[0] != "module:" or not parts[1].endswith(",") or parts[2] != "theorem:" or not parts[4] in ["pass", "fails"]:
        return None, None, None
    return (parts[1])[:-1], parts[3], parts[4]

def get_jixia_theorem(root_dir, module_name, theorem_name):
    project = JixiaProjectData(root_dir, ".jixia.v4.24.0")
    moduleTreeData = project.loadModuleTree(module_name)
    if moduleTreeData is None:
        return None, None
    for decl in moduleTreeData.decls:
        if decl.name == theorem_name:
            return decl.signature.pp if decl.signature.pp else None, \
                decl.value.pp if decl.value.pp else None
    return None, None

def get_dojo_theorem(root_dir, module_name, theorem_name):
    output = io.StringIO()
    module = create_dojo_module(root_dir, ".dojo", module_name, output)
    for theorem in module.theorems:
        if theorem.name == theorem_name:
            signature = None
            if theorem.tacticProof and len(theorem.tacticProof.tactics) > 0:
                signature = theorem.tacticProof.tactics[0].before[0]
            return signature, theorem.proof
    return None, None

def print_jixia_dojo(module_name, theorem_name, file):
    signature, proof = get_jixia_theorem(root_dir, module_name, theorem_name)
    if signature and proof:
        print(f"jixia:", file=file)
        if signature:
            print(f"signature: {signature}", file=file)
        if proof:
            print(f"proof: {proof}", file=file)
    print("---------------------------------------------------------------", file=file)
    signature, proof =  get_dojo_theorem(root_dir, module_name, theorem_name)
    if signature and proof:
        print(f"dojo:", file=file)
        if signature:
            print(f"signature: {signature}", file=file)
        if proof:
            print(f"proof: {proof}", file=file)
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", file=file)


def processFile(log_fp, root_dir, process_file):

    print(f"process_file: {process_file}")

    previous_module_name = None
    previous_theorem_name = None
    with open(process_file, 'r', encoding='utf-8') as file:
        for line in file:
            module_name, theorem_name, status = extract_status(line)
            if status is None:
                print(line.rstrip(), file=log_fp)
                continue
            if previous_module_name and previous_theorem_name:
                print_jixia_dojo(previous_module_name, previous_theorem_name, log_fp)
            if status == "fails":
                previous_module_name = module_name
                previous_theorem_name = theorem_name
                print(line.rstrip(), file=log_fp)
            else:
                previous_module_name = None
                previous_theorem_name = None

    if previous_module_name and previous_theorem_name:
        print_jixia_dojo(previous_module_name, previous_theorem_name, log_fp)




def main(root_dir: str, input_log_file: str):

    process_file = input_log_file if input_log_file else get_process_file(root_dir)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_name = f"theorem_extract_{timestamp}.log"
    log_dir = os.path.join(root_dir, ".logs")
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, file_name)

    with open(log_file, "w", encoding="utf-8") as log_fp:
        processFile(log_fp, root_dir, process_file)

 
if __name__ == "__main__":
    root_dir = "/home/linfe/math/lean_test"
    input_log_file = None
    main(root_dir, input_log_file)

