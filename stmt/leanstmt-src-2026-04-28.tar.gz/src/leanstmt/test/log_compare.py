import os
import glob
from datetime import datetime

class Record:
    module: str
    statement: str
    status: str
    error: str = None

    def __init__(self, module, statement, status, error):
        self.module
        self.statement = statement
        self.status = status
        self.error = error
    
    def key(self):
        return self.module + " " + self.statement


def get_process_file(search_dir: str):
    log_dir = ".logs"
    print(search_dir + "/" + log_dir)
    files = glob.glob(search_dir + "/" + log_dir + "/execute_lean_*.log")
    latest_file = max(files, key=os.path.getmtime)
    return latest_file

def get_log_file():
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_name = f"theorem_extract_{timestamp}.log"
    log_dir = os.path.join(root_dir, ".")
    os.makedirs(log_dir, exist_ok=True)
    return os.path.join(log_dir, file_name)

def extract_status(line):
    if not line.startswith("module"):
        return None, None, None, None
    parts = line.split(" ")
    if len(parts) < 5:
        return None, None, None, None
    if parts[0] != "module:" or not parts[1].endswith(",") or parts[2] != "theorem:" or not parts[4] in ["pass", "fails"]:
        return None, None, None, None
    return (parts[1])[:-1], parts[3], parts[4], " ".join(parts[5:])


def processFile(log_fp, root_dir, process_file):

    print(f"process_file: {process_file}")

    records = []
    line_state = None
    with open(process_file, 'r', encoding='utf-8') as file:
        message = []
        debug = []
        source = []
        error_message_dict = {}
        for line in file:
            if line_state is None:
                message = []
                debug = []
                source = []
                module_name, theorem_name, status, error = extract_status(line)
                if theorem_name:
                    record = Record(module_name, theorem_name, status, error)
                    records[record.key()] = record
                if status == "fails":
                    line_state = "message"
                    #print(f"module_name: {module_name} theorem_name: {theorem_name}, ")
                elif status != "pass":
                    print(line.rstrip())#, file=log_fp)
                    continue

            if line_state == "message":
                if line == "---------------------- DEBUG -----------------------\n":
                    line_state = "debug"
                else:
                    message.append(line)
            elif line_state == "debug":
                if line == "---------------------- Source Code ------------------\n":
                    line_state = "source"
                else:
                    debug.append(line)
            elif line_state == "source":
                if line == "=====================================================\n":
                    line_state = None
                    message_line = message[0]
                    lean_file = theorem_name + ".lean" 
                    index = message_line.find(lean_file)
                    message_line = message_line[index + len(lean_file): ].strip()
                    index = message_line.find("error:")
                    if index >= 0:
                        label = "error"
                        message_range = message_line[:index -1].strip()
                        message = message_line[index + len("error:") + 1:].strip()
                    else:
                        index = message_line.find("warning:")
                        label = "warning"
                        message_range = message_line[:index -1].strip()
                        message = message_line[index + len("warning:") + 1:].strip()
                    print(f"{module_name:<70} {theorem_name:<70} {message_range:<10} {label:<10}    {message}")
                    if message in error_message_dict.keys():
                        count = error_message_dict[message]
                        error_message_dict[message] = count + 1
                    else:
                        error_message_dict[message] = 1
                else:
                    source.append(line)
        #for key in error_message_dict.keys():
        #    print(f"{key:<200}, {error_message_dict[key]}")
    return records

def main(root_dir: str, process_file: str, process_file2: str = None):

    process_file2 = process_file2 if process_file2 else get_process_file(root_dir)

    log_file = get_log_file()
    log_file2 = get_log_file()

    with open(log_file, "w", encoding="utf-8") as log_fp:
        records = processFile(log_fp, root_dir, process_file)
    with open(log_file2, "w", encoding="utf-8") as log_fp:
        records2 = processFile(log_fp, root_dir, process_file2)

    same_keys = []
    diff_keys = []
    for key in records.keys():
        if key in records2.keys():
            if records[key].status == records2[key].status:
                same_keys.append(key)
            else:
                diff_keys.append(key)

    print(f"same_keys: {len(same_keys)}, diff_keys: {len(diff_keys)}")
    print("module".ljust(50) + "statement".ljust(60) + "status1".ljust(12) + "status2".ljust(12) + "error")
    for key in diff_keys:
        record = records[key]
        record2 = records2[key]
        error = error if record.status != "pass" else record2.error
        errors = error.split(record.module + "/" + record.statement)
        if len(errors) > 0:
            error = errors[1]
        print(f"{record.module.ljust(50)}{record.statement.ljust(60)}{record.status.ljust(12)}{record2.status.ljust(12)}{error}")
 
if __name__ == "__main__":
    root_dir = "/home/linfe/math/lean_test"
    process_file = root_dir + "/.logs/execute_lean_20260412_001249_test.log"
    process_file2 = root_dir + "/.logs/execute_lean_20260412_001249_test.log"
    main(root_dir, process_file, process_file2)

