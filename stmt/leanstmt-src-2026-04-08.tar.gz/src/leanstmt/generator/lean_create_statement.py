import sys
from dataclasses import dataclass
from operator import attrgetter
from leanstmt.generator.lean_module import LeanModule
from .lean_statement import Statement, Variable
from .lean_file import LeanFileRange, LeanFilePos
from .lean_module import LeanSymbolReference

class ExclusiveConfig: 
    def __init__(self, data: dict[str, list[str]]):
        self.config: dict[str, list[str]] = data

    def getConfigList(self, name: str):
        if self.config is None:
            return None
        return self.config[name] if name in self.config.keys() else None

@dataclass(frozen=True)
class ContextText:
    text: str
    comment: str
    pos: LeanFilePos

class LeanCreateStatement:
    def __init__(self, exclusiveConfig: ExclusiveConfig, module_name: str, module: LeanModule, statements: list[Statement]):
        self.exclusiveConfig = exclusiveConfig
        self.module_name = module_name
        self.module = module
        self.statements = statements

        private_stmts = []
        for statement in self.statements:
            if statement.kind != "theorem" and statement.kind != "definition":
                continue
            if statement.modifiers and statement.modifiers.visibility == "private":
                private_stmts.append(statement)
        self.private_stmts = sorted(private_stmts, key=lambda x: x.fileRange, reverse=True)

    def get_statement_name(self, namespace, statement):
        statement_name = statement.name if hasattr(statement, "name") and statement.name else None
        if statement_name:
            if namespace and statement_name.startswith(namespace + "."):
                statement_name = statement_name[len(namespace) + 1:]
        return statement_name

    def create_lean_text(self, statement: Statement, file):
        text = ""

        namespace = statement.scope_info.namespace.strip() if statement.scope_info.namespace else None
        #file = statement.name == "Filter.EventuallyEq.iteratedFDeriv" #statement.name.endswith("volume_pi")
        if file: print(f"statement.name: |{statement.name}| namespace: |{namespace}|", file=file)

        imprts = self.module.getImports()
        if imprts:
            for imprt in imprts:
                imprt_name = ".".join(imprt).strip() 
                if imprt_name != "Init":
                    text += "import " + imprt_name + " -- from module imports\n"
        # Only need to create own module file for testing
        text += "import " + self.module_name + " -- module name\n"

        namespaceRange, contexts = self.create_local_context(statement.fileRange, namespace, file=file)
        for context in contexts:
            text += context.text
            text += f" -- {context.comment}\n" if file else "\n"
        if namespaceRange is None:
            namespace = None
        
        isValid, result_text = self.create_statement_text(statement, namespace, "test_", file)
        if isValid:
            text += result_text.strip() + "\n"
            return True, text
        else:
            return False, result_text

   
    def get_replace_symbols(self, all_symbols, fileRange, file):
        if all_symbols is None:
            return []
        
        inRangeNamespaces = []
        outRangeNamespaaces = []
        for scopeInfo in self.module.getScopeRangeInfos():
            if scopeInfo.range is None or scopeInfo.name is None or scopeInfo.kind != "namespace":
                continue
            if scopeInfo.range.start > fileRange.stop or scopeInfo.range.stop < fileRange.start:
                outRangeNamespaaces.append(scopeInfo)
            else:
                inRangeNamespaces.append(scopeInfo)

        symbols = []
        replace_set = set()
        current_theorem_name = None
        for statement in self.statements:
            if statement.kind != "theorem" or statement.name is None:
                continue

            afterCurrentStatement = True
            if statement.fileRange.start > fileRange.stop:
                afterCurrentStatement = False
            
            sameNamespace = False
            statement_name = statement.name
            for scopeInfo in inRangeNamespaces:
                if scopeInfo.range.inRange(statement.fileRange):
                     sameNamespace = True
                if statement_name.startswith(scopeInfo.name):
                    statement_name = statement_name[len(scopeInfo.name) + 1:]
            for scopeInfo in outRangeNamespaaces:
                if statement_name.startswith(scopeInfo.name):
                    statement_name = statement_name[len(scopeInfo.name) + 1:]
            if statement.fileRange == fileRange:
                current_theorem_name = statement_name

            name_parts = statement_name.split(".")
            if len(name_parts) > 1:
                statement_name = name_parts[-1]
            for symbol in all_symbols:
                if symbol.src_name == statement_name and (sameNamespace or afterCurrentStatement):
                    if symbol.name == symbol.src_name:
                        symbol = LeanSymbolReference("_root_." + symbol.name, symbol.src_name, symbol.range)
                        if file: print(f" create root symbol: {symbol}", file=file)
                    if symbol.range not in replace_set:
                        replace_set.add(symbol.range)
                        symbols.append(symbol)
                        if file: print(f"replace symbol: {symbol}", file=file)
        namespaces = [ scopeInfo.name for scope in inRangeNamespaces]
        if file: print(f"current_theorem_name: {current_theorem_name}, namespaces: {namespaces} replace_symbols: {len(symbols)}", file=file)
        return sorted(symbols, key=lambda x: x.range, reverse=True) 
    
    def create_local_context(self, fileRange: LeanFileRange, namespace: str, file):

        exclude_ranges =[]

        if file:
            print(f"scopeInfo check fileRange: {fileRange}", file=file)
        
        namespaceRange = None
        ex_texts = []
        for scopeInfo in self.module.getScopeRangeInfos():
            if scopeInfo.range.start > fileRange.stop:
                continue
            if scopeInfo.kind == "section":
                if not scopeInfo.range.inRange(fileRange):
                    exclude_ranges.append(scopeInfo.range)
                    if file: print(f"add exclude section range: {scopeInfo}", file=file)
                else:
                    ex_texts.append(ContextText(scopeInfo.content, "scopeInfo section", scopeInfo.range.start))
                    if file: print(f"add texts: {scopeInfo.content}, {scopeInfo}", file=file)                                      
            elif scopeInfo.kind == "namespace":
                ex_texts.append(ContextText("open " + scopeInfo.name, "scopeInfo namespace", scopeInfo.range.start))
                if file: print(f"add texts: open {scopeInfo.name}, {scopeInfo}", file=file)
                if not scopeInfo.range.inRange(fileRange):
                    exclude_ranges.append(scopeInfo.range)
                    if file: print(f"add exclude namespace range: {scopeInfo}", file=file)
                else:
                    if namespace and namespace.endswith(scopeInfo.name):
                        column = scopeInfo.range.start.column + 1
                        ex_texts.append(ContextText(f"namespace {namespace}", "scopeInfo namespace",
                                    LeanFilePos(scopeInfo.range.start.line, column)))
                        namespaceRange = scopeInfo.range
                        if file: print(f"add texts: namespace {namespace}, {scopeInfo}", file=file)
        if file: print(f"namespaceRange: {namespaceRange}", file=file)

        for private_stmt in self.private_stmts:
            if private_stmt.fileRange.stop < fileRange.start:
                invalid_entry = self.inRange(exclude_ranges, private_stmt.fileRange)
                if invalid_entry:
                    continue
                invalid, text = self.create_statement_text(private_stmt, namespace, "", file=file)
                if invalid:
                    ex_texts.append(ContextText(text, "", private_stmt.fileRange.start))
                else:
                    return False, text
     
        exclude_ranges.append(LeanFileRange(fileRange.stop, LeanFilePos(sys.maxsize, sys.maxsize)))
        context_dict = {}
        texts =[]
        for entry in self.module.getContextEntries():
            if entry.range.start > fileRange.stop:
                continue
            invalid_entry = self.inRange(exclude_ranges, entry.range)
            if invalid_entry:
                if file: print(f"exclude variable: {entry.content}, variable.fileRange: {entry.range}, exclude_section_range: {exclude_ranges}", file=file)
                continue
            if entry.kind in ["notation", "variable","open", "universe", "set_option", "noncomputable", "include", "custom_macro", "attribute", "in", "mixfix"]:
                if entry.kind == "set_option":
                    if "linter.indexVariables" in entry.content or "linter.listVariables" in entry.content: # Lean Internal variable
                        continue
                    
                self.append_ex_texts(ex_texts, texts, context_dict, entry.range.start, file)

                if entry.kind == "in" and not entry.range.inRange(fileRange):
                    continue
                context = entry.content.rstrip()
                nz_context = self.normalize(context)
                if entry.kind in ["mixfix", "attribute"] and not nz_context.startswith("local"):
                    continue

                if nz_context in context_dict:
                    previous_content = context_dict[nz_context]
                    del previous_content

                context_dict[nz_context] = context
                if file: print(f"add entry: {context}, entry.range: {entry.range}", file=file)
                raw_kind = entry.raw_kind if entry.raw_kind else ""
                comment = f"context kind: {entry.kind} {raw_kind}"
                texts.append(ContextText(context, comment, entry.range.start))

        self.append_ex_texts(ex_texts, texts, context_dict, fileRange.start, file)
        
        texts.sort(key=attrgetter("pos"))
        return namespaceRange, texts
    
    def inRange(self, ranges, check_range):
        for exclude_range in ranges:
            if exclude_range.inRange(check_range):
                return True
        return False
    
    def append_ex_texts(self, ex_texts, texts, context_dict, currentPos: LeanFilePos, file):
        i = 0
        for ex_text in ex_texts[:]:
            if ex_text.pos >= currentPos:
                continue
            nz_context = self.normalize(ex_text.text)
            if nz_context in context_dict:
                previous_content = context_dict[nz_context]
                del previous_content
                
            context_dict[nz_context] = ex_text
            if file: print(f"add ex_text: {ex_text.text}, ex_text.rangepos: {ex_text.pos}", file=file)
            texts.append(ex_text)
            ex_texts.remove(ex_text)
        
    def create_statement_text(self, statement: Statement, namespace: str, prefix_name: str, file = None):
        statement_name = self.get_statement_name(namespace, statement)
        all_symbols = self.module.getSymbols("theorem", statement.name)
        if all_symbols:
            exclusiveSymbols = None
            if self.exclusiveConfig.config:
                exclusiveSymbols = self.exclusiveConfig.getConfigList("symbol")
            if file: print(f"all_symbols: {len(all_symbols)}", file=file)
            for symbol in all_symbols:
                if file: print(f"    symbol: {symbol}", file=file)
                if exclusiveSymbols:
                    if symbol.name in exclusiveSymbols:
                        return False, f"Symbol: {symbol}"
        else:
            if file: print(f"all_symbols: None", file=file)
        replace_symbols = self.get_replace_symbols(all_symbols, statement.fileRange, file=file) 
        text = ""

        attrs = self.create_attrs_text(statement.modifiers.attrs)
        if attrs:
            text += attrs.strip() + "\n"
        if statement.modifiers.visibility:
            text += statement.modifiers.visibility.strip() + " "
        if statement.modifiers.compute_kind:
            text += statement.modifiers.compute_kind.strip() + " "
        if statement.modifiers.rec_kind:
            text += statement.modifiers.rec_kind.strip() + " "
        if statement.modifiers.is_unsafe:
            text += "unsafe "
        if statement.modifiers.rec_kind_left:
            text += statement.modifiers.rec_kind_left.strip() + " "
        text += statement.command.strip() + " "
        if statement.modifiers.rec_kind_right:
            text += statement.modifiers.rec_kind_right.strip() + " "
        if statement_name:
            statement_name_parts = statement_name.split(".")
            statement_name_parts[-1] = prefix_name + statement_name_parts[-1]
            text += ".".join(statement_name_parts) + " "
        if hasattr(statement, "signature") and statement.signature:
            text += self.replaceContent(statement.signature, statement.signatureRange, replace_symbols, statement.name, file) + " "
        if hasattr(statement, "value") and statement.value:
            text += self.replaceContent(statement.value, statement.valueRange, replace_symbols, statement.name, file).rstrip()
        return True, text.strip()

    def replaceContent(self, content: str, range: LeanFileRange, replace_symbols, theorem_full_name: str,  file):
        lines = content.split("\n")
        for symbol in replace_symbols:
            if symbol.range is None or not range.inRange(symbol.range):
                if file: print(f"replaceContent not in range: range: {range}, symbol.range: {symbol.range}", file=file)
                continue
            name_parts = symbol.name.split(".")
            if len(name_parts) == 1:
                continue
            name_parts = name_parts[-2:]
            last_item = None
            replace_name = ".".join(name_parts)
            for item in reversed(name_parts):
                if item in symbol.src_name: 
                    last_item = item + "." + last_item if last_item else item
            if last_item is None:
                if file: print(f"replaceContent Fail last_item: {last_item}, replace_name: {replace_name}, symbol: {symbol}", file=file)
                continue
            if last_item == replace_name:
                if file: print(f"replaceContent skip symbol: {symbol}", file=file)
                continue
            if symbol.range.start.line != symbol.range.stop.line:
                if file: print(f"replaceContent Fail line: {symbol.range.start.line}, {symbol.range.stop.line}", file=file)
                continue
            line_index = symbol.range.start.line - range.start.line
            if line_index < 0 or line_index >= len(lines):
                if file: print(f"replaceContent Fail line range: {range.start.line}, {symbol.range.start.line}, {len(lines)}", file=file)
                continue
            if symbol.range.stop.column - symbol.range.start.column + 1 != len(symbol.src_name):
                if file: print(f"replaceContent Fail column range: {symbol.range.stop.column}, {symbol.range.start.column}, {len(symbol.src_name)}", file=file)
                continue
            line = lines[line_index]
            replace_symbol = symbol.src_name.replace(last_item, replace_name)
            start_column = range.start.column if range.start.line == symbol.range.start.line else 1
            column_start = symbol.range.start.column - start_column
            #if not line[column_start:].startswith(symbol.src_name):
            #    column_start -= 1
            #    if not line[column_start:].startswith(symbol.src_name):
            #        if file: print(f"replaceContent Fail src_name position not right in line, symbol {symbol}, range: {range}, line: |{line}|", file=file)
            #    continue                    
            column_stop = symbol.range.stop.column - start_column
            previous_char = line[column_start-1:column_start] if column_start > 1 else None
            if previous_char == ".":
                if file: print(f"replaceContent skip with '.': line: {line}, symbol: {symbol}", file=file)
                continue
            else:
                if file: print(f"replaceContent not skip with '{previous_char}': line: {line}, symbol: {symbol}", file=file)
            replace_line = line[:column_start] + replace_symbol + line[column_stop + 1:]
            if file: print(f"replaceContent: symbol {symbol}, range: {range}", file=file)
            if file: print(f"replaceContent: replace_symbol |{line}| |{replace_line}|", file=file)
            lines[line_index] = replace_line
        return "\n".join(lines)

    def create_attrs_text(self, attrs: list):
        if attrs is None or len(attrs) == 0:
            return None
        text = ""
        for attr in attrs:
            if len(text) > 0:
                text += ", "
            if attr.kind and attr.kind != "global":
                text += attr.kind.strip() + " "
            text += attr.content.strip()
        return f"@[{text}]"

    def normalize(self, str):
        str = str.replace("\t", " ").replace("\r", " ").replace("\n", " ")
        return " ".join(str.split())
