import sys
import os
import re
from typing import Optional
from dataclasses import dataclass, field
from dataclasses_json import dataclass_json
from ..core.core_project import CoreModule
from ..core.core_datasets import CoreDeclaration, CoreInfoTree
from .lean_statement import Attribute, ScopeInfo, Modifiers, Statement, Abbrev, Axiom, ClassInductive, Declaration, Example, Inductive, Instance, Opaque, Structure, Variable, ProofWanted, Theorem, Notation, IrreducibleDef
from .lean_file import LeanFile, LeanFileRange, LeanFilePos
from .lean_elab import collect_all_terms, collect_all_tacticProofs
from .lean_block import LeanNamespaceBlock, LeanNamespaces

Symbol_Unsafe_src_names =  [
    "rfl",
    "interior",
    "Inter",
    "iInter",
    "sInter",
    "closure",
    "nhds",
    "ofNat",
    "intro",
    "const"
]

Symbol_Unsafe_names = {
    "Array.anyM.loop"
}

@dataclass_json
@dataclass(frozen=True)
class LeanScopeRangeInfo:
    kind : str
    name : str
    content: str
    range : LeanFileRange
    index: int

    def __str__(self):
        return self.to_json()

@dataclass_json
@dataclass(frozen=True)
class LeanContextEntryInfo:
    kind : str
    raw_kind: str
    namespace: str
    content : str
    range : LeanFileRange

    def __str__(self):
        return self.to_json()
    
    def getArguments(self):
        kind = self.raw_kind if self.raw_kind else self.kind
        content = self.content.replace("\n", " ").replace("\t", " ").replace("\r", " ")
        index = content.find(kind + " ")
        if index < 0:
            return None
        content = self.content[index + len(kind) + 1:].strip()
        if not content.startswith("["):
            return None
        index = content.find("]")
        if index < 0:
            return None
        content = content[1:index].strip()
        if len(content) == 0:
            return None
        return content.split(" ")
    
    def isPrivate(self):
        content = self.content.replace("\n", " ").replace("\t", " ").replace("\r", " ")
        return content.strip().startswith("private")

@dataclass_json
@dataclass(frozen=True)
class LeanSymbolReference:  
    name: str
    src_name: str
    range: LeanFileRange
    is_private: bool = False
    prefix_safe: bool = True
    prefix_reason: str = None

    def __str__(self):
        return self.to_json()

@dataclass_json
@dataclass(frozen=True)
class LeanStatementSymbol:
    kind: str
    name: str
    signature_symbols: list[LeanSymbolReference]
    value_symbols: Optional[list[LeanSymbolReference]] = None

    def __str__(self):
        return self.to_json()
    
@dataclass_json
@dataclass(frozen=True)
class LeanTacticCommand:  
    tacticName: str
    src: str
    range: LeanFileRange
    idents: list[str]

@dataclass_json
@dataclass(frozen=True)
class LeanModule:
    name: str
    coreModule: CoreModule

    firsttime: bool = True

    namespaces: LeanNamespaces = None
    statements: list[Statement] = None
    contextEntries: list[LeanContextEntryInfo] = None
    statementSymbols: dict[str, LeanStatementSymbol] = field(default_factory=dict)
    statementTactics: dict[str, list[LeanTacticCommand]] = field(default_factory=dict)

    def __post_init__(self):
        namespaces = self.createNamespaces()    
        statements = self._getStatements()
        contextEntries = self._getContextEntries(namespaces, statements)
        object.__setattr__(self, 'namespaces', namespaces)
        object.__setattr__(self, 'statements', statements)
        object.__setattr__(self, 'contextEntries', contextEntries)

    def getStatements(self):
        return self.statements
    
    def getStatement(self, id: str):
        iId = int(id)
        if iId >= 0  and iId < len(self.statements):
            return self.statements[iId]
        return None
    
    def getContextEntries(self):
        return self.contextEntries

    def getImports(self):
        return self.coreModule.moduleInfo.imports
    
    def _appendSymbolReference(self, leanFile, reference, symbols_dict):
        if reference.name is None:
            return
        if reference.range is None:
            return
        name = ".".join([str(item) for item in reference.name])

        is_private = False
        if name.startswith("_private.0."):
            name = name[len("_private.0."):]
            is_private = True
        fileRange = LeanFileRange(LeanFilePos.createFilePos(leanFile.lines, reference.range[0]),
                         LeanFilePos.createFilePos(leanFile.lines, reference.range[1])) if reference.range else None
        src_name_raw = leanFile.getTextFromLineModule(fileRange) if fileRange else None
        src_name = leanFile.remove_comment(src_name_raw)
        adj_src_name = None
        if fileRange and fileRange.start.line == fileRange.stop.line:
            for item in reversed(reference.name):
                check_src_name = str(item) + "." + adj_src_name if adj_src_name else str(item)
                if check_src_name in src_name:
                    adj_src_name = check_src_name
                else:
                    break
            if adj_src_name:
                if src_name != adj_src_name:
                    index = src_name.index(adj_src_name)
                    src_name = adj_src_name
                    fileRange = LeanFileRange(LeanFilePos(fileRange.start.line, fileRange.start.column + index),
                                LeanFilePos(fileRange.start.line, fileRange.start.column + index + len(adj_src_name) - 1))
        str_fileRange = f"{fileRange}" if fileRange else name
        if not str_fileRange in symbols_dict:
            namespace_prefix_safe, namespace_prefix_reason = self._validate_namespace_prefix(leanFile, reference, name, src_name, fileRange) 
            symbols_dict[str_fileRange] = LeanSymbolReference(name, src_name, fileRange, is_private, namespace_prefix_safe, namespace_prefix_reason)

    def find_best_matches(self, target, candidates):
        def get_prefix_len(s):
            return len(os.path.commonprefix([target, s]))

        max_len = max((get_prefix_len(s) for s in candidates), default=0)
        return [s for s in candidates if get_prefix_len(s) == max_len]
    
    def getStatementNameID(self, statement):
        internal_name = statement.internal_name
        if internal_name is None:
            #print(f"ERROR statement.internal_name is None for statement: {statement.name} in module: {self.name}, internal_name: {internal_name}")
            return None, -1
        if statement.name is None:
            #print(f"ERROR statement.name is None for statement: {statement.name} in module: {self.name}, internal_name: {internal_name}")
            return None, -1
        if len(internal_name) > 1 and internal_name[0] == "_private":
            index  = 0
            for index, part in enumerate(internal_name):
                if isinstance(part, int):
                    internal_name = internal_name[index:]
                    assert (len(internal_name) > 0), f"Fail parse private statement name: {internal_name}"
                    internal_name.insert(0, "_private")
                    break
        name = ".".join([str(part) for part in internal_name])
        statement_index = -1
        if statement.kind == "instance":
            if type(internal_name[-1]) == int: # internal instance
                return None, -1
            index = internal_name[-1].rfind("_")
            if index > 0:
                left_part = internal_name[-1][:index]
                right_part = internal_name[-1][index+1:]
                if len(right_part) > 0 and right_part.isdigit():
                    internal_name[-1] = left_part
                    statement_index = int(right_part) - 1
                name = ".".join([str(part) for part in internal_name])

        return name, statement_index
    

    def getStatementTactic(self, statement: Statement):
        name, statement_index = self.getStatementNameID(statement)
        id = f"{name}_{statement_index}"
        if id in self.statementTactics.keys():
            return self.statementTactics[id]
        tacticCommands = self._getStatementTactic(statement)
        self.statementTactics[id] = tacticCommands
        return tacticCommands
        
    def _getStatementTactic(self, statement: Statement):
        kind = statement.kind
        name, _ = self.getStatementNameID(statement)
        leanFile = self.getLeanFile()
        stmtTactic = None
        if self.coreModule.tactics:
            matchTactics = []
            for tactic in self.coreModule.tactics:
                if tactic.name is None:
                    continue
                tacticName = ".".join([str(name) for name in tactic.name])
                if tactic.kind == kind and name.startswith(tacticName):
                    matchTactics.append(tactic)
            if len(matchTactics) == 1:
                stmtTactic = matchTactics[0]
            elif len(matchTactics) > 1:
                stmtFileRange = statement.fileRange
                for tactic in matchTactics:
                    if len(tactic.references) > 0:
                        fileRange = leanFile.createFileRange(tactic.references[0].range)
                        if stmtFileRange.inRange(fileRange):
                            stmtTactic = tactic
                            break

        if stmtTactic is None:
            return None
        
        tacticCommands = []
        tacticRangeSet = set()
        for reference in stmtTactic.references:
            range = leanFile.createFileRange(reference.range)
            cmd = LeanTacticCommand(reference.tacticName, reference.src, range, reference.idents)
            str_range = str(reference.range)
            if not str_range in tacticRangeSet:
                tacticRangeSet.add(str_range)
                tacticCommands.append(cmd)
        return tacticCommands

    def getStatementSymbol(self, statement: Statement):
        name, statement_index = self.getStatementNameID(statement)
        id = f"{name}_{statement_index}"
        if id in self.statementSymbols.keys():
            return self.statementSymbols[id]
        statementSymbol = self._getStatementSymbol(statement)
        self.statementSymbols[id] = statementSymbol
        return statementSymbol
        
    def _getStatementSymbol(self, statement: Statement):
        kind = statement.kind
        name, statement_index = self.getStatementNameID(statement)
        if kind == "classInductive" or kind == "structure":
            kind = "inductive"
        elif kind == "abbrev" or kind == "opaque" or kind == "irreducible_def":
            kind = "definition"

        symbols = []
        same_name_kinds = set()
        instance_dict = {}
        for smbl in self.coreModule.symbols:
            symbol_name = ".".join([str(item) for item in smbl.name ])
            if symbol_name == name:
                smbl_kind = smbl.kind
                if smbl_kind == "opaque":
                    smbl_kind = "definition"
                if smbl_kind not in same_name_kinds:
                    same_name_kinds.add(smbl.kind)
                if smbl_kind == kind or kind == "instance":
                    symbols.append(smbl)
            if kind == "instance" and symbol_name.startswith("inst"):
                if not symbol_name in instance_dict:
                    instance_dict[symbol_name] = [smbl]
                else:
                    instance_dict[symbol_name].append(smbl)

        leanFile = self.getLeanFile()
        if len(symbols) == 0:
            if kind == "instance":
                stmtFileRange = statement.fileRange
                if len(instance_dict) == 1:
                    symbols.extend(list(instance_dict.values())[0])
                elif len(instance_dict) > 1:
                    foundSymbol = None
                    for symbol in symbols:
                        if symbol.value_references:
                            for reference in symbol.value_references:
                                fileRange = leanFile.createFileRange(reference.range)
                                if stmtFileRange.inRange(fileRange):
                                    foundSymbol = symbol
                                    break
                            for reference in symbol.type_references:
                                fileRange = leanFile.createFileRange(reference.range)
                                if stmtFileRange.inRange(fileRange):
                                    foundSymbol = symbol
                                    break
                        if foundSymbol:
                            break
                    if foundSymbol:
                        symbols.append(foundSymbol)
        if len(symbols) == 0:
            is_private = statement.is_private()
            if len(same_name_kinds) > 0:
                print(f"ERROR symbols does not find for statement:  kind: {kind}, {statement.name}, same name kinds: {same_name_kinds}, is_private: {is_private}, name: {name} in module: {self.name}, internal_name: {internal_name}, symbols: {len(symbols)}")
            #if statement.kind == "instance":
            #    print(f"ERROR symbols does not find for statement:  kind: {statement.kind}, {statement.name}, same name kinds: {same_name_kinds}, is_private: {is_private}, name: {name} in module: {self.name}, internal_name: {internal_name}, symbols: {len(symbols)}")
            return None
        if statement_index == -1:
            symbol = symbols[0]
            if len(symbols) > 1:
                print(f"WARNING multiple symbols found for statement: {statement.name}, kind: {kind}, name: {name} in module: {self.name}, internal_name: {internal_name}, symbols: {len(symbols)}, same name kinds: {same_name_kinds}, use the first one")
        else:
            #assert statement_index < len(symbols); f"statement_index: {statement_index} out of symbols range: {len(symbols)} on statement: {statement.internal_name}"
            if statement_index < len(symbols):
                symbol = symbols[statement_index]
            else:
                symbol = symbols[0]
        symbols_signature_dict = {}
        for reference in symbol.type_references:
            self._appendSymbolReference(leanFile, reference, symbols_signature_dict)
        signatureRefs = symbols_signature_dict.values()
        valueRefs = None
        if hasattr(statement, "value"):
            symbols_value_dict = {}
            for reference in symbol.value_references:
                self._appendSymbolReference(leanFile, reference, symbols_value_dict)
            valueRefs = symbols_value_dict.values()
        return LeanStatementSymbol(kind, name, self.removeInvidSymbolReferences(signatureRefs), self.removeInvidSymbolReferences(valueRefs))
    
    def removeInvidSymbolReferences(self, symbolRefs):
        #symbol from Lean get substring of indentier. remove any substring symbl reference
        if symbolRefs is None:
            return None
        valid_symbolRefs = []
        for symbolRef in symbolRefs:
            if len(valid_symbolRefs) == 0:
                valid_symbolRefs.append(symbolRef)
            else:
                replaceIndex = None
                for index,valid_symbolRef in enumerate(valid_symbolRefs):
                    if valid_symbolRef.range.inRange(symbolRef.range) or symbolRef.range.inRange(valid_symbolRef.range):
                        if self.selectSymbolReference(symbolRef, valid_symbolRef):
                            replaceIndex = index
                        else:
                            replaceIndex = -1
                        break
                if replaceIndex is None:
                    valid_symbolRefs.append(symbolRef)
                elif replaceIndex >= 0:
                    valid_symbolRefs[replaceIndex] = symbolRef
        return valid_symbolRefs
    
    def selectSymbolReference(self, symbolRef1, symbolRef2):
        if symbolRef1.name.endswith(symbolRef1.src_name) and symbolRef2.name.endswith(symbolRef2.src_name):
            return len(symbolRef1.src_name) > len(symbolRef2.src_name)
        else:
            return len(symbolRef1.src_name) < len(symbolRef2.src_name)
        
    def createNamespaces(self):
        scopeRangeInfos = self.getScopeRangeInfos()
        namespaces = []
        for scopeRange in scopeRangeInfos:
            if scopeRange.kind != "namespace":
                continue
            namespace = LeanNamespaceBlock(scopeRange.kind, scopeRange.name, scopeRange.content, scopeRange.range, scopeRange.index)
            namespaces.append(namespace)
        return LeanNamespaces(namespaces)
    
    def getScopeRangeInfos(self):
        def get_scope_name(kind, scope_range_name):
            if scope_range_name is None:
                return None
            if not scope_range_name.startswith(kind + " "):
                return None
            scope_range_name = " ".join(scope_range_name.split()) if scope_range_name else None
            parts = scope_range_name.split(" ")
            if len(parts) > 1:
                return parts[1]
            else:
                return None

        scopeRangeInfos = []
        workingScopeRangeInfos = []
        leanFile = self.getLeanFile()
        for scope_range in self.coreModule.moduleInfo.scope_range_infos:
            name = scope_range.name.strip() if scope_range.name and scope_range.name != "anonymous" else None
            if scope_range.kind in ["namespace", "section"]:
                contentRange = LeanFileRange(LeanFilePos.createFilePos(leanFile.lines, scope_range.range.start), 
                                     LeanFilePos.createFilePos(leanFile.lines, scope_range.range.stop))
                range = LeanFileRange(contentRange.start, 
                                     LeanFilePos.createFilePos(leanFile.lines, sys.maxsize))
                content = leanFile.remove_comment(leanFile.getTextFromLineModule(contentRange)).strip()
                if scope_range.kind == "section" and name is None:
                    scopeInfo = LeanScopeRangeInfo(scope_range.kind, None, content, range, 0)
                    scopeRangeInfos.append(scopeInfo)
                    #empty_sections.append(scopeInfo)
                    workingScopeRangeInfos.append(scopeInfo)
                elif name:
                    name_parts = name.split(".")
                    for i, part in enumerate(name_parts):
                        part_content = part.join(content.rsplit(name, 1))
                        scopeInfo = LeanScopeRangeInfo(scope_range.kind, part, part_content, range, i)
                        scopeRangeInfos.append(scopeInfo)
                        workingScopeRangeInfos.append(scopeInfo)
            elif scope_range.kind == "end":
                orgScopeInfo = workingScopeRangeInfos.pop()
                endPos = LeanFilePos.createFilePos(leanFile.lines, scope_range.range.stop)
                object.__setattr__(orgScopeInfo.range, "stop", endPos)
                name = get_scope_name(scope_range.kind, scope_range.name)
                if name:
                    name_parts = name.split(".")
                    if len(name_parts) > 1:
                        allowMerge = True
                        removeScopeInfos = []
                        for part in name_parts[:-1]:
                            partScopeInfo = workingScopeRangeInfos.pop()
                            removeScopeInfos.append(partScopeInfo)
                            object.__setattr__(partScopeInfo.range, "stop", endPos)
                            if orgScopeInfo.range.start != partScopeInfo.range.start:
                                allowMerge = False
                        if allowMerge:
                            for removeScopeInfo in removeScopeInfos:
                                scopeRangeInfos.remove(removeScopeInfo)
                            content = name.join(orgScopeInfo.content.rsplit(orgScopeInfo.name, 1))
                            object.__setattr__(orgScopeInfo, "name", name)
                            object.__setattr__(orgScopeInfo, "content", content)
        return scopeRangeInfos
    
    def getNamespaceByScopeRanges(self, range):
        scopeRanges = []
        for scopeRange in self.getScopeRangeInfos():
            if scopeRange.kind == "namespace" and scopeRange.range.inRange(range):
                scopeRanges.append(scopeRange)
        if len(scopeRanges) == 0:
            return None
        return ".".join([scopeRange.name for scopeRange in sorted(scopeRanges, key=lambda x: x.range)])

    def _getContextEntries(self, namespaces, statements):
        next_id = len(statements) - 1
        def nextId():
            nonlocal next_id
            next_id = next_id + 1
            return next_id
    
        contextEntries = []
        leanFile = self.getLeanFile()
        inRangeEntry = None
        context_entries = sorted(self.coreModule.localContext.context_entries, key=lambda x: x.range) 
        wantedMacros = [ "assert_not_imported", "assert_not_exists", "mk_iff_of_inductive_prop", "library_note2", "irreducible_def" ]
        previousRange = None
        for context_entry in context_entries:
            range = LeanFileRange(LeanFilePos.createFilePos(leanFile.lines, context_entry.range.start), 
                                LeanFilePos.createFilePos(leanFile.lines, context_entry.range.stop))
            content = leanFile.remove_comment(context_entry.content)
            kind = None
            raw_kind = None
            macro_kind = context_entry.kind[len("command"):1].lower() if context_entry.kind.startswith("command") else None
            if context_entry.kind == "Batteries.Tactic.Alias.alias" or context_entry.kind == "Batteries.Tactic.Alias.aliasLR":
                kind = "alias"
            elif context_entry.kind == "Lean.Parser.Command.notation":
                #headers, body = self._parseContentEntry(leanFile, "notation", context_entry.content)
                #if body:
                #    name, signature, signatureRange = self._getContentEntryNameAndSignature(leanFile, context_entry.content, range, body)
                #    scopeInfo = self._createContentEntryScopeInfo(headers)
                #    modifiers = self._createContentEntryModifiers(headers)
                #    internal_name = [name]
                #    internal_namespace = namespaces.get_full_namespace(range)
                #    statements.append(Notation(content, range, nextId(), name, internal_name, internal_namespace, scopeInfo, modifiers, signature, signatureRange))
                #    entry = None
                #else:
                    kind = context_entry.kind[len("Lean.Parser.Command."):]
            elif context_entry.kind == "irreducible_def":
                if previousRange and previousRange.inRange(range):
                    pass
                elif content.strip().endswith("in"):
                    kind = "in"
                elif content.strip().startswith("elab"):
                    kind = "custom_macro"
                    raw_kind = "irreducible_def"
                    previousRange = range
                else:
                    headers, body = self._parseContentEntry(leanFile, "irreducible_def", context_entry.content)
                    assert body, f"irreducible_def context_entry: {context_entry.content})"
                    name, signature, signatureRange = self._getContentEntryNameAndSignature(leanFile, context_entry.content, range, body)
                    scopeInfo = self._createContentEntryScopeInfo(headers)
                    modifiers = self._createContentEntryModifiers(headers)
                    internal_name = [name]
                    internal_namespace = None
                    statements.append(IrreducibleDef(content, range, nextId(), name, internal_name, internal_namespace, scopeInfo, modifiers, signature, signatureRange))
                    entry = None
            elif context_entry.kind.startswith("Lean.Parser.Command."):
                kind = context_entry.kind[len("Lean.Parser.Command."):]
            elif macro_kind in wantedMacros:
                kind = "custom_macro"
                raw_kind = macro_kind
            if kind:
                namespace = self.getNamespaceByScopeRanges(range)
                entry = LeanContextEntryInfo(kind, raw_kind, namespace, content, range)
                prev_entry = contextEntries.pop() if len(contextEntries) > 0 else None
                if prev_entry:
                    if not entry.range.inRange(prev_entry.range):
                        inRangeEntry = entry
                        contextEntries.append(prev_entry)
                elif inRangeEntry and inRangeEntry.range.inRange(entry.range):
                    entry = None
                    inRangeEntry = None 
                if entry:
                    contextEntries.append(entry)
            
            if previousRange and (context_entry.kind != "irreducible_def" or not previousRange.inRange(range)):
                previousRange = None
        return contextEntries
    
    def _getContentEntryNameAndSignature(self, leanFile, entry_content, range, body):
        if len(body.strip()) == 0:
            return None, None, None
        name = None
        signature = None
        nz_body = leanFile.space_comment(body)
        nz_body = nz_body.replace("\n", " ").replace("\t", " ").replace("\r", " ").replace("(", " ").replace("[", " ").strip()
        if nz_body.startswith("\""):
            i = nz_body.index("\"", 1)
            if i > 0:
                name = nz_body[1:i].strip()
                i = body.index(f"\"{name}\"")
                signature = body[i+len(name) + 2:]
        else:
            i = nz_body.index(" ")
            if i > 0:
                name = nz_body[:i]
                signature = body[i + 1:]
        if signature is None:
            signature = body
        signature_parts = signature.split("\n") if signature else []
        start_line = range.stop.line - len(signature_parts) + 1
        header_part = entry_content[:-len(signature)+1]
        start_column  = len(header_part.split("\n")[-1])
        signatureRange =  LeanFileRange(LeanFilePos(start_line, start_column), range.stop)
        return name, leanFile.remove_comment(signature), signatureRange
    
    def _createContentEntryScopeInfo(self, headers):
        var_decls = None
        include_vars = None
        omit_vars = None
        namespace = None
        open_decl = None
        scoped_open_decl = None
        return ScopeInfo(var_decls, include_vars, omit_vars, namespace, open_decl, scoped_open_decl)
    
    def _createContentEntryModifiers(self, headers):
        attrs = None
        compute_kind = "noncomputable" if "noncomputable" in headers else None
        rec_kind = None
        is_unsafe = False
        visibility = None
        if "private" in headers:
            visibility = "private"
        elif "public" in headers:
            visibility = "public"
        elif "protected" in headers:
            visibility = "protected"
        if "local" in headers:
            visibility = "local"
        return Modifiers(visibility, attrs, compute_kind, rec_kind, is_unsafe)
    
    def _parseContentEntry(self, leanFile, kind, entry_content):
        content = leanFile.space_comment(entry_content)
        content = " " + content.replace("\n", " ").replace("\t", " ").replace("\r", " ").replace("(", " ").replace("[", " ") + " "
        i = content.find(" " + kind + " ")
        if i < 0:
            return None, None    
        header_content = content[:i]
        header_parts = header_content.strip().split(" ")
        body = entry_content[i + len(kind):]
        return header_parts, body
    
    def getDocuments(self):
        return self.coreModule.moduleInfo.docstring
    
    def getLeanFile(self):
        return LeanFile(self.coreModule.lines)
    
    def _getStatements(self):
        next_id = -1
        def nextId():
            nonlocal next_id
            next_id = next_id + 1
            return next_id
        
        leanFile = self.getLeanFile()
        declarations:list[CoreDeclaration] = self.coreModule.decls
        infoTrees: list[CoreInfoTree] = self.coreModule.infoTrees
        tacticProofs = collect_all_tacticProofs(leanFile, infoTrees)
        terms = collect_all_terms(leanFile, infoTrees, self.name)
        statements = []
        fileRanges = []
        
        for _, decl in enumerate(declarations):
            raw_name = self._getRawName(decl.name)
            internal_name = decl.name
            internal_namespace = ".".join(decl.scope_info.curr_namespace) if decl.scope_info and decl.scope_info.curr_namespace else None
            fileRange = leanFile.createFileRange(decl.ref.range)
            content = leanFile.remove_comment(leanFile.getTextFromLineModule(fileRange))
            signature, signatureRange, value, valueRange = self._createSignatureAndValue(decl, leanFile, fileRange)
            scope_info = self._createScopeInfo(decl)
            modifiers = self._createModifiers(decl, leanFile)
            name = self._getName(signatureRange, raw_name)

            statement = None
            if decl.kind == "abbrev":
                statement = Abbrev(content, fileRange, nextId(), name, internal_name, internal_namespace, scope_info, modifiers, signature, signatureRange, decl, value, valueRange)
            elif decl.kind == "axiom":
                statement = Axiom(content, fileRange, nextId(), name, internal_name, internal_namespace, scope_info, modifiers, signature, signatureRange, decl)
            elif decl.kind == "classInductive":
                statement = ClassInductive(content, fileRange, nextId(), name, internal_name, internal_namespace, scope_info, modifiers, signature, signatureRange, decl, value, valueRange)
            elif decl.kind == "definition":
                InExist = False
                for exist_fileRange in fileRanges:
                    if exist_fileRange.inRange(fileRange):
                        InExist = True
                if not "._@." in name and valueRange and not InExist: #remove MACRO declaration
                    statement = Declaration(content, fileRange, nextId(), name, internal_name, internal_namespace, scope_info, modifiers, signature, signatureRange, decl, value, valueRange)
            elif decl.kind == "example":
                statement = Example(content, fileRange, nextId(), name, internal_name, internal_namespace, scope_info, modifiers, signature, signatureRange, decl, value, valueRange)
            elif decl.kind == "inductive":
                statement = Inductive(content, fileRange, nextId(), name, internal_name, internal_namespace, scope_info, modifiers, signature, signatureRange, decl, value, valueRange)
            elif decl.kind == "instance":
                InExist = False
                for exist_fileRange in fileRanges:
                    if exist_fileRange.inRange(fileRange):
                        InExist = True
                #if not (".inst" in name or name.startswith("inst")) and not ("_hyg" in name or InExist):
                statement = Instance(content, fileRange, nextId(), name, internal_name, internal_namespace, scope_info, modifiers, signature, signatureRange, decl, value, valueRange)
            elif decl.kind == "opaque":
                if signatureRange and fileRange != signatureRange: # other case is MACRO and need fix for MACRO
                    statement = Opaque(content, fileRange, nextId(), name, internal_name, internal_namespace, scope_info, modifiers, signature, signatureRange, decl, value, valueRange)
            elif decl.kind == "structure": 
                statement = Structure(content, fileRange, nextId(), name, internal_name, internal_namespace, scope_info, modifiers, signature, signatureRange, decl, value, valueRange)
            elif decl.kind == "theorem":
                if signature and value:
                    statement = Theorem.create(content, fileRange, nextId(), name, internal_name, internal_namespace, scope_info, modifiers, signature, signatureRange, decl, value, valueRange, tacticProofs, terms)
                    if statement is None:
                        next_id = next_id - 1
            elif decl.kind == "variable":
                InExist = False
                for exist_fileRange in fileRanges:
                    if exist_fileRange.inRange(fileRange):
                        InExist = True # skip variable defined in the statement
                if not InExist:
                    statement = Variable(content, fileRange, nextId(), name, internal_name, internal_namespace, scope_info, modifiers, signature, signatureRange, decl)
            elif decl.kind == "proofWanted":
                statement = ProofWanted(content, fileRange, nextId(), name, internal_name, internal_namespace, scope_info, modifiers, signature, signatureRange, decl, value, valueRange)
            else:
                print(f"ERROR decl.kind: {decl.kind} does not support at {self.name}")
                statement = None
            if statement is not None:
                fileRanges.append(statement.fileRange)
                statements.append(statement)
        return statements
    
    def _getRawName(self, name: str):
        #first item is "_private" if it's a private declaration, we need to remove the prefix and get the real name
        # for example, if the declaration name is ['_private', 'Mathlib', 'Data', 'EReal', 'Operations', 0, 'EReal', 'exists_lt_add_right'],
        # and the module name is ["Init", "Nat"], we need to remove the prefix and get the real name "add"  
        if name is None or len(name) == 0:
            return None
        
        if name[0] == '_private':
            p_name = name[1:]
            module_name_array = self.name.split(".")
            if len(p_name) + 1 > len(module_name_array):
                name_prefix_array = p_name[:len(module_name_array)]
                if name_prefix_array == module_name_array:
                    p_name = p_name[len(name_prefix_array):]
            if not isinstance(p_name[0], int):
                print(f"ERROR decl.name: {name} format is invalid for private {p_name}")
                print(f"         p_name: {p_name}, module: {self.name}")
            else:
                name = p_name[1:]
        return ".".join([str(item) for item in name ])
    
    def _getName(self, signatureRange: LeanFileRange, raw_name: str):
        statement_name = raw_name
        bprint = False
        if signatureRange:
            pre_signatureRange = LeanFileRange(LeanFilePos(signatureRange.start.line - 1, 1), signatureRange.start)
            pre_signature = self.getLeanFile().getTextFromLineModule(pre_signatureRange)[:-1].strip()
            index = pre_signature.rfind(" ")
            if index >= 0:
                check_name = pre_signature[index:].strip()
            else:
                check_name = pre_signature[:].strip()
            if statement_name.endswith(check_name) or check_name.startswith("_root_"):
                return check_name
        return statement_name
    
    def _createSignatureAndValue(self, decl: CoreDeclaration, leanFile: LeanFile,fileRange: LeanFileRange):
        signatureRange = leanFile.createFileRange(decl.signature.range) if decl.signature and decl.signature.range else None
        valueRange = leanFile.createFileRange(decl.value.range) if decl.value and decl.value.range else None
        adjustment = False
        signature = leanFile.getTextFromLineModule(signatureRange) if signatureRange else None
        if signatureRange:
            if valueRange is None:
                next_pos = leanFile.nextPos(signatureRange.stop)
                if next_pos < fileRange.stop:
                    valueRange = LeanFileRange(next_pos, fileRange.stop)
                    adjustment = True
            if valueRange and signatureRange == valueRange:
                valueRange = None
        if valueRange and valueRange.stop < fileRange.stop:
            valueRange = LeanFileRange(valueRange.start, fileRange.stop)
        value = leanFile.getTextFromLineModule(valueRange) if valueRange else None
        if valueRange and signatureRange and signatureRange.stop == valueRange.start:
            last_signature_char = signature[-1]
            if last_signature_char == ":" or last_signature_char == "-":
                signature, signatureRange, value, valueRange = \
                    self._move_left_one_position(signature, signatureRange, value, valueRange)
        elif adjustment: # bug in extract to have ":" when no space between ":=" or "--" 
            last_signature_char = signature[-1]
            if last_signature_char == ":" or last_signature_char == "-":
                signature, signatureRange, value, valueRange = \
                self._move_left_one_position(signature, signatureRange, value, valueRange)
        if value and value.strip().startswith("|") and not value.strip(" \t").startswith("\n"):
            if signature[-1] == "\n":
                signature, signatureRange, value, valueRange = \
                    self._move_left_one_position(signature, signatureRange, value, valueRange)
            else:
                valueRange = LeanFileRange(LeanFilePos(signatureRange.stop.line, signatureRange.stop.column+1), valueRange.stop) 
                value = "\n" + value #some issue to lost last line feed
        signature = leanFile.remove_comment(signature) if signature else None
        value = leanFile.remove_comment(value).rstrip() if value else None
        return signature, signatureRange, value, valueRange
    
    def _move_left_one_position(self, signature, signatureRange, value, valueRange):
        last_signature_char = signature[-1]
        signature = signature[:-1]
        value = last_signature_char + value
        valueRange = LeanFileRange(signatureRange.stop, valueRange.stop)
        signatureRange = LeanFileRange(signatureRange.start,
                                       LeanFilePos(signatureRange.stop.line, signatureRange.stop.column-1))          
        return signature, signatureRange, value, valueRange
    
    
    def _createScopeInfo(self, decl: CoreDeclaration):
        namespace = ".".join(decl.scope_info.curr_namespace) if decl.scope_info and decl.scope_info.curr_namespace else None
        omit_vars = decl.scope_info.omit_vars if decl.scope_info and decl.scope_info.omit_vars else None
        open_decl = None
        if decl.scope_info and decl.scope_info.open_decl:
            open_decl = []
            for open_dl in decl.scope_info.open_decl:
                if open_dl.simple:
                    open_ns = ".".join(open_dl.simple.namespace)
                    open_decl.append(open_ns)
        scoped_open_decl = None
        if decl.scope_info and decl.scope_info.scoped_open_decl:
            scoped_open_decl = []
            for open_dl in decl.scope_info.scoped_open_decl:
                open_ns = ".".join(open_dl)
                if open_decl and not open_ns in open_decl and open_ns != namespace:
                    scoped_open_decl.append(open_ns)
        return ScopeInfo(decl.scope_info.var_decls, decl.scope_info.include_vars, omit_vars, namespace, open_decl, scoped_open_decl)
    
    def _createModifiers(self, decl: CoreDeclaration, leanFile: LeanFile):
        attrs = None
        for attr in decl.modifiers.visibility:
            attrs = []
            for attr in decl.modifiers.attrs:
                attrFileRange = leanFile.createFileRange(attr.stx)
                attrName = ".".join(attr.name)
                attrContent = leanFile.remove_comment(leanFile.getTextFromLineModule(attrFileRange)) if attrFileRange else None
                if attrContent and (attrContent.endswith("]") or attrContent.endswith(",")):
                    attrContent = attrContent.strip()[:-1].strip()
                else:
                    attrExFileRange = LeanFileRange(attrFileRange.stop, LeanFilePos(attrFileRange.stop.line, sys.maxsize))
                    attrEx = leanFile.getTextFromLineModule(attrExFileRange)[1:]
                    attrCommaIndex = attrEx.find(",")
                    attrEndIndex = attrEx.find("]")
                    if attrCommaIndex >= 0 and attrCommaIndex < attrEndIndex:
                        attrContent = attrContent + attrEx[:attrCommaIndex].strip()
                    elif attrEndIndex >= 0:
                        attrContent = attrContent + attrEx[:attrEndIndex].strip()
                attrs.append(Attribute(attr.kind, attrName, attrContent, attrFileRange))

        return Modifiers(
                decl.modifiers.visibility if decl.modifiers.visibility != "regular" else None,
                attrs,
                decl.modifiers.compute_kind if decl.modifiers.compute_kind != "regular" else None,
                decl.modifiers.rec_kind if decl.modifiers.rec_kind != "default" else None,
                decl.modifiers.is_unsafe
            )

    def _validate_namespace_prefix(self, leanFile, reference, name, src_name, range):
        if range is None or src_name is None:
            return None
        nz_name = src_name.strip()
        if len(nz_name) == 0:
            return None
        
        if src_name in Symbol_Unsafe_src_names:
            return False, "reserve src keyword with namespace"
        
        if src_name in Symbol_Unsafe_names:
            return False, "reserve keyword with namespace"
        #if reference.explicit_arg_names and len(reference.explicit_arg_names) > 0:
        #    return None, "with excplict arguements"

        if " " in nz_name or "(" in nz_name or "[" in nz_name or "{" in nz_name:
            return False, "Not ident with (space),([{"
        if not nz_name[0].isalpha() :
            return False, "Not ident with none ident characters"
        
        #if not re.match(r'^[a-zA-Z_]', src_name.strip()):
        #    return False, "Not ident with none ident characters"
        if name != src_name and not name.endswith("." + src_name):
            return  False,"Not namespace prefix"
        
        line = range.start.line
        if range.start.column > 1:
            prerange = LeanFileRange(LeanFilePos(line, 1), LeanFilePos(line, range.start.column -1))
            pre_str = self.normalize(leanFile.getTextFromLineModule(prerange))
            if pre_str.endswith("."):
                return False, "prefix ."
            if pre_str.endswith("@"):
                pre_str = pre_str[:-1]
            if pre_str.strip().endswith(" |") or pre_str.strip() == "|":
                return False, "induction |"    
        postrange = LeanFileRange(LeanFilePos(line, range.stop.column + 1), LeanFilePos(line, sys.maxsize))
        post_str = leanFile.getTextFromLineModule(postrange)
        if post_str.startswith("(") or post_str.startswith("[") or post_str.startswith("["):
            return False, "macro with () or []"
        if len(post_str) > 0 and (post_str[0].isalpha() or post_str[0].isdigit() or post_str[0] == "'" or post_str[0] == "_" or not post_str[0].isascii()):
            return False, "partial ident"
        return True, None

    def normalize(self, str):
        str = str.replace("\t", " ").replace("\r", " ").replace("\n", " ")
        return " ".join(str.split())
    
def get_in_statement_prefix(full_source, decl_start_pos, scoped_open_names):
    """
    full_source: 移除註解後的原始碼字串
    decl_start_pos: 定理起始的 byte_offset
    scoped_open_names: Lean getScopeInfo 回傳的 ["Function", "MeasureTheory", ...]
    """
    # 1. 往回抓取一段文字（例如 200 字元，足以包含一個 open scoped 指令）
    lookback_fragment = full_source[max(0, decl_start_pos - 200):decl_start_pos].strip()
    
    # 2. 正則表達式：尋找以 'in' 結尾的指令
    # 模式說明：(指令類型) (內容) in (結尾可選空白)
    # 範例：open scoped Function in
    in_pattern = r"(open\s+scoped\s+([\w\.]+)\s+in)\s*$"
    match = re.search(in_pattern, lookback_fragment)
    
    if match:
        full_in_stmt = match.group(1) # "open scoped Function in"
        ns_name = match.group(2)      # "Function"
        
        # 3. 交叉驗證：檢查這個命名空間是否在 Lean 報出的 scopedOpenDecl 裡
        if ns_name in scoped_open_names:
            return full_in_stmt
            
    return ""

