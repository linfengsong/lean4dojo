import sys
import re
from typing import Optional
from dataclasses import dataclass
from dataclasses_json import dataclass_json
from .lean_file import LeanFile, LeanFileRange, LeanFilePos

@dataclass_json
@dataclass(frozen=True)
class LeanBlock:
    kind : str
    name : str
    content: str
    range : LeanFileRange
    index: int

    def __str__(self):
        return self.to_json()
    
@dataclass_json
@dataclass(frozen=True)
class LeanNamespaceBlock(LeanBlock):
    pass

@dataclass_json
@dataclass(frozen=True)
class LeanNamespaceBlock(LeanBlock):
    pass

@dataclass_json
@dataclass(frozen=True)
class LeanNamespaces:
    namespaces: list[LeanNamespaceBlock]

    def __init__(self, namespace: list[LeanNamespaceBlock]):
        namespaces = sorted(namespace, key=lambda x: x.range)
        object.__setattr__(self, 'namespaces', namespaces)

    def get_full_namespace(self, range: LeanFileRange):
        names = []
        for namespace in self.namespaces:
            if namespace.range.start > range.start:
                break
            if namespace.range.inRange(range):
                names.append(namespace.name)
        return ".".join(names) if len(names) > 0 else None



