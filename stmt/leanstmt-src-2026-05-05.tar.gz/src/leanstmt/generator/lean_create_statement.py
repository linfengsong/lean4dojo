import sys
from dataclasses import dataclass
from operator import attrgetter
from .lean_create_module import LeanCreateModule
from .lean_statement import Statement
from .lean_file import LeanFileRange, LeanFilePos
from .lean_module import LeanSymbolReference

Lean_keywords = [
    "def", "theorem", "lemma", "example",
    "inductive", "structure", "class", "instance",
    "opaque", "constant", "axiom", "abbrev",
    "variable", "variables",
    "if", "then", "else",
    "match", "nomatch", "with",
    "do", "let", "mut",
    "for", "in", "at",
    "try", "catch", "finally",
    "return", "break", "continue",
    "forall", "exists",
    "fun", "λ",
    "have", "show", "suffices",
    "by",
    "from",
    "import", "prelude", "namespace", "section", "end",
    "open", "export", "hiding", "renaming",
    "private", "protected", "noncomputable", "unsafe", "partial",

    "infix", "infixl", "infixr",
    "postfix", "prefix",
    "notation",
    "macro",
    "syntax",
    "declare_syntax_cat", 
    "intro", "intros",
    "apply", "exact", "refine",
    "cases", "induction",
    "rewrite", "rw",
    "simp", "dsimp", "aesop",
    "refl", "rfl",
    "const",
    "attribute",
    "elab", "elab_rules", 
    "sorry",
    "forall", "exists",
    "true", "false" 
    "cexp",
]

class ExclusiveConfig: 
    def __init__(self, data: dict[str, list[str]]):
        self.config: dict[str, list[str]] = data

    def getConfigList(self, name: str):
        if self.config is None:
            return None
        return self.config[name] if name in self.config.keys() else None
    
@dataclass(frozen=True)
class ConfigParameter:
    name: str
    arguments: dict = None

@dataclass(frozen=True)
class ContextText:
    text: str
    comment: str
    pos: LeanFilePos
    blockIndex: int = 0

class LeanCreateStatement:
    module: LeanCreateModule
    statement: Statement
    persistant_symbol_names: set

    @property
    def id(self):
        return self.statement.id

    @property
    def name(self):
        return self.statement.name
    
    @property
    def kind(self):
        return self.statement.kind
    
    def __init__(self, module: LeanCreateModule, statement: Statement, persistant_symbol_names: set, 
                 dependent_statements: set):
        self.module = module
        self.statement = statement
        self.persistant_symbol_names = persistant_symbol_names
        self.dependent_statements = dependent_statements

    def get_full_name(self):
        return self.statement.get_full_name()

    def create_lean_text(self, file, configParameters = None):
        namespace = self.statement.scope_info.namespace.strip() if self.statement.scope_info.namespace else None
        if file: print(f"statement.name: |{self.statement.name}| namespace: |{namespace}|", file=file)

        if configParameters:
            for config_parameter in configParameters:
                if config_parameter.name == "instance":
                    instance_ids = self.getInstanceIds()        
                    for instance_id in instance_ids:
                        self.dependent_statements.add(instance_id)

        required_statement_ids = self.module.getDependentStatements(self, file)
        
        contexts = []
        reserveFileRanges = []
        primaryFileRange = self.statement.fileRange
        alterStatements = None
        include_statement_ids = set()
        for stmt_id in sorted(required_statement_ids):
            stmt = self.module.getStatement(stmt_id)            
            assert stmt is not None
            if stmt.statement.fileRange.start > primaryFileRange.stop:
                continue
            if not stmt.statement.is_private() and not stmt.name in include_statement_ids:
                include_statement_ids.add(stmt.id)
            stmt_namespace, stmt_name = self.needNamespace(contexts, stmt)
            isValid, text = self.create_statement_text(stmt, stmt_namespace, stmt_name, include_statement_ids, file)
            if stmt.id == self.statement.id:
                primaryIsValid = isValid
                primary_text = text
                alterStatements = self.getAlterStatements(stmt, stmt_namespace, stmt_name)
            elif isValid:
                contexts.append(ContextText(text, "", stmt.statement.fileRange.start))
            reserveFileRanges.append(stmt.statement.fileRange)

        post_contexts = self.create_local_context(contexts, self.statement.fileRange, reserveFileRanges, namespace, file)

        text = ""
        imprts = self.module.getImports()
        if imprts:
            for imprt in imprts:
                imprt_name = ".".join(imprt).strip() 
                if imprt_name != "Init":
                    text += "import " + imprt_name + "\n"

        text += "import " + self.module.module_name + " -- module name\n"

        num_in = 0
        for context in reversed(contexts):
            if self.normalize(context.text).endswith(" in"):
                num_in += 1
            else:
                break
        if contexts and len(contexts) > 0:
            for context in contexts[:-num_in] if num_in > 0 else contexts:
                text += context.text
                text += f" -- {context.comment}\n" if context.comment and file else "\n"

        if alterStatements:
            text += alterStatements.strip() + "\n"
        if num_in > 0:
            for context in contexts[len(contexts)-num_in:]:
                text += context.text
                text += f" -- {context.comment}\n" if context.comment and file else "\n"

        if primaryIsValid:
            text += primary_text.strip() + "\n"
            for context in post_contexts:
                text += context.text
                text += f" -- {context.comment}\n" if context.comment and file else "\n"
            return True, text
        else:
            return False, primary_text
        
    def getInstanceIds(self):
        instance_ids = []
        for stmt in self.module.getStatements():
            if stmt.kind == "instance" and stmt.statement.fileRange.start < self.statement.fileRange.start:
                instance_ids.append(stmt.id)
        return instance_ids
        
    def needNamespace(self, contexts, statement):
        statement_name = statement.name
        if statement_name is None:
            return None, None
        name_parts = statement_name.split(".")
        if len(name_parts) > 1:
            statement_namespace = ".".join(name_parts[:-1])
        else:
            return None, statement_name
        for context in contexts:
            nz_context = self.normalize(context.text)
            if not nz_context.startswith("namespace "):
                continue
            if nz_context.endswith(statement_namespace):
                return None, statement_name
        has_namespace = False
        for stmt in self.module.getStatements():
            if stmt.name is None or stmt.name == statement.name:
                continue
            if stmt.statement.is_private():
                continue
            stmt_name_parts = stmt.name.split(".")
            if len(stmt_name_parts) == 1:
                continue
            st_ns = ".".join(stmt_name_parts[:-1])
            if st_ns.endswith(statement_namespace):
                has_namespace = True
        if not has_namespace:
            return None, statement_name
            
        return statement_namespace, statement_name

    def get_content_entry_name(self, kind, entry_content):
        entry_content = entry_content.replace("\n", " ").replace("\t", " ").replace("\r", " ").replace("()", " ").replace("[", " ")
        parts = entry_content.split(" " + kind + " ")
        if len(parts) < 2:
            return None
        if not (" private "  in " " + parts[0] + " "):
            return None
        parts = parts[1].split(" ")
        if len(parts) < 2:
            return None
        return parts[0].strip()

    def get_scope_info_by_range(self, fileRange,):
        inRangeNamespaces = []
        outRangeNamespaaces = []
        current_namespace_parts = []
        for scopeInfo in self.module.getScopeRangeInfos():
            if scopeInfo.range is None or scopeInfo.name is None or scopeInfo.kind != "namespace":
                continue
            if scopeInfo.range.start > fileRange.stop or scopeInfo.range.stop < fileRange.start:
                outRangeNamespaaces.append(scopeInfo)
            else:
                inRangeNamespaces.append(scopeInfo)
                current_namespace_parts.append(scopeInfo.name)
        range_namespace = ".".join(current_namespace_parts) if len(current_namespace_parts) > 0 else None
        return range_namespace, inRangeNamespaces, outRangeNamespaaces
    
    def get_statement_name_namespace(self, statement_name):
        if statement_name is None:
            return None, None
        name_parts = statement_name.split(".")
        if len(name_parts) == 1:
            return None, statement_name
        return ".".join(name_parts[:-1]), name_parts[-1]
    
    def addSymbols(self, symbolWithReasons, symbols, replaceDict, file):
        for symbol, msg, is_add in symbolWithReasons:
            str_symbol_range = str(symbol.range)
            if is_add:
                if not str_symbol_range in replaceDict.keys():
                    symbols.append(symbol)
                    replaceDict[str_symbol_range] = symbol
                    if file and msg: print(f"replace symbol with {msg}: {symbol}", file=file)
            else:
                if str_symbol_range in replaceDict.keys():
                    in_symbol = replaceDict.pop(str_symbol_range)
                    symbols.remove(in_symbol)
                    if file and msg: print(f"replace symbol with {msg}: {symbol}", file=file)
    
    def getSymbbolInOpenRestrict(self, refSymbols, open_namespace):
        symbolWithReasons = []
        if refSymbols is None:
            return symbolWithReasons
        for symbol in refSymbols:
            if symbol.is_private or symbol.range is None or not symbol.prefix_safe:
                continue
            if symbol.src_name == open_namespace:
                symbolWithReasons.append((symbol, "open restriction", True))
        return symbolWithReasons
    
    def getAlterStatements(self, stmt, stmt_namespace, statement_name):
        if self.module.alter_namespace is None or stmt.statement.modifiers and stmt.statement.modifiers.visibility == "private":
            return None
        if stmt.statement.modifiers:
            for attr in stmt.statement.modifiers.attrs:
                if attr.content == "simp":
                    if statement_name.startswith("_root_."):
                        name = statement_name
                    else:
                        name = self.get_full_name()
                    return f"attribute [-simp] {name}"
        return None

    def getAlternameSymbol(self, statement_name, symbol, include_statement_ids):
        if self.module.alter_namespace is None:
            return NotImplemented
        found_statement = None
        for id in include_statement_ids:
            statement = self.module.getStatement(id)
            stmt_full_name = statement.get_full_name()
            if stmt_full_name.endswith("." + symbol.name) or stmt_full_name == symbol.name:
                found_statement =  statement
        if found_statement is None:
            return None
        alter_name = self.getAltername(symbol.name)
        return  LeanSymbolReference(alter_name, symbol.src_name, symbol.range, True)
    
    def getAltername(self, name):
        if name == None:
            return None
        if self.module.alter_namespace is None:
            return name
        name_parts = name.split(".")
        alter_name = self.module.alter_namespace + "." + name_parts[-1]
        if len(name_parts) > 1:
            alter_name = ".".join(name_parts[:-1]) + "." + alter_name
        return alter_name
    
    def getSymbolByNamespace(self, refSymbols, refRange, statement_name, is_private, current_namespace, statement_namespace, inRange_namespace, force_symbol_namespaces, open_namespaces, include_statement_ids, file):
        symbolWithReasons = []
        if refSymbols is None:
            return symbolWithReasons
        
        all_namespaces = self.module.all_namespaces
        
        hasStatementName = False
        for symbol in refSymbols:
            if symbol.name.endswith(statement_name):
                hasStatementName = True
            if symbol.is_private and symbol.range is None or not symbol.prefix_safe:
                continue
            if not is_private and self.module.alter_namespace and len(include_statement_ids) > 0:
                alternameSymbol = self.getAlternameSymbol(statement_name, symbol, include_statement_ids)
                if alternameSymbol:
                    if file: print(f" replace symbol for: {alternameSymbol.name}: {symbol.name}", file=file)
                    symbolWithReasons.append((alternameSymbol, f"statement alter_name from {symbol.name}in range", True))
                    continue
            name_namespace, name_statement_name = self.get_statement_name_namespace(symbol.name)
            if symbol.name != symbol.src_name and symbol.name.endswith(symbol.src_name):
                shadow_namespace = False
                for ns in all_namespaces:
                    if ns.endswith(name_namespace) and ns != name_namespace:
                        shadow_namespace = True
                if shadow_namespace:
                    symbolWithReasons.append((symbol, "namespace shadow with module", True))
                    continue

            if name_namespace:                    
                if name_statement_name != symbol.src_name:
                    continue
                if name_namespace in force_symbol_namespaces:
                    symbolWithReasons.append((symbol, "open conflict", True))
                    continue
                if  statement_namespace is None and current_namespace and symbol.name.endswith(current_namespace + "." + symbol.src_name):
                    symbolWithReasons.append((symbol, "statement prefix namespace", True))
                    continue

                if current_namespace is None:
                    continue
                if name_namespace in open_namespaces:
                    continue

                alter_current_namespace = current_namespace if current_namespace else None
                if alter_current_namespace and inRange_namespace:
                    alter_current_namespace = inRange_namespace + "." + alter_current_namespace
                in_current_namespace = (name_namespace == inRange_namespace or inRange_namespace.startswith(name_namespace + ".")) if inRange_namespace else False
                if not in_current_namespace and alter_current_namespace:
                    in_current_namespace = name_namespace == alter_current_namespace
                if not in_current_namespace or in_current_namespace and current_namespace == name_namespace and statement_namespace is None:
                    symbolWithReasons.append((symbol, "statement in range", True))
        if not is_private and refRange and not hasStatementName and "." in statement_name:
            leanFile = self.module.getLeanFile()
            altername = self.getAltername(statement_name)
            ranges = leanFile.get_ident_ranges(statement_name, refRange)
            for range in ranges:
                symbol = LeanSymbolReference(altername, statement_name, range, True)
                refSymbols.append(symbol)
                symbolWithReasons.append((symbol, "recursive", True))
        return symbolWithReasons
    
    def isStatementMatchSymbol(self, statement, symbol):
        stmt_full_name = statement.get_full_name()
        if symbol.src_name is None:
            return False
        
        if stmt_full_name is None:
            return False
        stmt_name_parts = stmt_full_name.split(".")
        symbol_name_parts = symbol.src_name.split(".")

        for index, part in enumerate(reversed(stmt_name_parts)):
            if len(symbol_name_parts) <= index:
                return True
            if part != symbol_name_parts[index-1]:
                return False
        return True
    
    def hasSymbolByStatement(self, refSymbols, fileRange, stmt, file):
        private_kinds = ["theorem", "definition", "inductive", "abbrev", "structure", "instance"]

        stmt_name = stmt.name
        stmt_range = stmt.fileRange
        is_private = stmt.kind in private_kinds and stmt.modifiers and stmt.modifiers.visibility == "private"
        if stmt.modifiers and stmt.modifiers.attrs:
            for attr in stmt.modifiers.attrs:
                if attr.kind == "local":
                    is_private = True

        has_stmt_symbol = False
        for symbol in refSymbols:
            if is_private and stmt_range.stop < fileRange.start and self.isStatementMatchSymbol(stmt, symbol):
                has_stmt_symbol = True
                if file: print(f"private statement in symbole: stmt_name: {stmt_name}, symbol.name: {symbol.name} ", file=file)

        return has_stmt_symbol

    def getSymbolByStatement(self, refSymbols, fileRange, statement_name, inRangeNamespaces, stmt, include_statement_names, file):
        if refSymbols is None:
            return []
        if stmt.name is None:
            return []
        
        if stmt.name in include_statement_names:
            return []
        
        stmt_name = stmt.name
        stmt_range = stmt.statement.fileRange

        symbolWithReasons = []

        for symbol in refSymbols:
            if symbol.is_private or symbol.range is None or not symbol.prefix_safe:
                continue
            if symbol.name == stmt_name or symbol.name.endswith("." + stmt_name) or stmt_name == symbol.src_name  or stmt_name.endswith("." + symbol.src_name):
                if file: print(f"replace check stmt_name: {stmt_name}: {symbol}", file=file)                   
                if symbol.name == symbol.src_name:
                    if fileRange.start <= stmt_range.start:
                        symbolWithReasons.append((symbol, None, False))
                        if file: print(f" create root symbol: {symbol}", file=file)
                        symbol = LeanSymbolReference("_root_." + symbol.name, symbol.src_name, symbol.range, True)
                    else:
                        if file: print(f"replace exclude symbol name and src_name equals and {fileRange.start} > {stmt_range.start}: {symbol}", file=file)
                        continue
                    
                if statement_name != symbol.src_name and not statement_name.endswith("." + symbol.src_name):
                    name = symbol.name
                    for scopeInfo in inRangeNamespaces:
                        if name.startswith(scopeInfo.name):
                            if name[len(scopeInfo.name) + 1:] == symbol.src_name:
                                name = None
                                break
                    if name is None and fileRange.start > stmt_range.start:
                        if file: print(f"replace exclude symbol in namespace and statement before current: {symbol}", file=file)
                        continue
                symbolWithReasons.append((symbol, "statement", True))
        return symbolWithReasons

    def get_replace_symbols(self, statement, statement_namespace, statement_name, include_statement_names, file):
        statementSymbol = self.module.getStatementSymbol(statement)
        fileRange = statement.statement.fileRange
    
        if statementSymbol is None:
            if file: print(f"statement_name: {statement_name}, statementSymbol is None ", file=file)
            return [], []
        
        if statementSymbol.signature_symbols:
            if file: print(f"statement_name: {statement_name}, signature_symbols: {len(statementSymbol.signature_symbols)}", file=file)
            for symbol in statementSymbol.signature_symbols:
                if file: print(f"    name: {symbol.name}, src_name: {symbol.src_name}, is_private: {symbol.is_private}, prefix_safe: {symbol.prefix_safe}, prefix_reason: {symbol.prefix_reason}, range: {symbol.range}", file=file)
        else:
            if file: print(f"statement_name: {statement_name}, statementSymbol.signature_symbols is None ", file=file)
        if statementSymbol.value_symbols:
            if file: print(f"statement_name: {statement_name}, value_symbols: {len(statementSymbol.value_symbols)}", file=file)
            for symbol in statementSymbol.value_symbols:
                if file: print(f"    name: {symbol.name}, src_name: {symbol.src_name}, is_private: {symbol.is_private}, prefix_safe: {symbol.prefix_safe}, prefix_reason: {symbol.prefix_reason}, range: {symbol.range}", file=file)
        else:
            if file: print(f"statement_name: {statement_name}, statementSymbol.value_symbols is None ", file=file)
        inRange_namespace, inRangeNamespaces, outRangeNamespaaces = self.get_scope_info_by_range(fileRange)

        signatureSymbols = []
        signatureReplaceDict = {}
        valueSymbols = []
        valueReplaceDict = {}
        statement_namespace_set = set()
        current_statement = None
        statement_last_parts = []
        for stmt in self.module.getStatements():
            if stmt.statement.fileRange.start == fileRange.start:
                current_statement = stmt
            if stmt.name:
                name_parts = stmt.name.split(".")
                statement_last_part = name_parts[-1] if len(name_parts) > 1 else stmt.name
                statement_last_parts.append(statement_last_part)
                name_parts = stmt.name.split(".")
                if len(name_parts) > 1:
                    last_ns = name_parts[-2]
                    if not last_ns in statement_namespace_set:
                        statement_namespace_set.add(last_ns)

        force_symbol_namespaces = []
        open_namespaces = []
        for entry in self.module.getContextEntries():
            context = entry.content.rstrip()
            nz_context = self.normalize(context.replace("(", " ( ").replace(")", " ) "))
            if not nz_context.startswith("open "):
                continue

            ns_list_str = nz_context[4:]            
            index = nz_context.find("(")
            if index > 0:
                ns_list_str = ns_list_str[:index]
                open_ns_specs = nz_context[index + 1: -1].strip().split(" ")
                for ns_spec in open_ns_specs:
                    self.addSymbols(self.getSymbbolInOpenRestrict(statementSymbol.signature_symbols, ns_spec.strip()), 
                                    signatureSymbols, signatureReplaceDict, file)
                    self.addSymbols(self.getSymbbolInOpenRestrict(statementSymbol.value_symbols, ns_spec.strip()), 
                                    valueSymbols, valueReplaceDict, file)
            ns_list = ns_list_str.strip().split(" ")
            for ns in ns_list:
                if ns in statement_namespace_set and not ns in force_symbol_namespaces:
                    force_symbol_namespaces.append(ns)
                if ns not in open_namespaces:
                    open_namespaces.append(ns)
        current_namespace, _ = self.get_statement_name_namespace(statement_name)
        self.addSymbols(
            self.getSymbolByNamespace(statementSymbol.signature_symbols, statement.statement.signatureRange, statement_name, statement.statement.is_private(), current_namespace, statement_namespace, inRange_namespace, force_symbol_namespaces, open_namespaces, include_statement_names, file),
            signatureSymbols, signatureReplaceDict, file)
        self.addSymbols(
            self.getSymbolByNamespace(statementSymbol.value_symbols, statement.statement.valueRange, statement_name, statement.statement.is_private(), current_namespace, statement_namespace, inRange_namespace, force_symbol_namespaces, open_namespaces, include_statement_names, file),
            valueSymbols, valueReplaceDict, file)
       
        for stmt in self.module.getStatements():
            sigSymbols = self.getSymbolByStatement(statementSymbol.signature_symbols, fileRange, statement_name, inRangeNamespaces, stmt, include_statement_names, file)
            self.addSymbols(sigSymbols, signatureSymbols, signatureReplaceDict, file)
            
            valSymbols  = self.getSymbolByStatement(statementSymbol.value_symbols, fileRange, statement_name, inRangeNamespaces, stmt, include_statement_names, file)
            self.addSymbols(valSymbols, valueSymbols, valueReplaceDict, file)

        tactics = self.module.module.getStatementTactic(current_statement.statement)
        if tactics:
            sigSymbols = []
            valSymbols = []
            inTactic = None
            for tactic in tactics:
                tacticRange = tactic.range
                for symbol in signatureSymbols:
                    if tacticRange.inRange(symbol.range):
                        inTactic = tactic
                for symbol in valueSymbols:
                    if tacticRange.inRange(symbol.range):
                        inTactic = tactic
            if inTactic is None:
                sigSymbols.append(symbol)
            else:
                if file: print(f"    name: {symbol.name}, src_name: {symbol.src_name} in tactic: {inTactic.tacticName}", file=file)
        else:
            sigSymbols = signatureSymbols
            valSymbols = valueSymbols           
        if file: print(f"current_theorem_name: {current_statement.name}, replace_signature_symbols: {len(sigSymbols)}, replace_value_symbols: {len(valSymbols)}", file=file)
        return sorted(sigSymbols, key=lambda x: x.range, reverse=True), sorted(valSymbols, key=lambda x: x.range, reverse=True)
    
    def create_local_context(self, texts, fileRange: LeanFileRange, reserveFileRanges: list,namespace: str, file):

        if file: print(f"scopeInfo check fileRange: {fileRange}", file=file)
        
        ex_texts = []
        last_stop_pos = None
        
        exclude_ranges =[]
        ecllude_namesspaces = []
        block_index = 0
        current_namespaces = []
        for scopeInfo in self.module.getScopeRangeInfos():
            hasStatement = False
            for range in reserveFileRanges:
                if scopeInfo.range.inRange(range):
                    hasStatement = True
            if scopeInfo.kind == "section":
                if not hasStatement:
                    exclude_ranges.append(scopeInfo.range)
                    if file: print(f"add exclude section range: {scopeInfo}", file=file)
                else:
                    block_index += 1
                    ex_texts.append(ContextText(scopeInfo.content, None, scopeInfo.range.start, block_index))
                    end_content = f"end {scopeInfo.name}" if scopeInfo.name else "end"
                    ex_texts.append(ContextText(end_content, None, scopeInfo.range.stop, -block_index))
                    if file: print(f"add texts: {scopeInfo.content}, {scopeInfo}", file=file)                                      
            elif scopeInfo.kind == "namespace":
                namespaces = scopeInfo.name.split(".")
                if not hasStatement:
                    exclude_ranges.append(scopeInfo.range)
                    ecllude_namesspaces.append(scopeInfo.name)
                    if file: print(f"add exclude namespace range: {scopeInfo}", file=file)
                else:
                    current_namespaces.extend(namespaces)
                    block_index += 1
                    name = scopeInfo.name
                    if not "." in name and "«" in scopeInfo.content:
                        name = f"«{name}»"

                    ex_texts.append(ContextText(f"namespace {name}", None, scopeInfo.range.start, block_index))
                    ex_texts.append(ContextText(f"end {name}", None, scopeInfo.range.stop, -block_index))
                    if file: print(f"add texts: namespace {namespace}, {scopeInfo}", file=file)

        ex_texts.sort(key=attrgetter("pos"))
        ex_texts.sort(key=attrgetter('blockIndex')) 

        last_stop_pos = fileRange.stop if last_stop_pos and last_stop_pos < fileRange.stop else fileRange.stop
        exclude_ranges.append(LeanFileRange(last_stop_pos, LeanFilePos(sys.maxsize, sys.maxsize)))
        context_dict = {}
        blocks = []
        for entry in self.module.getContextEntries(): 
            if entry.range.start > last_stop_pos:  
                continue
            invalid_entry = self.inRange(exclude_ranges, entry.range)
            if invalid_entry:
                if file: print(f"exclude variable: {entry.content}, variable.fileRange: {entry.range}, exclude_section_range: {exclude_ranges}", file=file)
                continue
            if entry.kind in ["notation", "notation3", "variable","open", "universe", "set_option", "noncomputable", "include", "custom_macro", "attribute", "in", "mixfix", "alias", "grindPattern", "macro", "macro_rules", "syntax", "prefix"]:
                if entry.kind == "set_option":
                    if "linter.indexVariables" in entry.content or "linter.listVariables" in entry.content: # Lean Internal variable
                        continue
                 
                self.append_ex_texts(ex_texts, blocks, texts, context_dict, entry.range.start, file)

                hasStatement = False
                for range in reserveFileRanges:
                    if entry.range.inRange(range):
                        hasStatement = True

                if entry.kind == "in" and not hasStatement:
                    continue
                context = entry.content.rstrip()
                nz_context = self.normalize(context)
                if entry.kind in ["notation", "notation3", "mixfix", "attribute", "macro", "macro_rules", "syntax", "prefix", "alias", "grindPattern", "custom_macro"]:
                    if not self.isLocalContext(entry):
                        continue

                if nz_context in context_dict:
                    previous_content = context_dict[nz_context]
                    del previous_content

                context_dict[nz_context] = context
                if file: print(f"add entry: {context}, entry.range: {entry.range}", file=file)
                comment = None #f"context kind: {entry.kind} {raw_kind}"
                texts.append(ContextText(context, comment, entry.range.start))

        self.append_ex_texts(ex_texts, blocks, texts, context_dict, fileRange.start, file)

        post_texts = []
        ex_texts = [ex_text for ex_text in ex_texts if ex_text.blockIndex != 0]
        for ex_text in ex_texts:
            if ex_text.pos < fileRange.stop or ex_text.blockIndex == 0:
                continue
            blockIndex = -ex_text.blockIndex 
            if blockIndex in blocks:
                print(f"add post_text: {ex_text.text}, ex_text.range: {ex_text.pos}, blockIndex: {ex_text.blockIndex}", file=file)
                post_texts.append(ex_text)
        
        texts.sort(key=attrgetter("pos"))
        return post_texts
    
    def isLocalContext(self, entry):
        content = entry.content.rstrip()
        nz_content = self.normalize(content)
        if nz_content.startswith("@["):
            index = nz_content.find("]")
            if index > 0:
                nz_content = nz_content[index + 1:].strip()
        if nz_content.startswith("local") or nz_content.startswith("private"): #or nz_context.startswith("scoped") 
            return True
        args = entry.getArguments()
        if args and "local" in args:
            return True
        return False
    
    def inRange(self, ranges, check_range):
        for exclude_range in ranges:
            if exclude_range.inRange(check_range):
                return True
        return False
    
    def append_ex_texts(self, ex_texts, blocks, texts, context_dict, currentPos: LeanFilePos, file):
        i = 0
        for ex_text in ex_texts[:]:
            if ex_text.pos >= currentPos:
                continue
            if ex_text.blockIndex:
                if ex_text.text.startswith("end"):
                    if ex_text.blockIndex in blocks:
                        blocks.remove(ex_text.blockIndex)
                    elif -ex_text.blockIndex in blocks:
                        blocks.remove(-ex_text.blockIndex) 
                else:
                    blocks.append(ex_text.blockIndex)
            nz_context = self.normalize(ex_text.text)
            if nz_context in context_dict:
                previous_content = context_dict[nz_context]
                del previous_content
                
            context_dict[nz_context] = ex_text
            if file: print(f"add ex_text: {ex_text.text}, ex_text.rangepos: {ex_text.pos}", file=file)
            texts.append(ex_text)
            ex_texts.remove(ex_text) 
        
    def create_statement_text(self, stmt: Statement, statement_namespace, statement_name: str, include_statement_names, file):
        statement = stmt.statement
        if file: print(f"statement internal_name: {statement.internal_name}, kind: {statement.kind}, theorem name: {statement_name}", file=file)
        signature_symbols, value_symbols = self.get_replace_symbols(stmt, statement_namespace, statement_name, include_statement_names, file)

        text = ""
        attrs = self.create_attrs_text(statement.modifiers.attrs)
        if attrs:
            text += attrs.strip() + "\n"
        if statement.modifiers.visibility:
            text += statement.modifiers.visibility.strip() + " "
        if statement.modifiers.compute_kind:
            text += statement.modifiers.compute_kind.strip() + " "
        if statement.modifiers.rec_kind:
            text += statement.modifiers.rec_kind.strip() + " "
        if statement.modifiers.is_unsafe:
            text += "unsafe "
        if statement.modifiers.rec_kind_left:
            text += statement.modifiers.rec_kind_left.strip() + " "
        text += statement.command.strip() + " "
        if statement.modifiers.rec_kind_right:
            text += statement.modifiers.rec_kind_right.strip() + " "
        if statement_name:
            name = statement_name
            if not statement.is_private():
                name = self.getAltername(name)
            if statement.kind == "instance":
                name_parts = statement_name.split(".")
                last_part = name_parts[-1]
                if last_part.startswith("inst"):
                    index_parts = last_part.split("_")
                    if len(index_parts) > 1 and index_parts[-1].isdigit():
                        name = None
            if name:
                if name[:1].isascii():
                    text += name + " "
                else:
                    text += "\"" + name + "\" "
        if hasattr(statement, "signature") and statement.signature and statement.signatureRange:
            signature = self.replaceContent("signature", statement.signatureRange, signature_symbols, file) + " "
            text += signature
        if hasattr(statement, "value") and statement.value and statement.valueRange:         
            value = self.replaceContent("value", statement.valueRange, value_symbols, file).rstrip()
            text += value
        return True, text.strip()
    
    
    def replaceSymbolLine(self, line, range, symbol, src_name, replace_name, file):
        parts = symbol.src_name.rsplit(src_name, 1)
        replace_symbol = replace_name.join(parts)
        start_column = range.start.column if range.start.line == symbol.range.start.line else 1
        column_start = symbol.range.start.column - start_column                  
        column_stop = symbol.range.stop.column - start_column
        replace_line = line[:column_start] + replace_symbol + line[column_stop + 1:]
        if file: print(f"replaceContent: symbol {symbol}, range: {range}", file=file)
        return replace_line

    def replaceContent(self, symbolType: str, range: LeanFileRange, replace_symbols, file):
        if range is None:
            return None
        leanFile = self.module.getLeanFile()
        content = leanFile.getTextFromLineModule(range)
        lines = content.split("\n")
        for symbol in replace_symbols:
            replace_name = symbol.name
            src_name = symbol.src_name
            if not symbol.prefix_safe:
                if file: print(f"{symbolType} replaceContent skip not prefix_safe, src_name: {src_name}, symbol: {symbol}", file=file)
                continue
            if symbol.range is None or not range.inRange(symbol.range):
                if file: print(f"{symbolType} replaceContent not in range, src_name: {src_name}: range: {range}, symbol: {symbol}", file=file)
                continue
            line_index = symbol.range.start.line - range.start.line
            if src_name is None:
                if file: print(f"{symbolType} replaceContent Fail src_name: {src_name}, replace_name: {replace_name}, symbol: {symbol}", file=file)
                continue
            if src_name == replace_name:
                if file: print(f"{symbolType} replaceContent skip symbol src_name: {src_name}: {symbol}", file=file)
                continue
            if symbol.range.start.line != symbol.range.stop.line:
                if file: print(f"{symbolType} replaceContent Fail line: {symbol.src_name} {symbol.range.start.line}, {symbol.range.stop.line}", file=file)
                continue
            if line_index < 0 or line_index >= len(lines):
                if file: print(f"r{symbolType} eplaceContent Fail line range: {symbol.src_name} {range.start.line}, {symbol.range.start.line}, {len(lines)}", file=file)
                continue
            if symbol.range.stop.column - symbol.range.start.column + 1 != len(symbol.src_name):
                if file: print(f"{symbolType} replaceContent Fail column range: {symbol.src_name} {symbol.range.start.column}, {symbol.range.stop.column}, {len(symbol.src_name)}", file=file)
                continue
            lines[line_index] = self.replaceSymbolLine(lines[line_index], range, symbol, src_name, replace_name, file)
        return leanFile.remove_comment("\n".join(lines))

    def create_attrs_text(self, attrs: list):
        if attrs is None or len(attrs) == 0:
            return None
        text = ""
        for attr in attrs:
            if attr.name == "typevec":
                continue
            if attr.name == "to_additive":
                nz_content = self.normalize(attr.content.replace("(", "( ").replace(":=", " := "))
                if nz_content.startswith("to_additive ( attr := "):
                    continue

                if nz_content == "to_additive":
                    continue
            if attr.name and attr.name == "elementwise":
                continue
            if len(text) > 0:
                text += ", "
            if attr.kind and attr.kind != "global":
                text += attr.kind.strip() + " "
            
            text += attr.content.strip()
        if len(text) == 0:
            return None
        return f"@[{text}]"

    def normalize(self, str):
        str = str.replace("\t", " ").replace("\r", " ").replace("\n", " ")
        return " ".join(str.split())
