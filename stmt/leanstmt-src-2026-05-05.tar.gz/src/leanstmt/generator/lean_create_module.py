from dataclasses import dataclass
from leanstmt.generator.lean_module import LeanModule
from .lean_file import LeanFilePos, LeanFileRange

Lean_keywords = [
    "def", "theorem", "lemma", "example",
    "inductive", "structure", "class", "instance",
    "constant", "axiom", "abbrev",
    "variable", "variables",
    "if", "then", "else",
    "match", "nomatch", "with",
    "do", "let", "mut",
    "for", "in", "at",
    "try", "catch", "finally",
    "return", "break", "continue",
    "forall", "exists",
    "fun", "λ",
    "have", "show", "suffices",
    "by",
    "from",
    "import", "prelude", "namespace", "section", "end",
    "open", "export", "hiding", "renaming",
    "private", "protected", "noncomputable", "unsafe", "partial",

    "infix", "infixl", "infixr",
    "postfix", "prefix",
    "notation",
    "macro",
    "syntax",
    "declare_syntax_cat", 
    "intro", "intros",
    "apply", "exact", "refine",
    "cases", "induction",
    "rewrite", "rw",
    "simp", "dsimp", "aesop",
    "refl", "rfl",
    "abbrev",
    "opaque","axiom", "constant",
    "attribute",
    "elab", "elab_rules", 
    "sorry",
    "forall", "exists",
    "true", "false" 
    "cexp",
]

class ExclusiveConfig: 
    def __init__(self, data: dict[str, list[str]]):
        self.config: dict[str, list[str]] = data

    def getConfigList(self, name: str):
        if self.config is None:
            return None
        return self.config[name] if name in self.config.keys() else None

@dataclass(frozen=True)
class ContextText:
    text: str
    comment: str
    pos: LeanFilePos
    blockIndex: int = None

@dataclass(frozen=True)
class DependentStatement:
    fileRange: LeanFileRange
    dependentStatements: list
    privateSymbol: bool

@dataclass(frozen=True)
class ConfigParameter:
    namespace: str
    statement_name: str
    kind: str
    arguments: dict

class LeanCreateModule:
    alter_namespace: str = "LeanTest"
    config_parameters: list[ConfigParameter]

    def __init__(self, exclusiveConfig: ExclusiveConfig, module_name: str, module: LeanModule):
        self.exclusiveConfig = exclusiveConfig
        self.module_name = module_name
        self.module = module

        persistent_with_def = False
        statement_full_name_dict, persistant_name_dict = self._get_statement_name_dict(persistent_with_def)

        self._statements = []
        persistant_symbol_name_dict = {}
        all_namespaces = set()
        from .lean_create_statement import LeanCreateStatement
        for statement in module.statements:
            statementSymbol = self.module.getStatementSymbol(statement)
            dependent_statements = self._get_dependent_statements_from_symbols(statement_full_name_dict, statementSymbol)
            stmt_persistant_symbol_name_dict = self._get_persistant_symbol_name_dict(statementSymbol, persistant_name_dict)
            for name in stmt_persistant_symbol_name_dict.keys():
                if not name in persistant_symbol_name_dict.keys():
                    persistant_symbol_name_dict[name] = stmt_persistant_symbol_name_dict[name]
            stmt = LeanCreateStatement(self, statement, stmt_persistant_symbol_name_dict.keys(), dependent_statements)
            self._statements.append(stmt)
            if statement.internal_namespace and not statement.internal_namespace in all_namespaces:
                all_namespaces.add(statement.internal_namespace)

        self.persistant_symbol_name_dict = persistant_symbol_name_dict
        self.all_namespaces = all_namespaces

    def getStatements(self):
        return self._statements
    
    def getStatement(self, id):
        iId = int(id)
        if iId >= 0  and iId < len(self._statements):
            return self._statements[iId]
        return None
    
    def getScopeRangeInfos(self):
        return self.module.getScopeRangeInfos()
    
    def getCreateStatements(self):
        statements = []
        for statement in self._statements:
            if statement.statement.kind != "theorem":
                continue
            if statement.statement.is_private():
                continue
            statements.append(statement)
        return statements
    
    def hasPrivateInstances(self):
        for statement in self._statements:
            if statement.statement.kind == "instance" and statement.statement.is_private():
                return True
        return False
    
    def getStatementSymbol(self, statement):
        return self.module.getStatementSymbol(statement.statement)
    
    def getContextEntries(self):
        return self.module.getContextEntries()
    
    def getLeanFile(self):
        return self.module.getLeanFile()
    
    def getImports(self):
        return self.module.getImports()
    
    def getDependentStatements(self, statement, file):
        include_ids = set()
        include_ids.add(statement.id)
        required_ids = set()
        required_symbol_names = set()
        self._get_dependent_statements(statement, include_ids, required_ids, required_symbol_names, file)
        private_required_ids = set()
        self._add_private_statements(statement, include_ids, private_required_ids, file)
        for id in include_ids.copy():
            if not id in private_required_ids:
                stmt = self.getStatement(id)
                self._add_private_statements(stmt, include_ids, private_required_ids, file)
        return include_ids

    def _get_dependent_statements(self, statement, include_ids, required_ids, required_symbol_names, file):        
        request_start = statement.statement.fileRange.start
        request_id = statement.id
        if request_id in required_ids:
            return
        required_ids.add(request_id)
        if file: print(f"    processing statement: {statement.name}, {statement.get_full_name()} kind: {statement.kind}, id: {request_id}, dependent_statements: {statement.dependent_statements}, persistant_symbol_names: {statement.persistant_symbol_names}", file=file)
        for stmt_id in statement.dependent_statements:
            stmt = self.getStatement(stmt_id)
            if stmt.statement.fileRange.start < request_start:
                self._get_dependent_statements(stmt, include_ids, required_ids, required_symbol_names, file)
            if stmt_id in include_ids and not stmt.statement.is_private() and not request_id in include_ids:
                include_ids.add(request_id)
                if file: print(f"       dependent_statement add: {statement.name}, stmt_id: {stmt_id} in include_ids, request_id: {request_id}", file=file)

        for name in statement.persistant_symbol_names:
            statements = self.persistant_symbol_name_dict[name]
            if len(statements) > 0:
                if not request_id in include_ids:
                    if file: print(f"        persistant_symbol_names add: {statement.name}, stmt_id: {request_id}", file=file)
                    include_ids.add(request_id)
                    if request_id in required_ids:
                        required_ids.remove(request_id)
            if name in required_symbol_names:
                continue
            required_symbol_names.add(name)
            for stmt_id in statements:
                if not stmt_id in include_ids:
                    stmt = self.getStatement(stmt_id)
                    if stmt.statement.fileRange.start < request_start:
                        if file: print(f"        persistant_symbol_names add: {statement.name}, stmt_id: {stmt_id}", file=file)
                        include_ids.add(stmt_id)
                        self._get_dependent_statements(stmt, include_ids, required_ids, required_symbol_names, file)
        if file: print(f"      finish processing statement: {statement.name}, request_id: {request_id}", file=file)

    def _add_private_statements(self, statement, include_ids, required_ids, file):
        request_id = statement.id
        for stmt_id in statement.dependent_statements:
            if request_id == stmt_id or stmt_id in required_ids:
                continue
            required_ids.add(stmt_id)
            stmt = self.getStatement(stmt_id)
            if stmt.statement.is_private() and not stmt_id in include_ids:
                include_ids.add(stmt_id)
                if file: print(f"    add private statement: {statement.name}, stmt_id: {stmt_id} from statement: {request_id}", file=file)
            self._add_private_statements(stmt, include_ids, required_ids,file)
        

    def _get_all_reference_ids(self, statement):
        all_ref_ids = set()
        for id in statement.reference_statements:
            if id == statement.id:
                continue
            if not id in all_ref_ids:
                all_ref_ids.add(id)
            stmt = self.getStatement(id)
            ref_ids = self._get_all_reference_ids(stmt)
            for ref_id in ref_ids:
                if not ref_id in all_ref_ids:
                    all_ref_ids.add(ref_id)
        return all_ref_ids
    
    def _add_instance_statement_range_to_dict(self, statement, dict: dict, names: list):
        if names is None or len(names) == 0:
            return
        full_name = statement.get_full_name()
        if full_name is None:
            return
        ns_parts = full_name.split(".")
        nm = ns_parts[-1]
        if nm in names:
            ns = ".".join(ns_parts[:-1]) if len(ns_parts) > 1 else ""
            if not ns in dict.keys():
                range_dict = {}
                dict[ns] = range_dict
            else:
                range_dict = dict[ns]
            if not nm in range_dict.keys():
                range_dict[nm] = statement

    def _get_statement_name_dict(self, persistent_with_def):
        statement_full_name_dict = {}
        persistant_def_name_dict = {}
        
        inst_dict = {}
        private_names = set()
        for statement in self.module.statements:
            full_name = statement.get_full_name()
            if full_name:
                if full_name in statement_full_name_dict.keys():
                    dependentStatement = statement_full_name_dict[full_name]
                else:
                    dependentStatement = DependentStatement(statement.fileRange, [], True)
                    statement_full_name_dict[full_name] = dependentStatement
                dependentStatement.dependentStatements.append(statement.id)                
            if persistent_with_def and statement.kind == "definition":
                if not statement.is_public():
                    persistant_def_name_dict[full_name] = dependentStatement
                    if not full_name in private_names:
                        private_names.add(full_name)
                    name = statement.name
                    persistant_def_name_dict[name] = dependentStatement
                    if not name in private_names:
                        private_names.add(name)
            elif statement.kind == "irreducible_def":
                dependentStatement = DependentStatement(statement.fileRange, [], True)
                persistant_def_name_dict[full_name] = dependentStatement
                if not full_name in private_names:
                    private_names.add(full_name)
                name = statement.name
                persistant_def_name_dict[name] = dependentStatement
                if not name in private_names:
                    private_names.add(name)
                if name in statement_full_name_dict.keys():
                    dependentStatement = statement_full_name_dict[name]
                else:
                    dependentStatement = DependentStatement(statement.fileRange, [], True)
                    statement_full_name_dict[name] = dependentStatement
                dependentStatement.dependentStatements.append(statement.id)

            if statement.kind == "instance":
                self._add_instance_statement_range_to_dict(statement, inst_dict, ["instAdd_1", "instNeg_1", "instSub_1"])
        for ns in inst_dict.keys():
            stmt_dict = inst_dict[ns]
            if "instAdd_1" in stmt_dict.keys() and "instNeg_1" in stmt_dict.keys() and "instSub_1" in stmt_dict.keys():
                stmt = stmt_dict["instSub_1"]
                dependentStatement = DependentStatement(stmt.fileRange, [stmt.id], False)
                persistant_def_name_dict["sub_eq_add_neg"] = dependentStatement

        self._dependent_statements_for_persistant_symbol(private_names, persistant_def_name_dict)
        return statement_full_name_dict, persistant_def_name_dict

    def _dependent_statements_for_persistant_symbol(self, private_names, persistant_def_name_dict):
        #for name in persistant_symbol_name_dict.keys()
        for stmt in self.module.statements:
            statement_symbol = self.module.getStatementSymbol(stmt)
            symbol_names = set()
            if statement_symbol:
                if statement_symbol.signature_symbols:
                    for symbol in statement_symbol.signature_symbols:
                        if symbol.name in private_names and not symbol.name in symbol_names:
                            symbol_names.add(symbol.name)
                if statement_symbol.value_symbols:
                    for symbol in statement_symbol.value_symbols:
                        for persistant_symbol_name in private_names:
                            if symbol.name.endswith(persistant_symbol_name): 
                                if not persistant_symbol_name in symbol_names:
                                    symbol_names.add(persistant_symbol_name)
            for name in symbol_names:
                dependentStatements = persistant_def_name_dict[name].dependentStatements
                
                if not stmt.id in dependentStatements:
                    dependentStatements.append(stmt.id)

    def _get_dependent_statements_from_symbols(self, statement_full_name_dict, statement_symbol):
        dependent_statements = set()
        if statement_symbol is None:
            return dependent_statements
        statements = set()
        if statement_symbol.signature_symbols:
            for symbol in statement_symbol.signature_symbols:
                stmts = self._get_match_statements(statement_full_name_dict, symbol)
                for stmt in stmts:
                    if not stmt in statements:
                        statements.add(stmt)
        if statement_symbol.value_symbols:
            for symbol in statement_symbol.value_symbols:
                stmts = self._get_match_statements(statement_full_name_dict, symbol)
                for stmt in stmts:
                    if not stmt in statements:
                        statements.add(stmt)
        return statements
    
    def _get_match_statements(self, statement_full_name_dict, symbol):
        if symbol.src_name is None:
            return 
        match_full_name = None
        match_index = -1
        for stmt_full_name in statement_full_name_dict.keys():
            stmt_fileRange = statement_full_name_dict[stmt_full_name].fileRange
            if symbol.range.start < stmt_fileRange.start:
                continue
            stmt_name_parts = stmt_full_name.split(".")
            symbol_name_parts = symbol.src_name.split(".")
            for index, part in enumerate(reversed(stmt_name_parts)):
                if len(symbol_name_parts) <= index:
                    break
                if part == symbol_name_parts[index-1]:
                    if match_index < index:
                        match_full_name = stmt_full_name
                        match_index = index
                else:
                    break
        if match_full_name:
            return statement_full_name_dict[match_full_name].dependentStatements
        return set()
            
    def _get_persistant_symbol_name_dict(self, statementSymbol, persistant_name_dict):
        share_symbol_name_dict = {}
        if statementSymbol == None:
            return share_symbol_name_dict
        
        for persistant_name_key in persistant_name_dict.keys():
            persistant_name = persistant_name_dict[persistant_name_key]
            if statementSymbol.signature_symbols:
                for symbol in statementSymbol.signature_symbols:
                    if symbol.is_private == persistant_name.privateSymbol:
                         if symbol.name.endswith(persistant_name_key):
                            share_symbol_name_dict[symbol.name] = persistant_name.dependentStatements

            if statementSymbol.value_symbols:
                for symbol in statementSymbol.value_symbols:
                    if symbol.is_private == persistant_name.privateSymbol:
                         if symbol.name.endswith(persistant_name_key):
                            share_symbol_name_dict[symbol.name] = persistant_name.dependentStatements

        return share_symbol_name_dict

    def _get_content_entry_name(self, kind, entry_content):
        entry_content = entry_content.replace("\n", " ").replace("\t", " ").replace("\r", " ").replace("()", " ").replace("[", " ")
        parts = entry_content.split(" " + kind + " ")
        if len(parts) < 2:
            return None
        if not (" private "  in " " + parts[0] + " "):
            return None
        parts = parts[1].split(" ")
        if len(parts) < 2:
            return None
        return parts[0].strip()
