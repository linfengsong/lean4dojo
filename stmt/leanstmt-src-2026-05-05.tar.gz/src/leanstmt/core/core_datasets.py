from tokenize import String

import msgspec
from typing import Optional, Literal, List, Annotated

CoreNameID = list[str | int]

class CoreSymbolReference(msgspec.Struct):
    name: CoreNameID
    range: Optional[Annotated[list[int], msgspec.Meta(min_length=2, max_length=2)]] = None
    src_name: str = msgspec.field(name="srcName", default=None)
    explicit_arg_names: list[str] = msgspec.field(name="explicitArgNames", default_factory=list)
    explicit_arg_types: list[str] = msgspec.field(name="explicitArgTypes", default_factory=list)
    instance_arg_names : list[str] = msgspec.field(name="instanceArgNames", default_factory=list)
    instance_arg_types : list[str] = msgspec.field(name="instanceArgTypes", default_factory=list)

def is_lean_disjoint_union(*xs) -> bool:
    return sum(x is not None for x in xs) == 1
    
# Declaration types
CoreBinderInfo = Literal["default", "implicit", "strictImplicit", "instImplicit"]
CoreVisibility = Literal["regular", "protected", "private", "public"]
CoreComputeKind = Literal["regular", "meta", "noncomputable"]
CoreRecKind = Literal["default", "partial", "nonrec"]
CoreDeclarationKind = Literal[
    "abbrev",
    "axiom",
    "classInductive",
    "definition",
    "example",
    "inductive",
    "instance",
    "opaque",
    "structure",
    "theorem",
    "variable",
    "proofWanted",

    "constructor",
    "recursor",
    "Lean.Parser.Command.declaration",
]
# Symbol
CoreSymbolKind = Literal[
    "axiom",
    "definition",
    "theorem",
    "opaque",
    "quotient",
    "inductive",
    "constructor",
    "recursor",
    "instance",
]

CoreTacticCommandKind= Literal[
    "axiom",
    "definition",
    "theorem",
    "opaque",
    "quotient",
    "inductive",
    "constructor",
    "recursor",
    "instance",
]

CoreSimpleElabInfo = Literal[
    "command",
    "field",
    "option",
    "completion",
    "uw",
    "custom",
    "alias",
    "redecl",
    "omission",
    "partial",
    "term",
]

class CoreStringRange(msgspec.Struct, array_like=True):
    """A byte range within a file"""

    start: int
    stop: int

    def as_slice(self) -> slice:
        return slice(self.start, self.stop)
    
    def __eq__(self, other):
        return self.start == other.start and self.stop == other.stop
    
    def __lt__(self, other):
        return self.start < other.start or self.start == other.start and self.stop < other.stop
    
class CoreScopeRangeInfo(msgspec.Struct):
  kind : str
  name : str
  range : Optional[CoreStringRange]

class CoreContextEntryInfo(msgspec.Struct):
  kind : str
  content : str
  range : Optional[CoreStringRange]

class CoreLocalContextInfo(msgspec.Struct):
  context_entries: list[CoreContextEntryInfo] = msgspec.field(name="contextEntries", default="default")

# Module Info
class CoreModuleInfo(msgspec.Struct):
    """Module-level information"""

    imports: list[CoreNameID]
    """Modules directly imported by this module"""
    docstring: list[str]
    """List of all docstrings in this module, as marked by /-! ... -/"""
    scope_range_infos: list[CoreScopeRangeInfo] = msgspec.field(name="scopeRangeInfos", default="default")
    """List of all scope ranges for section and namespace in this module"""

class CoreParam(msgspec.Struct):
    """A parameter to a declaration, as defined in the source code"""

    ref: Optional[CoreStringRange] = None
    """The entire syntax object, e.g., `{x : A}`"""
    id: Optional[CoreStringRange] = None
    """The identifier part, e.g., `x` in {x : A}"""
    type: Optional[CoreStringRange] = None
    """The type part, e.g., `A` in {x : A}"""
    binder_info: CoreBinderInfo = msgspec.field(name="bi", default="default")
    """The binder kind of this parameter, e.g., `implicit` for {x : A}"""

class CoreAttribute(msgspec.Struct):
    kind: str
    name: CoreNameID
    stx: Optional[CoreStringRange] = None

class CoreModifiers(msgspec.Struct):
    """A modifier attached to a declaration"""

    visibility: CoreVisibility
    attrs: list[CoreAttribute]
    """Visibility level of a declaration"""
    is_noncomputable: bool = False
    compute_kind: CoreComputeKind = msgspec.field(name="computeKind", default="regular")
    rec_kind: CoreRecKind = msgspec.field(name="recKind", default="default")
    """Recursion level of a declaration"""
    is_unsafe: bool = msgspec.field(name="isUnsafe", default=False)
    docstring: Optional[tuple[str, bool]] = msgspec.field(name="docString", default=None)

class CoreSyntax(msgspec.Struct):
    """A simplified representation of a Syntax node"""

    original: bool
    """Whether this Syntax node is original or generated (e.g., by a macro)"""
    range: Optional[CoreStringRange] = None


class CorePPSyntax(msgspec.Struct):
    """A Syntax node with pretty-printing info"""

    original: bool
    range: Optional[CoreStringRange] = None
    pp: Optional[str] = None


class CoreOpenDeclSimple(msgspec.Struct):
    """Simple open declaration"""
    namespace: CoreNameID
    hiding: list[CoreNameID] = msgspec.field(name="except", default_factory=list)


class CoreOpenDeclRename(msgspec.Struct):
    """Rename open declaration"""
    name: CoreNameID
    as_: CoreNameID = msgspec.field(name="as")


class CoreOpenDecl(msgspec.Struct):
    """An `open` directive in Core"""

    simple: Optional[CoreOpenDeclSimple] = None
    rename: Optional[CoreOpenDeclRename] = None

    def __post_init__(self):
        if not is_lean_disjoint_union(self.simple, self.rename):
            raise ValueError("exactly one of [simple, rename] is expected")


class CoreScopeInfo(msgspec.Struct):
    """Current scope info, i.e., variables, namespaces, etc.  Used for isolating declarations in a file"""

    var_decls: list[str] = msgspec.field(name="varDecls", default_factory=list)
    """`variable` directives"""
    include_vars: list[CoreNameID] = msgspec.field(name="includeVars", default_factory=list)
    """variables marked with `include`"""
    omit_vars: list[CoreNameID] = msgspec.field(name="omitVars", default_factory=list)
    """variables marked with `omit`"""
    curr_namespace: CoreNameID = msgspec.field(name="currNamespace", default_factory=list)
    """The current namespace"""
    open_decl: list[CoreOpenDecl] = msgspec.field(name="openDecl", default_factory=list)
    """`open` directives"""
    scoped_open_decl: list[CoreNameID] = msgspec.field(name="scopedOpenDecl", default_factory=list)
    """`open` directives in the current scope, including those from outer scopes"""

class CoreDeclaration(msgspec.Struct):
    """Declarations in the source code"""
    
    kind: CoreDeclarationKind
    """Kind of a declaration"""
    ref: CorePPSyntax
    name: CoreNameID
    signature: CorePPSyntax
    """The signature part, e.g., `{α : Sort u} (a : α) : α` in `def id {α : Sort u} (a : α) : α`"""
    modifiers: CoreModifiers
    params: list[CoreParam] = msgspec.field(default_factory=list)
    type: Optional[CorePPSyntax] = None
    value: Optional[CorePPSyntax] = None
    scope_info: Optional[CoreScopeInfo] = msgspec.field(name="scopeInfo", default=None)

class CoreSymbol(msgspec.Struct):
    kind: "CoreSymbolKind"
    name: CoreNameID
    type_full: Optional[str] = msgspec.field(name="typeFull", default=None)
    type_readable: Optional[str] = msgspec.field(name="typeReadable", default=None)
    type_fallback: str = msgspec.field(name="typeFallback", default="")
    type_references: list[CoreSymbolReference] = msgspec.field(name="typeReferences", default_factory=list)
    value_references: Optional[list[CoreSymbolReference]] = msgspec.field(name="valueReferences", default=None)
    is_prop: bool = msgspec.field(name="isProp", default=False)

    @property
    def type(self) -> str:
        return self.type_full or self.type_fallback
    

class CoreTacticCommandReference(msgspec.Struct):
  idents: list[str]
  range: CoreStringRange
  src: str
  tacticName: str


class CoreTacticCommandInfo(msgspec.Struct):
  kind: CoreTacticCommandKind
  name: CoreNameID
  references: list[CoreTacticCommandReference] = msgspec.field(name="references", default_factory=list)

class CoreVariable(msgspec.Struct, kw_only=True):
    """
    A variable in Core contexts.

    Usually called a :term:`free variable` or an `fvar` in Core terminology.
    """

    id: CoreNameID
    name: CoreNameID
    binder_info: Optional[CoreBinderInfo] = msgspec.field(name="binderInfo", default=None)
    """Binder info of this variable, or None if it is defined by a `let`"""
    type: str
    value: Optional[str] = None
    """Value of this variable if it is defined by a `let`, or None otherwise"""
    is_prop: bool = msgspec.field(name="isProp", default=False)

CoreContext = list[CoreVariable]
"""A :term:`local context` in Core"""

class CoreGoal(msgspec.Struct):
    """A :term:`metavariable` in Core"""

    tag: CoreNameID
    """The user name of this metavariable"""
    context: CoreContext
    mvar_id : CoreNameID = msgspec.field(name="mvarId")
    type: str
    is_prop: bool = msgspec.field(name="isProp", default=False)
    pp: str = None
    """Pretty-printed representation of this goal by `Meta.ppGoal`"""


CoreProofState = list[CoreGoal]
"""A :term:`proof state`, represented by a list of goals"""


# Elaboration
class CorePPSyntaxWithKind(msgspec.Struct):
    """A Syntax node with pretty-printing and kind info"""

    original: bool
    range: Optional[CoreStringRange] = None
    pp: Optional[str] = None
    kind: CoreNameID = msgspec.field(default_factory=list)
    """Syntax kind"""


class CoreTacticElabInfo(msgspec.Struct):
    """An InfoTree node about a tactic"""

    references: list[CoreNameID] = msgspec.field(default_factory=list)
    """Names directly referenced in the tactic"""
    before: CoreProofState = msgspec.field(default_factory=list)
    after: CoreProofState = msgspec.field(default_factory=list)


class CoreSpecialValue(msgspec.Struct):
    """Marks the current value is of a special form of interest"""

    const: Optional[CoreNameID] = None
    """This value is a constant reference"""
    fvar: Optional[CoreNameID] = None
    """This value is a fvar reference"""

    def __post_init__(self):
        if not is_lean_disjoint_union(self.const, self.fvar):
            raise ValueError("exactly one of [const, fvar] is expected")


class CoreTermElabInfo(msgspec.Struct):
    """An InfoTree node about a term"""

    context: CoreContext = msgspec.field(default_factory=list)
    type: str = ""
    expected_type: Optional[str] = msgspec.field(name="expectedType", default=None)
    value: str = ""
    special: Optional[CoreSpecialValue] = None


class CoreMacroInfo(msgspec.Struct):
    """An InfoTree node about a macro expansion"""

    expanded: CorePPSyntaxWithKind

class CoreElabInfo(msgspec.Struct):
    """
    An InfoTree node

    Can be one of term node, tactic node, macro node, or simple node.

    A simple node is one with only its kind recorded.
    """

    term: Optional[CoreTermElabInfo] = None
    tactic: Optional[CoreTacticElabInfo] = None
    macro: Optional[CoreMacroInfo] = None
    simple: Optional[CoreSimpleElabInfo] = None

    def __post_init__(self):
        if not is_lean_disjoint_union(self.term, self.tactic, self.macro, self.simple):
            raise ValueError("exactly one of [term, tactic, macro, simple] is expected")


class CoreInfoTree(msgspec.Struct):
    """An InfoTree node with elaboration information"""
    
    info: CoreElabInfo
    ref: CorePPSyntaxWithKind
    children: list["CoreInfoTree"]= msgspec.field(default_factory=list)

class CoreLineModel(msgspec.Struct):
    """An Line node with line information"""
    start: int
    state: CoreProofState = msgspec.field(default_factory=list)
    line: str = None

class CoreSyntaxOriginal(msgspec.Struct):
    pos: int
    endPos: int
    leading: str = ""
    trailing: str = ""

class CoreSyntaxInfo(msgspec.Struct):
    original: Optional[CoreSyntaxOriginal] = None

class CoreSyntaxAtom(msgspec.Struct):
    val: str
    info: Optional[CoreSyntaxInfo] = None

class CoreSyntaxIdent(msgspec.Struct):
    val: List[str]      # 注意：您的範例中 val 是 ["hello_world"] 陣列
    rawVal: str
    info: Optional[CoreSyntaxInfo] = None
    preresolved: List[str] = []

class CoreSyntaxNode(msgspec.Struct):
    kind: Optional[str] = None # Jixia 有時在 node 外層或內層標註 kind
    args: List["CoreSyntaxTree"] = []

class CoreSyntaxTreeInfo(msgspec.Struct):
    node: Optional[CoreSyntaxNode] = None
    atom: Optional[CoreSyntaxAtom] = None
    ident: Optional[CoreSyntaxIdent] = None

class CoreSyntaxTree(msgspec.Struct):
    kind: str
    children: Optional[List[Optional["CoreSyntaxTree"]]] = None
    value: Optional[str] = None
    range: Optional[CoreStringRange] = None
    info: Optional[CoreSyntaxTreeInfo] = None
