Glossary
========

.. glossary::

   free variable
   local context
   metavariable
   proof state
