from dataclasses import dataclass
import msgspec.json
from pathlib import Path
from .structs import LeanModuleInfo,LeanSymbol,LeanDeclaration,LeanInfoTree
from .module import ModuleData,SymbolData,DeclarationData,InfoTreeData,ModuleTreeData,ProjectData,to_lean_ident

@dataclass
class LeanProjectData(ProjectData):
    working_dir: str
    json_dir: str = ".jixia"

    def loadModuleTree(self, module_name):
        module = self.load_info(module_name, "mod", LeanModuleInfo)
        if module is None:
            return None
        
        try:
            #write_lean(project, module_name, output_dir)
            symbols = self.load_info(module_name, "sym", list[LeanSymbol])
            decls = self.load_info(module_name, "decl", list[LeanDeclaration])
            infoTrees = self.load_info(module_name, "elab", list[LeanInfoTree])

            no_marcor_decls = []
            for decl in decls:
                if "_aux_" in to_lean_ident(decl.name) and "___unexpand_" in to_lean_ident(decl.name):
                    pass #print(f"Lean remove macro decl: {decl.name}")
                else:
                    no_marcor_decls.append(decl)

            mooduleTreeData = ModuleTreeData(
                ModuleData.create(module),
                [SymbolData.create(symbol) for symbol in symbols],
                [DeclarationData.create(decl) for decl in decls],
                [InfoTreeData.create(infoTree) for infoTree in infoTrees]
            )

            return mooduleTreeData
        except Exception as e:
            print(f"xxxx Lean Fail to load json for {module_name}: {e}")
            return None
    
    def load_info(self, module_name, type, objType):
        module_id = to_lean_ident(module_name)
        filename = f"{module_id}.{type}.json"
        with(Path(self.working_dir) / Path(self.json_dir) / Path(filename)).open(encoding='utf-8') as fp:
            raw_json = fp.read()
            
            return msgspec.json.decode(raw_json, type=objType)

