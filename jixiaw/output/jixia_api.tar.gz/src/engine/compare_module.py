import json
from dataclasses import dataclass, is_dataclass, fields
from dataclasses_json import dataclass_json, DataClassJsonMixin
from typing import Any, Dict, Optional
from .jixia_project import JixiaProjectData
from .lean_project import LeanProjectData
from .util import collect_match_modules
from .module import dataclass_field_values


@dataclass_json
@dataclass
class Diff:
    path: str = None
    name: str = None
    old: Any = None
    new: Any = None
    parent_old: Any = None
    parent_new: Any = None

    @classmethod
    def create(cls, path, name, old, new, parent_old, parent_new, diff_detail):
        if diff_detail > 0:
            return cls (
                path = path,
                name = name,
                old = old,
                new = new,
                parent_old = parent_old,
                parent_new = parent_new,
            )
        else:
            num_cut = 200
            return cls (
                path = path,
                name = name,
                old = f"{old}"[:num_cut],
                new = f"{new}"[:num_cut],
                parent_old = f"{parent_old}"[:num_cut],
                parent_new = f"{parent_new}"[:num_cut],          
            )
        
def createListData(list: list, diff_detail: int) -> list:
    if len(list) == 0:
        return []
    if hasattr(list[0], "name"):
        out_list = []
        for item in list:
            item_name = getattr(item, "name")
            out_list.append(item_name)
        return out_list
    else:
        index = diff_detail
        if len(list) <= diff_detail:
            index = len(list) - 1
        return [] #list[index]

def find_first_mismatch_detail(name1:str, fname, list1: list, name2: str, list2: list, diff_detail: int = 0, path: str = "") -> Optional[Dict[str, Any]]:
    """
    遞迴尋找第一個不相等的欄位。
    回傳範例: {'path': '...', 'val1': ..., 'val2': ...}
    """
    obj1 = list1[0]
    obj2 = list2[0]
    # 1. 處理類型不一致
    if type(obj1) is not type(obj2):
        return Diff.create(
            path=path if path else "root",
            name=fname,
            old=obj1,
            new=obj2,
            parent_old=list1[diff_detail],
            parent_new=list2[diff_detail],
            diff_detail=diff_detail
            )

    # 2. 處理 Dataclass
    if is_dataclass(obj1):
        for f in fields(obj1):
            current_path = f"{path}.{f.name}" if path else f.name
            v1, v2 = dataclass_field_values(f, obj1, obj2)
            res = find_first_mismatch_detail(name1, f.name, [v1, *list1], name2, [v2, *list2], diff_detail, current_path)
            if res: return res
        return None

    # 3. 處理列表 (List)
    if isinstance(obj1, list):
        if len(obj1) != len(obj2):
            return Diff.create(
                path=path if path else "root",
                name=fname,
                old=len(obj1),
                new=len(obj2),
                parent_old=createListData(obj1, diff_detail),
                parent_new=createListData(obj2, diff_detail),
                diff_detail=diff_detail
            )
        for i, (item1, item2) in enumerate(zip(obj1, obj2)):
            item_name = ""
            if hasattr(item1, "name"):
                item_name = getattr(item1, "name")
            res = find_first_mismatch_detail(name1, f"{fname},{item_name}", [item1, *list1], name2, [item2, *list2], diff_detail, f"{path}[{i}, {item_name}]")
            if res: return res
        return None

    # 4. 基本數值或其它類型比較
    if obj1 != obj2:
        return Diff.create(
            path=path if path else "root",
            name=fname,
            old=obj1,
            new=obj2,
            parent_old=list1[diff_detail],
            parent_new=list2[diff_detail],
            diff_detail=diff_detail
        )

    return None

def print_diff(label, module_name, diff, prefect):
    if diff is None:
        return
    elif prefect:
        json_str = diff.to_json(indent=2, ensure_ascii=False)
    else:
        json_str = f"    {diff.to_json(ensure_ascii=False)}"
    print(f"module_name {module_name} is different on {label}")
    print(json_str)

def compare_module(jixia_project, lean_project, module_name, diff_detail, prefect):

    jixia_label = "old"
    lean_label = "new"
    try:
        jixia_moduleTreeData = jixia_project.loadModuleTree(module_name)
        if jixia_moduleTreeData is None:
            print(f"jixia_moduleTreeData is None on {module_name}")
            return
        
        lean_moduleTreeData = lean_project.loadModuleTree(module_name)
        if lean_moduleTreeData is None:
            print(f"lean_moduleTreeData is None on {module_name}")
            return
    
        if jixia_moduleTreeData.module != lean_moduleTreeData.module:
            diff = find_first_mismatch_detail(jixia_label, "root", [jixia_moduleTreeData.module, jixia_moduleTreeData], 
                                              lean_label, [lean_moduleTreeData.module, lean_moduleTreeData], diff_detail)
            print_diff("module", module_name, diff, prefect)

        if jixia_moduleTreeData.symbols != lean_moduleTreeData.symbols:
            diff = find_first_mismatch_detail(jixia_label, "root", [jixia_moduleTreeData.symbols, jixia_moduleTreeData], 
                                              lean_label, [lean_moduleTreeData.symbols, lean_moduleTreeData], diff_detail)
            print_diff("symbols", module_name, diff, prefect)

        if jixia_moduleTreeData.decls != lean_moduleTreeData.decls:
            diff = find_first_mismatch_detail(jixia_label, "root", [jixia_moduleTreeData.decls, jixia_moduleTreeData], 
                                              lean_label, [lean_moduleTreeData.decls, lean_moduleTreeData], diff_detail)
            print_diff("decls", module_name, diff, prefect)

        #if jixia_moduleTreeData.infoTrees != lean_moduleTreeData.infoTrees:
        #    diff = find_first_mismatch_detail("jixia", "root", jixia_moduleTreeData.infoTrees, "lean", lean_moduleTreeData.infoTrees, diff_detail)
        #    print_diff("infoTrees", module_name, diff, diff_detail, prefect)

    except Exception as e:
        print(f"xxxx Fail to compare module: {module_name}")
        raise e


def process_searches(working_dir: str, search_list: list[str], exclude_list: list[str], diff_detail, prefect):
    jixia_project = JixiaProjectData(working_dir, json_dir=".jixia.v4.24.0")
    lean_project = LeanProjectData(working_dir)

    print(f"Comparing: jixia_project: {jixia_project}, lean_project: {lean_project}")
    print(f"    search_list: {search_list}")

    jixia_modules = []
    for search in search_list:
        jixia_modules.extend(collect_match_modules(jixia_project, search, exclude_list))

    lean_modules = []
    for search in search_list:
        lean_modules.extend(collect_match_modules(lean_project, search, exclude_list))

    for module_name in lean_modules:
        compare_module(jixia_project, lean_project, module_name, diff_detail, prefect)

if __name__ == "__main__":
    search_list = [
        #"Init",
        #"Mathlib",
        #"LeanTest",
        #"Init.Try"
        #"Init.Data.Cast"
        "Mathlib.MeasureTheory"
        #"Mathlib.MeasureTheory.SetAlgebra"
        #"Mathlib.MeasureTheory.PiSystem",
        #"Mathlib.MeasureTheory.Constructions.SubmoduleQuotient"
        #"Mathlib.MeasureTheory.Constructions.Projective"
    ]
    exclude_list = [
        "Init.WF",
        "Init.Meta.Defs",
        'Mathlib.Data.Prod.Basic',

        "Mathlib.Tactic.CC.Addition",
        "Mathlib.Tactic.Simps.Basic",
        "Mathlib.Lean.Meta.CongrTheorems",
        "Mathlib.Util.Notation3"
    ]
    diff_detail = 0
    #prefect = True
    prefect = False

    process_searches("/home/linfe/math/lean_test", search_list, exclude_list, diff_detail, prefect)